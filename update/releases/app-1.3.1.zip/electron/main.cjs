/**
 * VFX STUDIO 桌面客户端主进程
 * - 打开应用窗口（内置 Chromium，不依赖用户浏览器）
 * - 生产模式用内置本地服务器加载页面（file:// 会拦截 ES module）
 * - 通过 IPC 接收渲染进程产出的透明 PNG 帧
 * - 调用内置 ffmpeg 合成 ProRes 4444 透明 MOV
 */
const { app, BrowserWindow, ipcMain, dialog, shell, nativeTheme, screen } = require('electron')
// 任务栏归属：与 electron-builder 的 appId 一致。
// 不设置的话 Windows 会按 exe 元数据（手工拼装的便携版是 "Electron"）显示悬停提示与分组。
app.setAppUserModelId('com.vfxstudio.overlay')
const path = require('node:path')
const fs = require('node:fs')
const fsp = require('node:fs/promises')
const os = require('node:os')
const http = require('node:http')
const { execFile, spawn } = require('node:child_process')

const isDev = !app.isPackaged
/** @type {BrowserWindow | null} */
let win = null
/** @type {BrowserWindow | null} */
let activationWin = null
/** @type {import('node:http').Server | null} */
let staticServer = null
/** 本地静态服务器端口（激活窗口复用同一服务器） */
let serverPort = 0

/**
 * 应用图标（窗口左上角 / 任务栏 / 快捷方式）。
 * public/icon.ico 会被 vite 原样拷进 dist，主进程在 electron/ 下，故取 ../dist/icon.ico。
 */
const APP_ICON = path.join(__dirname, '..', 'dist', 'icon.ico')

/**
 * 启动诊断日志：写到 userData/startup.log。
 * 客户端「打不开」时，把这份日志发给开发者即可定位卡在哪个阶段
 * （app 未就绪 / 窗口未创建 / 页面未加载 / 渲染进程崩溃）。
 */
function logStartup(...args) {
  try {
    const p = path.join(app.getPath('userData'), 'startup.log')
    fs.appendFileSync(p, `[${new Date().toISOString()}] ${args.join(' ')}\n`)
  } catch {
    /* 忽略 */
  }
}

/**
 * 是否运行在「已安装模式」。
 * 判据：exe 同目录存在 NSIS 生成的 Uninstall 程序（便携版没有）。
 * 用来区分「安装包装的版本」与「免安装解压版」——只有前者才自动补快捷方式。
 */
function isInstalledMode() {
  if (process.platform !== 'win32') return false
  try {
    const dir = path.dirname(process.execPath)
    return fs
      .readdirSync(dir)
      .some((f) => f.toLowerCase().startsWith('uninstall') && f.toLowerCase().endsWith('.exe'))
  } catch {
    return false
  }
}

/**
 * 桌面 / 开始菜单快捷方式兜底（2026-09-28）
 *
 * 背景：electron-builder 的 NSIS 模板在「覆盖安装」时走 keepShortcuts 分支，
 * 若旧快捷方式本来就不存在，模板既不新建也不重建 → 装完桌面没有图标。
 * build/installer.nsh 的 customInstall 已无条件补建，这里再兜一层：
 * 应用每次启动自检，安装模式下发现快捷方式缺失就直接补上（已存在则不动，
 * 尊重用户手动删除以外的意外丢失）。
 *
 * 便携版不触发（避免往用户桌面乱写东西）。
 */
function ensureShortcuts() {
  if (!isInstalledMode()) return
  const exe = process.execPath
  const dir = path.dirname(exe)
  const targets = []
  try {
    targets.push(path.join(app.getPath('desktop'), 'VFX STUDIO.lnk'))
  } catch {
    /* 忽略 */
  }
  try {
    targets.push(
      path.join(
        app.getPath('appData'),
        'Microsoft',
        'Windows',
        'Start Menu',
        'Programs',
        'VFX STUDIO.lnk'
      )
    )
  } catch {
    /* 忽略 */
  }
  for (const lnk of targets) {
    if (fs.existsSync(lnk)) continue
    try {
      shell.writeShortcutLink(lnk, 'create', {
        target: exe,
        cwd: dir,
        icon: exe,
        iconIndex: 0,
        description: 'VFX STUDIO 视频特效创作工作台'
      })
      logStartup('shortcut created:', lnk)
    } catch (err) {
      logStartup('shortcut failed:', lnk, String((err && err.message) || err))
    }
  }
}

/** 音乐保存目录（随应用数据持久化） */
function musicDir() {
  const d = path.join(app.getPath('userData'), 'music')
  if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true })
  return d
}

/** 定位 ffmpeg：打包后在 resources，开发时用项目内置，兜底走系统 PATH */
function ffmpegPath() {
  const candidates = []
  if (app.isPackaged) candidates.push(path.join(process.resourcesPath, 'ffmpeg.exe'))
  candidates.push(path.join(__dirname, 'bin', 'ffmpeg.exe'))
  for (const c of candidates) {
    if (fs.existsSync(c)) return c
  }
  return 'ffmpeg'
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
  '.bmp': 'image/bmp',
  '.avif': 'image/avif',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.mp4': 'video/mp4',
  '.webm': 'video/webm',
  '.mov': 'video/quicktime',
  '.m4v': 'video/x-m4v',
  '.srt': 'text/plain; charset=utf-8',
}

/** 最近媒体注册表：token → 文件路径（用于刷新/重启后恢复源视频） */
function mediaRegistryPath() {
  return path.join(app.getPath('userData'), 'media-registry.json')
}

function loadMediaRegistry() {
  try {
    return JSON.parse(fs.readFileSync(mediaRegistryPath(), 'utf8'))
  } catch {
    return {}
  }
}

function saveMediaRegistry(reg) {
  fs.writeFileSync(mediaRegistryPath(), JSON.stringify(reg, null, 2))
}

/**
 * 编排自动保存文件：存在 userData 下。
 * 不用 localStorage 的原因：生产模式本地服务器每次随机端口，页面 origin 每次都变，
 * localStorage 按 origin 隔离 → 换端口就取不到旧数据（重启看似被清空）。
 */
function autosavePath() {
  return path.join(app.getPath('userData'), 'autosave.json')
}

/** 「历史舞台」快照文件：同样放 userData，与页面 origin 无关 */
function historyPath() {
  return path.join(app.getPath('userData'), 'history.json')
}

/** 带 Range 支持的文件流（视频拖动进度需要） */
function serveWithRange(req, res, filePath) {
  let stat
  try {
    stat = fs.statSync(filePath)
  } catch {
    res.writeHead(404)
    res.end()
    return
  }
  const mime = MIME[path.extname(filePath).toLowerCase()] || 'application/octet-stream'
  const range = req.headers.range
  if (range) {
    const m = /bytes=(\d*)-(\d*)/.exec(range)
    let start = m && m[1] ? parseInt(m[1], 10) : 0
    let end = m && m[2] ? parseInt(m[2], 10) : stat.size - 1
    if (Number.isNaN(start)) start = 0
    if (Number.isNaN(end) || end >= stat.size) end = stat.size - 1
    if (start > end) {
      res.writeHead(416, { 'Content-Range': `bytes */${stat.size}` })
      res.end()
      return
    }
    res.writeHead(206, {
      'Content-Range': `bytes ${start}-${end}/${stat.size}`,
      'Accept-Ranges': 'bytes',
      'Content-Length': end - start + 1,
      'Content-Type': mime,
    })
    fs.createReadStream(filePath, { start, end }).pipe(res)
  } else {
    res.writeHead(200, {
      'Accept-Ranges': 'bytes',
      'Content-Length': stat.size,
      'Content-Type': mime,
    })
    fs.createReadStream(filePath).pipe(res)
  }
}

/** 起一个本地服务器：/ 服务 dist 页面，/music/<file> 服务已保存的音乐 */
function startStaticServer(root) {
  return new Promise((resolve, reject) => {
    const server = http.createServer((req, res) => {
      try {
        let rel = decodeURIComponent(new URL(req.url || '/', 'http://localhost').pathname)
        if (rel === '/' || rel === '') rel = '/index.html'

        // 源视频路由（token → 原文件路径，支持 Range 以便拖动进度）
        // /img 是同一通道的别名：image-wall-1 的图片素材也走 token，同源加载才不会污染导出 canvas
        if (rel === '/video' || rel === '/img') {
          const u = new URL(req.url || '/', 'http://localhost')
          const token = u.searchParams.get('token')
          const reg = loadMediaRegistry()
          const p = token ? reg[token] : null
          if (!p || !fs.existsSync(p)) {
            res.writeHead(404)
            res.end('not found')
            return
          }
          serveWithRange(req, res, p)
          return
        }

        // 音乐文件路由（来自 userData/music 目录）
        if (rel.startsWith('/music/')) {
          const file = path.join(musicDir(), path.basename(rel))
          fs.readFile(file, (err, data) => {
            if (err) {
              res.writeHead(404)
              res.end('not found')
              return
            }
            res.writeHead(200, {
              'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream',
              'Accept-Ranges': 'bytes',
            })
            res.end(data)
          })
          return
        }

        const file = path.join(root, rel)
        if (!path.resolve(file).startsWith(path.resolve(root))) {
          res.writeHead(403)
          res.end('forbidden')
          return
        }
        fs.readFile(file, (err, data) => {
          if (err) {
            res.writeHead(404)
            res.end('not found')
            return
          }
          res.writeHead(200, { 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream' })
          res.end(data)
        })
      } catch (e) {
        res.writeHead(500)
        res.end(String(e))
      }
    })
    server.on('error', reject)
    server.listen(0, '127.0.0.1', () => {
      staticServer = server
      serverPort = server.address().port
      resolve(serverPort)
    })
  })
}

async function createWindow() {
  // 按主屏可用区域计算窗口尺寸，避免无边框窗口在高 DPI / 小屏上
  // 超出可视区（无边框没有原生边缘缩放手柄，超出后无法缩小，表现像「打不开」）。
  const area = screen.getPrimaryDisplay().workAreaSize
  const margin = 40
  const width = Math.min(1620, Math.max(1100, area.width - margin))
  const height = Math.min(980, Math.max(680, area.height - margin))
  logStartup('createWindow: workArea', `${area.width}x${area.height}`, '->', `${width}x${height}`)
  win = new BrowserWindow({
    width,
    height,
    // 最小尺寸：不低于 1100×680（保证三栏/顶栏布局），但绝不超过当前窗口宽高（避免被强制放大到屏幕外）
    // 最小宽度不能太小：再窄左右栏会挤压错位（布局按 ≥1500 设计）
    minWidth: Math.min(1500, width),
    minHeight: Math.min(680, height),
    backgroundColor: '#14161c',
    title: 'VFX STUDIO 视频特效创作工作台',
    icon: APP_ICON,
    autoHideMenuBar: true,
    // Windows 下无边框，由渲染进程自绘「缩小/最大化/关闭」按钮
    frame: process.platform !== 'win32',
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
  })

  // 最大化状态回传渲染进程，用于切换「最大化/还原」图标
  win.on('maximize', () => win?.webContents.send('window:maximized', true))
  win.on('unmaximize', () => win?.webContents.send('window:maximized', false))

  // 渲染进程崩溃 / 消失：记录日志并弹原生提示，便于定位「白屏/打不开」
  win.webContents.on('did-finish-load', () => logStartup('did-finish-load'))
  win.webContents.on('render-process-gone', (_e, det) => {
    logStartup('render-process-gone:', det?.reason || 'unknown')
    dialog.showErrorBox(
      '渲染进程已崩溃',
      `原因：${det?.reason || '未知'}\n\n请重新打开 VFX STUDIO。若反复出现，请把 userData 下的 startup.log 发给开发者。`,
    )
  })

  if (isDev) {
    logStartup('load: dev http://localhost:5173')
    win.loadURL('http://localhost:5173')
  } else {
    const port = await startStaticServer(path.join(__dirname, '..', 'dist'))
    logStartup('load: http://127.0.0.1:' + port + '/index.html')
    win.loadURL(`http://127.0.0.1:${port}/index.html`)
  }

  win.on('closed', () => {
    win = null
  })
}

/** 创建「版本与激活」独立窗口 */
async function createActivationWindow() {
  if (activationWin) {
    activationWin.show()
    activationWin.focus()
    return
  }
  activationWin = new BrowserWindow({
    width: 560,
    height: 740,
    minWidth: 480,
    minHeight: 560,
    backgroundColor: '#14161c',
    title: '版本与激活',
    icon: APP_ICON,
    autoHideMenuBar: true,
    resizable: true,
    frame: true,
    parent: win ?? undefined,
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
  })

  // 确保窗口一定可见并置顶于主窗口之前（曾出现过点了没反应像「没打开」的反馈）
  activationWin.once('ready-to-show', () => {
    if (!activationWin) return
    activationWin.show()
    activationWin.focus()
  })

  // 固定系统标题栏为「版本与激活」：index.html 的 <title> 加载后不再覆盖
  activationWin.on('page-title-updated', (e) => e.preventDefault())

  if (isDev) {
    await activationWin.loadURL('http://localhost:5173/?activation=1')
  } else {
    if (!serverPort) await startStaticServer(path.join(__dirname, '..', 'dist'))
    await activationWin.loadURL(`http://127.0.0.1:${serverPort}/index.html?activation=1`)
  }

  activationWin.on('closed', () => {
    activationWin = null
  })
}

// 单实例锁：避免用户多次双击堆积出多个无边框窗口（互相盖住、像「打不开」）
if (!app.requestSingleInstanceLock()) {
  app.quit()
} else {
  app.on('second-instance', () => {
    if (win) {
      if (win.isMinimized()) win.restore()
      win.focus()
    }
  })

  app.whenReady().then(() => {
    // 深色模式：让 Windows 原生标题栏跟随深色（titleBarOverlay 之外的双保险）
    nativeTheme.themeSource = 'dark'
    logStartup('app ready')
    ensureShortcuts()
    void createWindow()
    app.on('activate', () => {
      if (BrowserWindow.getAllWindows().length === 0) void createWindow()
    })
  })
}

app.on('window-all-closed', () => {
  if (staticServer) {
    staticServer.close()
    staticServer = null
  }
  if (process.platform !== 'darwin') app.quit()
})

/* ------------------------------------------------------------------ *
 * 导出：透明 PNG 帧 → ffmpeg → ProRes 4444 透明 MOV
 * ------------------------------------------------------------------ */

/** 当前导出会话 */
let session = null // { dir: string, total: number, digits: number }

async function cleanupSession() {
  if (session) {
    try {
      await fsp.rm(session.dir, { recursive: true, force: true })
    } catch {
      /* 忽略清理失败 */
    }
    session = null
  }
}

function runFfmpeg(args) {
  return new Promise((resolve, reject) => {
    execFile(ffmpegPath(), args, { maxBuffer: 1024 * 1024 * 64 }, (err, _stdout, stderr) => {
      if (err) {
        const tail = String(stderr || err.message).trim().split('\n').slice(-6).join('\n')
        reject(new Error(tail || 'ffmpeg 执行失败'))
      } else {
        resolve()
      }
    })
  })
}

/** 探测视频是否含音轨（ffmpeg -i 会往 stderr 打印流信息，退出码非 0 属正常） */
function probeHasAudio(filePath) {
  return new Promise((resolve) => {
    execFile(
      ffmpegPath(),
      ['-hide_banner', '-i', filePath],
      { maxBuffer: 1024 * 1024 * 8, timeout: 20000 },
      (_err, _stdout, stderr) => {
        resolve(/Stream #\d+:\d+(?:\[0x[0-9a-f]+\])?(\([a-z]{3}\))?: Audio:/.test(String(stderr || '')))
      },
    )
  })
}

ipcMain.handle('export:start', async (_e, { total }) => {
  await cleanupSession()
  const dir = await fsp.mkdtemp(path.join(os.tmpdir(), 'vfx-frames-'))
  session = { dir, total, digits: String(total).length }
  return { dir }
})

ipcMain.handle('export:frames', async (_e, { startIndex, frames }) => {
  if (!session) throw new Error('导出会话不存在，请重新开始')
  for (let i = 0; i < frames.length; i++) {
    const name = `frame_${String(startIndex + i).padStart(session.digits, '0')}.png`
    await fsp.writeFile(path.join(session.dir, name), Buffer.from(frames[i]))
  }
  return true
})

ipcMain.handle('export:finish', async (_e, { fps, fileName, width, height, duration }) => {
  if (!session) throw new Error('导出会话不存在，请重新开始')
  const { dir, digits } = session

  const { canceled, filePath } = await dialog.showSaveDialog(win ?? undefined, {
    title: '保存透明 MOV',
    defaultPath: fileName || 'overlay.mov',
    filters: [{ name: 'QuickTime 透明视频 (*.mov)', extensions: ['mov'] }],
  })
  if (canceled || !filePath) {
    await cleanupSession()
    return { ok: false, cancelled: true }
  }

  const pattern = path.join(dir, `frame_%0${digits}d.png`)
  const args = [
    '-framerate',
    String(fps),
    '-i',
    pattern,
    '-c:v',
    'prores_ks',
    '-profile:v',
    '4444',
    '-pix_fmt',
    'yuva444p10le',
    '-alpha_bits',
    '16',
    '-vendor',
    'apl0',
  ]
  if (width && height) args.push('-s', `${width}x${height}`)
  // 精确对齐时长：帧数向上取整后输出可能略长，用 -t 裁到目标时长
  if (Number.isFinite(duration) && duration > 0) args.push('-t', String(duration))
  args.push('-y', filePath)

  try {
    await runFfmpeg(args)
  } catch (err) {
    await cleanupSession()
    throw err
  }
  await cleanupSession()
  return { ok: true, filePath }
})

ipcMain.handle('export:cancel', async () => {
  await cleanupSession()
  return true
})

/* 成片导出：原视频（按目标比例 scale+crop）+ 透明动效层帧 + 音乐轨混音 → H.264 MP4 */
ipcMain.handle(
  'videoexport:finish',
  async (_e, { fps, fileName, width, height, videoToken, music }) => {
    if (!session) throw new Error('导出会话不存在，请重新开始')
    const { dir, digits } = session

    const reg = loadMediaRegistry()
    const videoPath = videoToken ? reg[videoToken] : null
    if (!videoPath || !fs.existsSync(videoPath)) {
      await cleanupSession()
      throw new Error('找不到源视频文件，请重新导入视频后再导出')
    }

    // 音乐轨：只保留确实存在的文件
    const clips = []
    for (const m of Array.isArray(music) ? music : []) {
      if (!m || !m.file) continue
      const fp = path.join(musicDir(), path.basename(String(m.file)))
      if (fs.existsSync(fp)) clips.push({ ...m, path: fp })
    }

    const hasSrcAudio = await probeHasAudio(videoPath)

    const { canceled, filePath } = await dialog.showSaveDialog(win ?? undefined, {
      title: '保存成片视频',
      defaultPath: fileName || 'video.mp4',
      filters: [{ name: 'MP4 视频 (*.mp4)', extensions: ['mp4'] }],
    })
    if (canceled || !filePath) {
      await cleanupSession()
      return { ok: false, cancelled: true }
    }

    const pattern = path.join(dir, `frame_%0${digits}d.png`)
    const parts = []
    // 画面：原视频严格按目标比例（9:16 / 16:9）放大裁切铺满，再叠动效层（与舞台预览一致）
    parts.push(
      `[0:v]scale=${width}:${height}:force_original_aspect_ratio=increase,crop=${width}:${height}[base];[base][1:v]overlay=0:0[v]`,
    )

    // 音频：原片音轨 + 每段 BGM（裁剪起点 / 淡入淡出 / 延迟到落点）
    const weights = []
    const labels = []
    if (hasSrcAudio) {
      parts.push(
        `[0:a]aformat=sample_fmts=fltp:sample_rates=44100:channel_layouts=stereo[sa]`,
      )
      weights.push(1)
      labels.push('[sa]')
    }
    clips.forEach((c, i) => {
      const idx = 2 + i
      const offset = Math.max(0, Number(c.offset) || 0)
      const dur = Math.max(0, Number(c.duration) || 0)
      const fi = Math.max(0, Number(c.fadeIn) || 0)
      const fo = Math.max(0, Number(c.fadeOut) || 0)
      let chain = `[${idx}:a]aformat=sample_fmts=fltp:sample_rates=44100:channel_layouts=stereo`
      if (offset > 0 || dur > 0) {
        const end = dur > 0 ? `:end=${(offset + dur).toFixed(3)}` : ''
        chain += `,atrim=start=${offset.toFixed(3)}${end},asetpts=PTS-STARTPTS`
      }
      if (fi > 0) chain += `,afade=t=in:st=0:d=${fi.toFixed(3)}`
      if (fo > 0 && dur > 0) {
        chain += `,afade=t=out:st=${Math.max(0, dur - fo).toFixed(3)}:d=${fo.toFixed(3)}`
      }
      const ms = Math.max(0, Math.round((Number(c.start) || 0) * 1000))
      if (ms > 0) chain += `,adelay=${ms}|${ms}`
      chain += `[bgm${i}]`
      parts.push(chain)
      weights.push(Math.max(0, Math.min(1.5, Number(c.volume ?? 0.9))))
      labels.push(`[bgm${i}]`)
    })

    const hasAudioOut = labels.length > 0
    if (hasAudioOut) {
      // amix 按「权重之和」归一化，因此末端补一个 volume 还原真实音量
      const sum = weights.reduce((s, w) => s + w, 0)
      parts.push(
        `${labels.join('')}amix=inputs=${labels.length}:duration=first:weights=${weights
          .map((w) => w.toFixed(3))
          .join(' ')}${sum > 0 ? `,volume=${sum.toFixed(3)}` : ''},alimiter=limit=0.95[a]`,
      )
    }

    const args = ['-i', videoPath, '-framerate', String(fps), '-i', pattern]
    for (const c of clips) args.push('-i', c.path)
    args.push(
      '-filter_complex',
      parts.join(';'),
      '-map',
      '[v]',
      '-c:v',
      'libx264',
      '-crf',
      '18',
      '-preset',
      'medium',
      '-pix_fmt',
      'yuv420p',
    )
    if (hasAudioOut) {
      args.push('-map', '[a]', '-c:a', 'aac', '-b:a', '192k')
    }
    args.push('-movflags', '+faststart', '-shortest', '-y', filePath)

    try {
      await runFfmpeg(args)
    } catch (err) {
      await cleanupSession()
      throw err
    }
    await cleanupSession()
    return { ok: true, filePath }
  },
)

ipcMain.handle('shell:showItem', async (_e, p) => {
  if (p) shell.showItemInFolder(p)
  return true
})

ipcMain.handle('app:info', async () => ({
  version: app.getVersion(),
  ffmpeg: ffmpegPath(),
  packaged: app.isPackaged,
}))

/* ------------------------------------------------------------------ *
 * 检查更新（2026-09-28）
 *
 * 设计：客户端只做「拉取版本清单 → 比对 → 提示 → 跳浏览器下载」，不自动替换文件。
 * 理由：主力交付是便携版（自包含目录），没有安装器可走静默升级；
 * 且自动覆盖 app.asar 会打断用户正在编辑的工程。
 *
 * 清单托管在腾讯云 COS（或任意 https 静态地址），字段见 update/manifest.example.json。
 * ------------------------------------------------------------------ */

/**
 * 我们自己的代码根目录：resources/app（dist + electron/ + package.json）
 * 主进程在 resources/app/electron/ 下，故取上一级。
 * ⚠️ scripts/pack-code-update.cjs 打包的就是这个目录，改名必须同步。
 */
const APP_CODE_ROOT = path.resolve(__dirname, '..')

/**
 * 运行时标签：必须与 scripts/pack-code-update.cjs 的 RUNTIME_TAG 一致（改必同步）。
 * 只有 Electron 大版本升级时才递增——标签不匹配的旧客户端会自动回退到全量安装包，
 * 避免新代码跑在旧运行时上。
 */
const CODE_UPDATE_RUNTIME_TAG = 'r1'

/** 更新清单地址：读 package.json 的 updateManifest 字段；为空 = 未配置，客户端不联网 */
function updateManifestUrl() {
  try {
    return String(require('../package.json').updateManifest || '').trim()
  } catch {
    return ''
  }
}

/** 便携版（portable）运行时，electron-builder 会注入 PORTABLE_EXECUTABLE_DIR */
function isPortableMode() {
  return !!process.env.PORTABLE_EXECUTABLE_DIR
}

/** 语义化版本比较：a > b 返回 1，相等 0，小于 -1。容忍 '1.2' / 'v1.2.0' 这类写法 */
function compareVersion(a, b) {
  const pa = String(a || '').replace(/^v/i, '').split('.')
  const pb = String(b || '').replace(/^v/i, '').split('.')
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const na = parseInt(pa[i], 10) || 0
    const nb = parseInt(pb[i], 10) || 0
    if (na !== nb) return na > nb ? 1 : -1
  }
  return 0
}

/** 清单超时：宁可「检查失败」，也不能让启动卡在网络上 */
const UPDATE_TIMEOUT_MS = 8000

/**
 * 更新相关地址的安全校验：
 * - 一律要求 https（防止明文传输被劫持、替换成恶意安装包）
 * - 例外：本机 http（127.0.0.1 / localhost），方便本地联调与内网测试
 */
function isSafeUpdateUrl(u) {
  const s = String(u || '')
  if (/^https:\/\//i.test(s)) return true
  return /^http:\/\/(127\.0\.0\.1|localhost)(:\d+)?\//i.test(s)
}

/**
 * 把 Node / Electron 的英文网络错误翻译成中文，避免用户看到 "fetch failed" 这类原始报错。
 * scope 用来区分环节，例如「检查更新」「下载更新包」。
 */
function friendlyNetError(e, scope) {
  const raw = String((e && e.message) || e || '')
  const name = String((e && e.name) || '')
  const prefix = String(scope || '更新')
  let cause = ''
  if (name === 'AbortError' || /aborted|timeout/i.test(raw)) cause = '连接超时'
  else if (/fetch failed/i.test(raw)) cause = '无法连接到服务器'
  else if (/ENOTFOUND|EAI_AGAIN|getaddrinfo/i.test(raw)) cause = '服务器地址解析失败'
  else if (/ECONNREFUSED/i.test(raw)) cause = '服务器拒绝连接'
  else if (/ECONNRESET|EPIPE|socket hang/i.test(raw)) cause = '网络连接被中断'
  else if (/CERT|certificate|SELF_SIGNED/i.test(raw)) cause = '服务器证书校验失败'
  else if (/network|ETIMEDOUT|EHOSTUNREACH|ENETUNREACH/i.test(raw)) cause = '网络异常'
  else if (raw) cause = '发生未知错误（' + raw + '）'
  return `${prefix}失败：${cause || '发生未知错误'}，请检查网络后重试。`
}

/** HTTP 响应码也要说人话：404 多半是清单还没上传 */
function friendlyHttpError(status) {
  if (status === 404) return '服务器返回 404：找不到更新清单文件，请确认清单已上传到正确地址。'
  if (status === 403 || status === 401) return `服务器返回 ${status}：没有访问权限，请确认更新文件已设为公开。`
  if (status >= 500) return `服务器返回 ${status}：更新服务器暂时不可用，请稍后再试。`
  return `服务器返回 HTTP ${status}，请稍后重试。`
}

ipcMain.handle('update:check', async () => {
  const current = app.getVersion()
  const url = updateManifestUrl()
  if (!url) {
    logStartup('update check: skipped (updateManifest 未配置)')
    return { ok: false, reason: 'not-configured', current }
  }
  if (!isSafeUpdateUrl(url)) {
    logStartup('update check: 地址不安全 ->', url)
    return { ok: false, reason: 'bad-url', current }
  }

  const ac = new AbortController()
  const timer = setTimeout(() => ac.abort(), UPDATE_TIMEOUT_MS)
  try {
    // 加时间戳查询参数绕开 CDN 缓存：raw.githubusercontent.com（Fastly）会缓存约 5 分钟，
    // 刚改完清单就点检查会拿到旧版本号，误报「已是最新版本」。cache:'no-store' 只是请求头，
    // 拦不住 CDN 边缘缓存，必须让每次请求的 URL 都不一样。
    const bust = url + (url.includes('?') ? '&' : '?') + '_t=' + Date.now()
    const res = await fetch(bust, {
      signal: ac.signal,
      cache: 'no-store',
      headers: { accept: 'application/json' },
    })
    if (!res.ok) return { ok: false, reason: 'http', current, message: friendlyHttpError(res.status) }

    const m = await res.json()
    const latest = String(m.version || '').trim()
    if (!latest) return { ok: false, reason: 'bad-json', current }

    // 便携版优先给 portableUrl（免安装包），安装版给 downloadUrl（安装包）
    const portable = isPortableMode()
    const downloadUrl = String((portable && m.portableUrl) || m.downloadUrl || '').trim()
    const notes = Array.isArray(m.notes)
      ? m.notes.map((s) => String(s))
      : String(m.notes || '')
          .split('\n')
          .map((s) => s.trim())
          .filter(Boolean)

    // 轻量增量包：只含 resources/app（实测约 0.6MB，而完整安装包 130MB）。
    // 只有 runtimeTag 与本机一致时才启用，否则回退到全量安装包（downloadUrl）。
    let codePackage = null
    const cp = m.codePackage
    if (cp && String(cp.url || '').trim()) {
      const cpUrl = String(cp.url).trim()
      if (String(cp.runtimeTag || '') !== CODE_UPDATE_RUNTIME_TAG) {
        logStartup('code package skipped: runtimeTag 不匹配', String(cp.runtimeTag), '!=', CODE_UPDATE_RUNTIME_TAG)
      } else if (!isSafeUpdateUrl(cpUrl)) {
        logStartup('code package skipped: 地址不安全 ->', cpUrl)
      } else {
        codePackage = {
          url: cpUrl,
          sha256: String(cp.sha256 || '').trim(),
          size: Number(cp.size || 0),
          runtimeTag: String(cp.runtimeTag || ''),
        }
      }
    }

    logStartup('update check: current=' + current + ' latest=' + latest + ' hasUpdate=' + (compareVersion(latest, current) > 0) + ' codePackage=' + !!codePackage)
    return {
      ok: true,
      current,
      latest,
      hasUpdate: compareVersion(latest, current) > 0,
      notes,
      downloadUrl,
      publishedAt: String(m.publishedAt || ''),
      force: !!m.force,
      portable,
      codePackage,
    }
  } catch (e) {
    const msg = friendlyNetError(e, '检查更新')
    logStartup('update check failed:', String((e && e.message) || e), '(url=' + url + ')')
    return { ok: false, reason: 'network', current, message: msg }
  } finally {
    clearTimeout(timer)
  }
})

/** 用系统默认浏览器打开下载页（只允许 http/https，避免被拿来执行本地文件） */
ipcMain.handle('shell:openExternal', async (_e, url) => {
  const u = String(url || '')
  if (!/^https?:\/\//i.test(u)) return false
  await shell.openExternal(u)
  return true
})

/* ------------------------------------------------------------------ *
 * 下载更新包 → 覆盖安装（2026-09-28）
 * ------------------------------------------------------------------ */

/** 同一时刻只允许一个下载任务 */
const updateDownload = { busy: false }

const UPDATE_DOWNLOAD_TIMEOUT_MS = 5 * 60 * 1000

function updateDownloadDir() {
  return path.join(os.tmpdir(), 'vfx-studio-update')
}

/**
 * 安装前备份用户数据（额外保险）
 *
 * 覆盖安装本身不会动数据：程序装在 %LOCALAPPDATA%\Programs\，而
 * app-state.json（DS API key、激活码、AI 学习档案）、autosave.json（当前舞台编排）、
 * history.json 都在 %APPDATA%\overlay-workbench\，且 NSIS 已配置 deleteAppDataOnUninstall=false。
 * 这里仍备份一份，是为了万一新版读坏了旧数据还能回滚。
 * 只备份关键小文件（单文件 >20MB 跳过），避免把音乐/导出缓存也复制一遍。
 */
function backupUserData() {
  try {
    const ud = app.getPath('userData')
    const files = ['app-state.json', 'autosave.json', 'history.json']
    const present = files.filter((f) => {
      try {
        return fs.statSync(path.join(ud, f)).size <= 20 * 1024 * 1024
      } catch {
        return false
      }
    })
    if (!present.length) return ''
    const dest = path.join(ud, 'update-backup-' + new Date().toISOString().slice(0, 10).replace(/-/g, ''))
    fs.mkdirSync(dest, { recursive: true })
    for (const f of present) fs.copyFileSync(path.join(ud, f), path.join(dest, f))
    // 只留最近 3 份备份
    try {
      const olds = fs.readdirSync(ud).filter((d) => /^update-backup-\d{8}$/.test(d)).sort()
      while (olds.length > 3) {
        const first = olds.shift()
        if (first) fs.rmSync(path.join(ud, first), { recursive: true, force: true })
      }
    } catch {
      /* 忽略 */
    }
    logStartup('update backup ->', dest, present.join(','))
    return dest
  } catch (e) {
    logStartup('update backup failed:', String((e && e.message) || e))
    return ''
  }
}

/** 下载更新包到系统临时目录，进度通过 update:progress 事件推给窗口 */
ipcMain.handle('update:download', async (event, opts) => {
  const url = String((opts && opts.url) || '')
  const sha256 = String((opts && opts.sha256) || '').trim()
  if (updateDownload.busy) return { ok: false, reason: 'busy' }
  if (!isSafeUpdateUrl(url)) return { ok: false, reason: 'bad-url' }

  const name = String((opts && opts.fileName) || '').replace(/[^a-zA-Z0-9._-]/g, '_')
  // 允许两类：完整安装包 .exe，以及轻量增量包 .zip（只含我们自己的代码）
  const lowerName = name.toLowerCase()
  if (!lowerName.endsWith('.exe') && !lowerName.endsWith('.zip')) return { ok: false, reason: 'bad-file' }

  updateDownload.busy = true
  try {
    const dir = updateDownloadDir()
    await fsp.mkdir(dir, { recursive: true })
    const file = path.join(dir, name)

    const ac = new AbortController()
    const timer = setTimeout(() => ac.abort(), UPDATE_DOWNLOAD_TIMEOUT_MS)
    try {
      const res = await fetch(url, { signal: ac.signal, redirect: 'follow' })
      if (!res.ok || !res.body) return { ok: false, reason: 'http', message: friendlyHttpError(res.status) }
      const total = Number(res.headers.get('content-length') || 0)

      const reader = res.body.getReader()
      const chunks = []
      let received = 0
      let lastSent = 0
      for (;;) {
        const { done, value } = await reader.read()
        if (done) break
        chunks.push(Buffer.from(value))
        received += value.length
        const now = Date.now()
        if (now - lastSent > 120) {
          lastSent = now
          event.sender.send('update:progress', { received, total })
        }
      }
      const buf = Buffer.concat(chunks)

      // 清单给了 sha256 就校验，防止下载损坏或被劫持
      if (sha256) {
        const hash = require('node:crypto').createHash('sha256').update(buf).digest('hex')
        if (hash.toLowerCase() !== sha256.toLowerCase()) {
          return { ok: false, reason: 'checksum', message: '文件校验不一致，已中止' }
        }
      }

      await fsp.writeFile(file, buf)
      event.sender.send('update:progress', { received: buf.length, total: buf.length || total, done: true })
      return { ok: true, file, size: buf.length }
    } finally {
      clearTimeout(timer)
    }
  } catch (e) {
    const msg = friendlyNetError(e, '下载更新包')
    logStartup('update download failed:', String((e && e.message) || e))
    return { ok: false, reason: 'network', message: msg }
  } finally {
    updateDownload.busy = false
  }
})

/**
 * 覆盖安装：备份用户数据 → 拉起安装器（/S 静默）→ 本程序退出让出文件占用。
 * 便携版没有安装器，改为「下载到指定位置 + 提示手动替换」（返回 needManual）。
 */
ipcMain.handle('update:install', async (_e, opts) => {
  const file = String((opts && opts.file) || '')
  if (!file.toLowerCase().endsWith('.exe') || !fs.existsSync(file)) return { ok: false, reason: 'no-file' }

  const backup = backupUserData()

  if (isPortableMode()) {
    // 便携 exe 是自解压单文件（运行即启动程序，不是安装器），不能自动覆盖 → 交给用户替换
    return { ok: true, needManual: true, file, backup }
  }

  logStartup('update install ->', file)
  try {
    spawn(file, ['/S'], { detached: true, stdio: 'ignore' }).unref()
  } catch (e) {
    return { ok: false, reason: 'spawn', message: '启动安装程序失败：' + String((e && e.message) || e) + '。可尝试手动运行已下载的安装包。' }
  }
  // 给安装器一点时间拉起；本程序不退出会导致文件占用、覆盖失败
  setTimeout(() => app.exit(0), 800)
  return { ok: true, backup }
})

/* ------------------------------------------------------------------ *
 * 轻量增量更新（2026-09-28）
 *
 * 完整安装包 130MB，但其中 99% 是永远不变的 Electron 运行时与 ffmpeg；
 * 我们每次真正改的只有 resources/app（实测 1.01MB，打包后 0.58MB）。
 * 所以优先发这个代码包：下载几百 KB → 覆盖 resources/app → 重启，
 * 不必重下 130MB。runtimeTag 不匹配（Electron 升级）时自动回退全量安装。
 * ------------------------------------------------------------------ */

/** CRC32 查表（手写，避免依赖 zlib.crc32——旧版 Electron 内置 Node 可能没有） */
const CRC_TABLE = (() => {
  const t = new Int32Array(256)
  for (let n = 0; n < 256; n++) {
    let c = n
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1
    t[n] = c
  }
  return t
})()

function crc32Buf(buf) {
  let c = ~0
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8)
  return (~c) >>> 0
}

/**
 * 解析标准 zip（方法 0=store / 8=deflate），只用 Node 内置 zlib，零第三方依赖。
 * 与 scripts/pack-code-update.cjs 生成的包配套。
 */
function unzipBuffer(buf) {
  let eo = -1
  for (let i = buf.length - 22; i >= 0; i--) {
    if (buf.readUInt32LE(i) === 0x06054b50) {
      eo = i
      break
    }
  }
  if (eo < 0) throw new Error('不是有效的 zip 包')
  const count = buf.readUInt16LE(eo + 10)
  let p = buf.readUInt32LE(eo + 16)
  const out = []
  for (let i = 0; i < count; i++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('zip 中央目录损坏')
    const method = buf.readUInt16LE(p + 10)
    const wantCrc = buf.readUInt32LE(p + 16)
    const compSize = buf.readUInt32LE(p + 20)
    const uncompSize = buf.readUInt32LE(p + 24)
    const nameLen = buf.readUInt16LE(p + 28)
    const extraLen = buf.readUInt16LE(p + 30)
    const commentLen = buf.readUInt16LE(p + 32)
    const localOff = buf.readUInt32LE(p + 42)
    const name = buf.toString('utf8', p + 46, p + 46 + nameLen)
    p += 46 + nameLen + extraLen + commentLen

    const lNameLen = buf.readUInt16LE(localOff + 26)
    const lExtraLen = buf.readUInt16LE(localOff + 28)
    const start = localOff + 30 + lNameLen + lExtraLen
    const raw = buf.subarray(start, start + compSize)
    const data = method === 8 ? require('node:zlib').inflateRawSync(raw) : Buffer.from(raw)
    if (data.length !== uncompSize) throw new Error('解压后大小不符：' + name)
    if (crc32Buf(data) !== wantCrc) throw new Error('校验不一致：' + name)
    out.push({ name: String(name).replace(/\\/g, '/').replace(/^\/+/, ''), data })
  }
  return out
}

/** 覆盖前备份当前代码，万一新版起不来还能手工回滚（最多留 2 份） */
function backupCode() {
  try {
    const ud = app.getPath('userData')
    const dest = path.join(ud, 'code-backup-' + new Date().toISOString().slice(0, 10).replace(/-/g, ''))
    fs.mkdirSync(dest, { recursive: true })
    for (const rel of ['dist', 'electron']) {
      const from = path.join(APP_CODE_ROOT, rel)
      if (fs.existsSync(from)) fs.cpSync(from, path.join(dest, rel), { recursive: true, force: true })
    }
    const pj = path.join(APP_CODE_ROOT, 'package.json')
    if (fs.existsSync(pj)) fs.copyFileSync(pj, path.join(dest, 'package.json'))
    try {
      const olds = fs.readdirSync(ud).filter((d) => /^code-backup-\d{8}$/.test(d)).sort()
      while (olds.length > 2) {
        const first = olds.shift()
        if (first) fs.rmSync(path.join(ud, first), { recursive: true, force: true })
      }
    } catch {
      /* 忽略 */
    }
    logStartup('code backup ->', dest)
    return dest
  } catch (e) {
    logStartup('code backup failed:', String((e && e.message) || e))
    return ''
  }
}

/**
 * 应用轻量增量包：校验 → 备份 → 写出新文件 → 清理旧资源 → 重启。
 *
 * 为什么可以在运行中直接覆盖：实测 Windows 上 Node 加载过的 .js/.html/.css
 * 文件句柄已释放，允许覆盖甚至删除（electron.exe 本身被占用，但我们不动它）。
 * 用户数据（app-state.json / autosave.json / music）在 userData 目录，完全不受影响。
 */
ipcMain.handle('update:applyCode', async (_e, opts) => {
  const file = String((opts && opts.file) || '')
  const sha256 = String((opts && opts.sha256) || '').trim()
  if (!file.toLowerCase().endsWith('.zip') || !fs.existsSync(file)) return { ok: false, reason: 'no-file' }

  try {
    const buf = fs.readFileSync(file)
    if (sha256) {
      const h = require('node:crypto').createHash('sha256').update(buf).digest('hex')
      if (h.toLowerCase() !== sha256.toLowerCase()) {
        return { ok: false, reason: 'checksum', message: '更新包校验不一致，已中止' }
      }
    }

    const entries = unzipBuffer(buf)
    if (!entries.length) return { ok: false, reason: 'empty', message: '更新包里没有文件' }

    const root = APP_CODE_ROOT
    const keep = new Set()
    // 越界检查：任何 ../ 都拒绝，只允许写进 APP_CODE_ROOT
    for (const e of entries) {
      const rel = e.name
      if (!rel || rel.split('/').includes('..')) return { ok: false, reason: 'bad-entry', message: '更新包含非法路径' }
      const dest = path.join(root, rel)
      if (!path.resolve(dest).startsWith(path.resolve(root))) {
        return { ok: false, reason: 'bad-entry', message: '更新包含越界路径' }
      }
      keep.add(rel)
    }

    // 备份旧代码（必须在覆盖之前，否则备份到的就是新代码了）
    const backup = backupCode()

    // 写出全部新文件
    for (const e of entries) {
      const dest = path.join(root, e.name)
      fs.mkdirSync(path.dirname(dest), { recursive: true })
      fs.writeFileSync(dest, e.data)
    }

    // 清理 dist/assets 里的旧 hash 文件（新版文件名带新 hash，旧的已无用）
    const assets = path.join(root, 'dist', 'assets')
    if (fs.existsSync(assets)) {
      for (const f of fs.readdirSync(assets)) {
        if (keep.has(`dist/assets/${f}`)) continue
        try {
          fs.rmSync(path.join(assets, f), { force: true })
        } catch {
          /* 占用中就算了，下次启动再清 */
        }
      }
    }

    logStartup('code update applied ->', root, entries.length + ' files')
    // 重启让新代码生效
    setTimeout(() => {
      app.relaunch()
      app.exit(0)
    }, 700)
    return { ok: true, files: entries.length, backup }
  } catch (e) {
    const msg = friendlyNetError(e, '写入新版本')
    logStartup('code update failed:', String((e && e.message) || e))
    return { ok: false, reason: 'apply', message: msg }
  }
})

/* ------------------------------------------------------------------ *
 * 音乐库：上传保存 / 列表
 * ------------------------------------------------------------------ */

ipcMain.handle('music:save', async (_e, { name, ext, data }) => {
  const id = 'm' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6)
  const safeExt = String(ext || 'mp3').replace(/[^a-z0-9]/gi, '').toLowerCase() || 'mp3'
  const file = `${id}.${safeExt}`
  await fsp.writeFile(path.join(musicDir(), file), Buffer.from(data))
  return { file, name: String(name || file).slice(0, 80) }
})

ipcMain.handle('music:list', async () => {
  try {
    const files = await fsp.readdir(musicDir())
    return files
      .filter((f) => /\.(mp3|wav|m4a|ogg|flac|aac)$/i.test(f))
      .map((f) => ({ file: f, name: f.replace(/\.[^.]+$/, '') }))
  } catch {
    return []
  }
})

/* ------------------------------------------------------------------ *
 * 本地素材持久化：注册原路径（源视频 / ImageWall 的图片），刷新或重启后仍可加载
 * ------------------------------------------------------------------ */

ipcMain.handle('video:register', async (_e, filePath) => {
  if (!filePath || !fs.existsSync(filePath)) throw new Error('素材文件不存在')
  const reg = loadMediaRegistry()
  let token = Object.keys(reg).find((k) => reg[k] === filePath)
  if (!token) {
    token = 'v' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6)
    reg[token] = filePath
    saveMediaRegistry(reg)
  }
  return { token }
})

/* ------------------------------------------------------------------ *
 * 编排自动保存：写入 userData/autosave.json（与页面 origin 无关，重启必恢复）
 * ------------------------------------------------------------------ */

ipcMain.on('autosave:load', (e) => {
  try {
    e.returnValue = fs.readFileSync(autosavePath(), 'utf8')
  } catch {
    e.returnValue = ''
  }
})

ipcMain.on('autosave:save', (_e, data) => {
  try {
    fs.writeFileSync(autosavePath(), typeof data === 'string' ? data : '')
  } catch {
    /* 忽略写入失败 */
  }
})

/* ------------------------------------------------------------------ *
 * 历史舞台快照：写入 userData/history.json（与页面 origin 无关）
 * ------------------------------------------------------------------ */

ipcMain.on('history:load', (e) => {
  try {
    e.returnValue = fs.readFileSync(historyPath(), 'utf8')
  } catch {
    e.returnValue = ''
  }
})

ipcMain.on('history:save', (_e, data) => {
  try {
    fs.writeFileSync(historyPath(), typeof data === 'string' ? data : '')
  } catch {
    /* 忽略写入失败 */
  }
})

/* ------------------------------------------------------------------ *
 * AI 状态键值存储：userData/app-state.json（与页面 origin 无关，重启必恢复）。
 * 存风格档案 / 修正记录 / 编排基线 / 导出快照 / AI 配置等小体量 JSON 字符串。
 * 一次启动只在首次读取时读盘，之后走内存缓存。
 * ------------------------------------------------------------------ */

function appStatePath() {
  return path.join(app.getPath('userData'), 'app-state.json')
}

let appStateCache = null

function loadAppState() {
  if (appStateCache) return appStateCache
  try {
    const obj = JSON.parse(fs.readFileSync(appStatePath(), 'utf8'))
    appStateCache = obj && typeof obj === 'object' ? obj : {}
  } catch {
    appStateCache = {}
  }
  return appStateCache
}

ipcMain.on('kv:load', (e, key) => {
  e.returnValue = typeof key === 'string' ? loadAppState()[key] || '' : ''
})

ipcMain.on('kv:save', (_e, { key, data }) => {
  if (typeof key !== 'string' || !key) return
  const state = loadAppState()
  if (typeof data === 'string' && data) state[key] = data
  else delete state[key]
  try {
    fs.writeFileSync(appStatePath(), JSON.stringify(state))
  } catch {
    /* 忽略写入失败 */
  }
})

/* ------------------------------------------------------------------ *
 * 窗口控制：缩小 / 最大化(还原) / 关闭（无边框窗口自绘按钮）
 * ------------------------------------------------------------------ */

ipcMain.on('window:minimize', () => win?.minimize())

ipcMain.on('window:maximize', () => {
  if (!win) return
  if (win.isMaximized()) win.unmaximize()
  else win.maximize()
})

ipcMain.on('window:close', () => win?.close())

ipcMain.handle('window:isMaximized', () => !!win?.isMaximized())

/* ------------------------------------------------------------------ *
 * 激活窗口：独立小窗 + 状态变更通知主窗口刷新 PRO 标识
 * ------------------------------------------------------------------ */

ipcMain.handle('activation:open', () => createActivationWindow())

ipcMain.on('edition:changed', () => {
  // 激活/退出后通知所有窗口刷新 edition 状态
  BrowserWindow.getAllWindows().forEach((w) => {
    w.webContents.send('edition:refresh')
  })
})
