/** 预加载脚本：仅向渲染进程暴露必要的桌面能力 */
const { contextBridge, ipcRenderer, webUtils } = require('electron')

contextBridge.exposeInMainWorld('vfx', {
  isDesktop: true,
  platform: process.platform,

  /** 开始一次导出，total 为总帧数 */
  startExport: (total) => ipcRenderer.invoke('export:start', { total }),

  /** 批量发送帧数据（startIndex 从 1 开始） */
  sendFrames: (startIndex, frames) => ipcRenderer.invoke('export:frames', { startIndex, frames }),

  /** 选择保存位置并用 ffmpeg 合成 MOV */
  finishExport: (opts) => ipcRenderer.invoke('export:finish', opts),

  /** 选择保存位置并用 ffmpeg 把原视频 + 透明帧合成 MP4 成片 */
  finishVideoExport: (opts) => ipcRenderer.invoke('videoexport:finish', opts),

  /** 取消并清理临时帧 */
  cancelExport: () => ipcRenderer.invoke('export:cancel'),

  /** 在文件管理器中定位文件 */
  showItem: (p) => ipcRenderer.invoke('shell:showItem', p),

  /** 应用信息（版本 / ffmpeg 路径） */
  appInfo: () => ipcRenderer.invoke('app:info'),

  /** 检查更新：拉取云端版本清单并与本地版本比对（未配置地址时不联网） */
  checkUpdate: () => ipcRenderer.invoke('update:check'),

  /** 下载更新包到临时目录，进度走 onUpdateProgress */
  downloadUpdate: (opts) => ipcRenderer.invoke('update:download', opts),

  /** 应用轻量增量包：校验 → 备份 → 覆盖 resources/app → 重启（体积仅几百 KB） */
  applyCodeUpdate: (opts) => ipcRenderer.invoke('update:applyCode', opts),

  /** 监听更新包下载进度 */
  onUpdateProgress: (cb) => ipcRenderer.on('update:progress', (_e, p) => cb(p)),
  offUpdateProgress: (cb) => ipcRenderer.removeListener('update:progress', cb),

  /** 用系统默认浏览器打开链接（更新页 / 官网等） */
  openExternal: (url) => ipcRenderer.invoke('shell:openExternal', url),

  /** 打开「激活 PRO」独立窗口 */
  openActivationWindow: () => ipcRenderer.invoke('activation:open'),

  /** 隐藏「激活 PRO」独立窗口（点「完成」时用，避免直接 window.close() 连带关闭主窗口） */
  closeActivationWindow: () => ipcRenderer.send('activation:close'),

  /** 激活窗口：把内容实际需要的高度回报主进程，主进程据此收紧窗口（专业版内容比基础版矮近 300px） */
  reportActivationHeight: (height) => ipcRenderer.send('activation:content-height', height),

  /** 通知主进程：激活状态已变更，请刷新各窗口 PRO 标识 */
  notifyEditionChanged: () => ipcRenderer.send('edition:changed'),

  /** 监听激活状态刷新通知（激活窗口操作后主窗口需同步） */
  onEditionRefresh: (cb) => ipcRenderer.on('edition:refresh', (_e) => cb()),
  offEditionRefresh: (cb) => ipcRenderer.removeListener('edition:refresh', cb),

  /** 音乐库：保存上传的音频，返回文件名 */
  saveMusic: (name, ext, data) => ipcRenderer.invoke('music:save', { name, ext, data }),
  /** 音乐库：列出已保存的音乐 */
  listMusic: () => ipcRenderer.invoke('music:list'),
  /** 音乐库：删除已保存的音频 */
  deleteMusic: (file) => ipcRenderer.invoke('music:delete', { file }),

  /** 取 File 对象的磁盘路径（源视频持久化用） */
  getPathForFile: (file) => {
    try {
      return webUtils.getPathForFile(file)
    } catch {
      return ''
    }
  },
  /** 注册源视频原路径，返回 token（之后可用 /video?token= 播放） */
  registerVideo: (filePath) => ipcRenderer.invoke('video:register', filePath),
  /** 示例工程：把打包内的示例素材 seed 到 userData 并注册 token，返回 文件名 → token 映射 */
  sampleMedia: () => ipcRenderer.invoke('sample:media'),

  /** 编排自动保存（写入 userData/autosave.json，重启后恢复；与端口/origin 无关） */
  autosave: {
    load: () => ipcRenderer.sendSync('autosave:load') || '',
    save: (data) => ipcRenderer.send('autosave:save', data),
  },

  /** 历史舞台快照（写入 userData/history.json，与端口/origin 无关） */
  history: {
    load: () => ipcRenderer.sendSync('history:load') || '',
    save: (data) => ipcRenderer.send('history:save', data),
  },

  /** AI 状态键值存储（写入 userData/app-state.json，与端口/origin 无关，重启保留）。
   *  data 传空串 = 删除该键。 */
  kv: {
    load: (key) => ipcRenderer.sendSync('kv:load', key) || '',
    save: (key, data) => ipcRenderer.send('kv:save', { key, data }),
  },

  /** 系统级机器 ID（Windows MachineGuid 等，与应用版本无关，激活指纹用） */
  machineId: () => {
    try {
      return ipcRenderer.sendSync('machine:id') || ''
    } catch {
      return ''
    }
  },

  /** 窗口控制（无边框窗口自绘按钮） */
  windowControl: {
    minimize: () => ipcRenderer.send('window:minimize'),
    maximize: () => ipcRenderer.send('window:maximize'),
    close: () => ipcRenderer.send('window:close'),
    isMaximized: () => ipcRenderer.invoke('window:isMaximized'),
    onMaximizeChange: (cb) => {
      ipcRenderer.on('window:maximized', (_e, v) => cb(v))
    },
  },
})
