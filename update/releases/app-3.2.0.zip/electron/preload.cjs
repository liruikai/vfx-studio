/** 预加载脚本：仅向渲染进程暴露必要的桌面能力 */
const { contextBridge, ipcRenderer, webUtils } = require('electron')

contextBridge.exposeInMainWorld('vfx', {
  isDesktop: true,
  platform: process.platform,

  /** 开始一次导出，total 为总帧数 */
  startExport: (total) => ipcRenderer.invoke('export:start', { total }),

  /** 批量发送帧数据（startIndex 从 1 开始） */
  sendFrames: (startIndex, frames) => ipcRenderer.invoke('export:frames', { startIndex, frames }),

  /** 选择保存位置并用 ffmpeg 合成 MOV */
  finishExport: (opts) => ipcRenderer.invoke('export:finish', opts),

  /** 不弹保存对话框：直接把当前帧会话合成到 outDir/fileName（按卡分段，逐卡各出一条 MOV） */
  finishExportTo: (opts) => ipcRenderer.invoke('export:finishTo', opts),

  /** 导出时顺手写入一份文本产物（如配音脚本 .md）：只写到已选定的导出目录内 */
  writeTextFile: (opts) => ipcRenderer.invoke('export:writeTextFile', opts),

  /** 导出时顺手写一份二进制产物（如音效素材 WAV）：只写到已选定的导出目录内 */
  writeBinaryFile: (opts) => ipcRenderer.invoke('export:writeBinaryFile', opts),

  /** 选择保存位置并用 ffmpeg 把原视频 + 透明帧合成 MP4 成片 */
  finishVideoExport: (opts) => ipcRenderer.invoke('videoexport:finish', opts),

  /** 取消并清理临时帧 */
  cancelExport: () => ipcRenderer.invoke('export:cancel'),

  /** 弹出「选择目录」对话框，返回所选路径（取消返回空串）。只渲分段不导整条时用它定输出目录 */
  pickDir: (title) => ipcRenderer.invoke('export:pickDir', title),

  /** 导出前先选保存位置（选好再开渲，避免渲完才弹对话框、一取消就白渲）；取消返回空串 */
  pickSave: (opts) => ipcRenderer.invoke('export:pickSave', opts),

  /** 在文件管理器中定位文件 */
  showItem: (p) => ipcRenderer.invoke('shell:showItem', p),

  /** 应用信息（版本 / ffmpeg 路径 / 完整性） */
  appInfo: () => ipcRenderer.invoke('app:info'),

  /** 客户端完整性：核心文件是否被改动过（false ⇒ 本会话强制按基础版运行） */
  integrity: () => ipcRenderer.invoke('app:integrity'),

  /** 主进程权威 PRO 判定（第②层：门控下沉主进程），返回 { pro: boolean | null } */
  isPro: () => ipcRenderer.invoke('app:isPro'),

  /** 检查更新：拉取云端版本清单并与本地版本比对（未配置地址时不联网） */
  checkUpdate: () => ipcRenderer.invoke('update:check'),

  /** 下载更新包到临时目录，进度走 onUpdateProgress */
  downloadUpdate: (opts) => ipcRenderer.invoke('update:download', opts),

  /** 应用轻量增量包：校验 → 备份 → 覆盖 resources/app → 重启（体积仅几百 KB） */
  applyCodeUpdate: (opts) => ipcRenderer.invoke('update:applyCode', opts),

  /** 监听更新包下载进度 */
  onUpdateProgress: (cb) => ipcRenderer.on('update:progress', (_e, p) => cb(p)),
  offUpdateProgress: (cb) => ipcRenderer.removeListener('update:progress', cb),

  /** 用系统默认浏览器打开链接（更新页 / 官网等） */
  openExternal: (url) => ipcRenderer.invoke('shell:openExternal', url),

  /** 打开「激活 PRO」独立窗口 */
  openActivationWindow: () => ipcRenderer.invoke('activation:open'),

  /** 隐藏「激活 PRO」独立窗口（点「完成」时用，避免直接 window.close() 连带关闭主窗口） */
  closeActivationWindow: () => ipcRenderer.send('activation:close'),

  /** 激活窗口：把内容实际需要的高度回报主进程，主进程据此收紧窗口（专业版内容比基础版矮近 300px） */
  reportActivationHeight: (height) => ipcRenderer.send('activation:content-height', height),

  /** 通知主进程：激活状态已变更，请刷新各窗口 PRO 标识 */
  notifyEditionChanged: () => ipcRenderer.send('edition:changed'),

  /** 监听激活状态刷新通知（激活窗口操作后主窗口需同步） */
  onEditionRefresh: (cb) => ipcRenderer.on('edition:refresh', (_e) => cb()),
  offEditionRefresh: (cb) => ipcRenderer.removeListener('edition:refresh', cb),

  /** 音乐库：保存上传的音频，返回文件名 */
  saveMusic: (name, ext, data) => ipcRenderer.invoke('music:save', { name, ext, data }),
  /** 音乐库：列出已保存的音乐 */
  listMusic: () => ipcRenderer.invoke('music:list'),
  /** 音乐库：删除已保存的音频 */
  deleteMusic: (file) => ipcRenderer.invoke('music:delete', { file }),

  /** 取 File 对象的磁盘路径（源视频持久化用） */
  getPathForFile: (file) => {
    try {
      return webUtils.getPathForFile(file)
    } catch {
      return ''
    }
  },
  /** 注册源视频原路径，返回 token（之后可用 /video?token= 播放） */
  registerVideo: (filePath) => ipcRenderer.invoke('video:register', filePath),
  /** 视频分析：用 ffmpeg 抽帧生成缩略图序列 + 解码音频生成波形峰谷（真实解析，还原剪映观感）。
   *  App.tsx 通过 window.vfx.video.probe(原路径, {thumbs,wave}) 调用；缺失这一层会导致导入静默失败。 */
  video: {
    probe: (filePath, opts) => ipcRenderer.invoke('video:probe', filePath, opts),
  },
  /** 示例工程：把打包内的示例素材 seed 到 userData 并注册 token，返回 文件名 → token 映射 */
  sampleMedia: () => ipcRenderer.invoke('sample:media'),

  /** 编排自动保存（写入 userData/autosave.json，重启后恢复；与端口/origin 无关） */
  autosave: {
    load: () => ipcRenderer.sendSync('autosave:load') || '',
    save: (data) => ipcRenderer.send('autosave:save', data),
  },

  /** R25 草稿箱：多槽工程持久化（userData/drafts/，与端口/origin 无关）。
   *  素材只存 token 引用；保存走主进程 tmp → rename 原子写，坏档自动隔离。 */
  drafts: {
    /** 列出全部草稿元数据（按最近修改倒序），含 lastDraftId */
    list: () => ipcRenderer.invoke('drafts:list'),
    /** 新建草稿，返回 { ok, id, doc } */
    create: (arg) => ipcRenderer.invoke('drafts:create', arg),
    /** 读取单份草稿全文；损坏时返回 { ok:false, reason:'corrupt', quarantined } */
    load: (id) => ipcRenderer.invoke('drafts:load', id),
    /** 原子写整份草稿（doc 内含 project / chat / meta / media） */
    save: (arg) => ipcRenderer.invoke('drafts:save', arg),
    /** 重命名 */
    rename: (arg) => ipcRenderer.invoke('drafts:rename', arg),
    /** 复制一份草稿（深拷贝，不动素材共享池） */
    duplicate: (id) => ipcRenderer.invoke('drafts:duplicate', id),
    /** 删除草稿（只删自己的 doc 与索引条目） */
    remove: (id) => ipcRenderer.invoke('drafts:remove', id),
    /** 存缩略图（dataURL，直接写进 index 的 meta） */
    setThumb: (arg) => ipcRenderer.invoke('drafts:setThumb', arg),
    /** 记录「最近打开的草稿」 */
    setLast: (id) => ipcRenderer.invoke('drafts:setLast', id),
    /** 首启迁移旧 autosave.json + 全局 AI 对话为第一份草稿（只复制不删除旧数据） */
    migrateAutosave: () => ipcRenderer.invoke('drafts:migrateAutosave'),
    /** 素材失效检测：token → { exists, path, name } */
    resolveMedia: (arg) => ipcRenderer.invoke('drafts:resolveMedia', arg),
    /** 失效素材重新指定路径：只改 registry 映射，草稿引用不变 */
    relinkMedia: (arg) => ipcRenderer.invoke('drafts:relinkMedia', arg),
    /** 弹系统对话框选一个媒体文件，返回绝对路径 */
    pickMediaFile: (arg) => ipcRenderer.invoke('drafts:pickMediaFile', arg),
  },

  /** 历史舞台快照（写入 userData/history.json，与端口/origin 无关） */
  history: {
    load: () => ipcRenderer.sendSync('history:load') || '',
    save: (data) => ipcRenderer.send('history:save', data),
  },

  /** AI 状态键值存储（写入 userData/app-state.json，与端口/origin 无关，重启保留）。
   *  data 传空串 = 删除该键。 */
  kv: {
    load: (key) => ipcRenderer.sendSync('kv:load', key) || '',
    save: (key, data) => ipcRenderer.send('kv:save', { key, data }),
  },

  /** 系统级机器 ID（Windows MachineGuid 等，与应用版本无关，激活指纹用） */
  machineId: () => {
    try {
      return ipcRenderer.sendSync('machine:id') || ''
    } catch {
      return ''
    }
  },

  /** 窗口控制（无边框窗口自绘按钮） */
  windowControl: {
    minimize: () => ipcRenderer.send('window:minimize'),
    maximize: () => ipcRenderer.send('window:maximize'),
    close: () => ipcRenderer.send('window:close'),
    isMaximized: () => ipcRenderer.invoke('window:isMaximized'),
    /** R26：草稿箱首屏 / 编辑器 双档尺寸（home 小窗锁定最小尺寸，editor 恢复工作台尺寸） */
    setMode: (mode) => ipcRenderer.send('window:draftMode', mode === 'editor' ? 'editor' : 'home'),
    /** 返回退订函数：首屏会在 home↔editor 之间反复挂载，必须避免监听器堆积 */
    onMaximizeChange: (cb) => {
      const handler = (_e, v) => cb(v)
      ipcRenderer.on('window:maximized', handler)
      return () => ipcRenderer.removeListener('window:maximized', handler)
    },
    /** R27：编辑器态点关闭时主进程不退出，通知渲染层回草稿客户端首屏。返回退订函数。 */
    onCloseToDrafts: (cb) => {
      const handler = () => cb()
      ipcRenderer.on('window:close-to-drafts', handler)
      return () => ipcRenderer.removeListener('window:close-to-drafts', handler)
    },
  },

  /** 剪映对接：克隆信封法（读写都受限在剪映草稿目录与本地 userData 缓存两个沙盒内） */
  jianying: {
    /** 剪映草稿默认根目录（%LOCALAPPDATA%\JianyingPro\...\com.lveditor.draft），不存在也照常返回路径 */
    defaultRoot: () => ipcRenderer.invoke('jianying:defaultRoot'),
    /** 检测本机是否安装了剪映（默认索引目录存在且含 root_meta_info.json） */
    detect: () => ipcRenderer.invoke('jianying:detect'),
    /** 探测本机剪映安装信息（安装目录 / 版本号 / videoeditor.dll 路径） */
    installInfo: () => ipcRenderer.invoke('jianying:installInfo'),
    /** 从索引解析用户实际存放草稿的目录（取出现次数最多的 draft_root_path） */
    draftRoot: (metaRoot) => ipcRenderer.invoke('jianying:draftRoot', metaRoot),
    /** 让用户选取剪映草稿根目录（默认目录找不到时兜底） */
    selectFolder: () => ipcRenderer.invoke('jianying:selectFolder'),
    /** 列出剪映草稿：可按比例过滤，按最近修改时间只返回最新 10 条；
     *  返回 { drafts, total }，每条尽量带剪映版本号 appVersion（密文草稿需解密读取） */
    listDrafts: (rootPath, ratioKey) => ipcRenderer.invoke('jianying:listDrafts', rootPath, ratioKey),
    /** 把指定草稿抓为信封缓存到本地（绝不引用源文件）；同时解密出明文模板供生成时注入成片 */
    captureEnvelope: (arg) => ipcRenderer.invoke('jianying:captureEnvelope', arg),
    /** 抓取成功后按路径精确删除源草稿 */
    deleteDraft: (arg) => ipcRenderer.invoke('jianying:deleteDraft', arg),
    /** 列出已抓到的信封（按比例） */
    envelopeList: () => ipcRenderer.invoke('jianying:envelopeList'),
    /** 删除某个比例的本地信封缓存 */
    deleteEnvelope: (arg) => ipcRenderer.invoke('jianying:deleteEnvelope', arg),
    /** 以信封里的明文模板为基准注入成片 → 写回剪映草稿目录一个新草稿（结构同代，打开即播） */
    generateDraft: (arg) => ipcRenderer.invoke('jianying:generateDraft', arg),
  },
})
