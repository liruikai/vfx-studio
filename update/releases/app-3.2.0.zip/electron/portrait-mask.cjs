/* ------------------------------------------------------------------ *
 * 离线人像遮罩预计算（2026-10-28）
 *
 * 作用：对导入的源视频跑一遍本地人像分割（MODNet ONNX + onnxruntime-node，
 * 全程 CPU、零网络），产出一支灰度 mask 视频（白=人物，黑=背景），
 * 供 ① 成片导出三层合成（卡片入底 → 原视频 → 人像层）与
 * ② 舞台预览的人像层 同源取用。
 *
 * 预处理口径（portrait-test.cjs 在真实人像上验证过）：
 *   输入 512×512（拉伸），RGB 归一化到 [0,1]（仅 /255，不做 mean/std），
 *   输出 [1,1,512,512] 即 [0,1] matte。
 *
 * mask 视频编码注意：灰度走 h264 yuv420p 必须显式标 full range
 * （-color_range pc + x264 range=pc），否则按 limited range 解码会把
 * 白色压到 235 ⇒ alpha 上限 0.92，人像边缘整体发灰。
 *
 * 性能：MODNet 推理 + ffmpeg 双管道是 CPU 密集活，必须放在 worker 线程
 * （portrait-worker.cjs）跑，否则会占满主进程事件循环 → 整个客户端卡死、
 * 进度 IPC 发不出去。主进程只负责转发进度、保持 UI 响应。
 *
 * 缓存：userData/masks/<md5(路径|大小|mtime) 前16位>.mask.mp4，
 * 同一源文件（未变动）只算一次；跨重启命中缓存秒回。
 * ------------------------------------------------------------------ */
const fs = require('fs')
const path = require('path')
const crypto = require('crypto')
const { Worker } = require('worker_threads')
const { app } = require('electron')

const MODEL_FILE = 'modnet_photographic_portrait_matting.onnx'
const INFER_SIZE = 512 // MODNet 输入边长（拉伸）
const FRAME_BYTES = INFER_SIZE * INFER_SIZE * 3
const MAX_FPS = 30 // 60fps 源降采样到 30 再推理（遮罩平滑，合成端会按导出 fps 重采样）
const MIN_FPS = 8

/** bundled ffmpeg：与 main.cjs 的 ffmpegPath 同候选（dev: electron/bin，打包: resources 根） */
function ffmpegPath() {
  const candidates = [
    process.resourcesPath ? path.join(process.resourcesPath, 'ffmpeg.exe') : null,
    path.join(__dirname, 'bin', 'ffmpeg.exe'),
  ].filter(Boolean)
  for (const c of candidates) {
    if (fs.existsSync(c)) return c
  }
  return 'ffmpeg'
}

/** 模型路径：dev 与便携版都在 electron/models；NSIS 打包走 extraResources 兜底 */
function modelPath() {
  const candidates = [
    path.join(__dirname, 'models', MODEL_FILE),
    process.resourcesPath ? path.join(process.resourcesPath, 'models', MODEL_FILE) : null,
  ].filter(Boolean)
  for (const c of candidates) {
    if (fs.existsSync(c)) return c
  }
  return ''
}

/** mask 缓存落点：userData/masks/<hash>.mask.mp4（源文件未变动即命中） */
function maskCachePath(videoPath) {
  let key = 'x'
  try {
    const st = fs.statSync(videoPath)
    key = crypto
      .createHash('md5')
      .update(`${videoPath}|${st.size}|${Math.round(st.mtimeMs)}`)
      .digest('hex')
      .slice(0, 16)
  } catch {
    key = crypto.createHash('md5').update(String(videoPath)).digest('hex').slice(0, 16)
  }
  const dir = path.join(app.getPath('userData'), 'masks')
  fs.mkdirSync(dir, { recursive: true })
  return path.join(dir, `${key}.mask.mp4`)
}

/** 正在跑的 worker：用于 cancel 终止。key = 源视频路径（同一文件只应一路） */
const activeWorkers = new Map()

/**
 * 预计算入口（带缓存命中与单飞）。重活交给 portrait-worker.cjs 的 worker 线程，
 * 主进程只转发进度 → UI 不卡、进度条正常推进。
 * @param {{videoPath:string, onProgress?:(done:number,total:number,phase:string)=>void, force?:boolean}} p
 * force=true 时无视缓存重算（右键「重算」入口），rename 会覆盖旧缓存文件。
 */
async function ensureMask({ videoPath, onProgress, force }) {
  const cached = maskCachePath(videoPath)
  if (!force && fs.existsSync(cached) && fs.statSync(cached).size > 1024) {
    return { maskPath: cached, cached: true, frames: 0, ms: 0 }
  }
  const mp = modelPath()
  if (!mp) throw new Error('找不到人像模型文件（modnet ONNX）')
  const ff = ffmpegPath()
  if (!ff) throw new Error('找不到 ffmpeg 运行库')
  const tmpPath = cached.replace(/\.mask\.mp4$/, '.mask.partial.mp4')
  try { fs.rmSync(tmpPath, { force: true }) } catch { /* 不存在 */ }

  return await new Promise((resolve, reject) => {
    const worker = new Worker(path.join(__dirname, 'portrait-worker.cjs'), {
      workerData: { videoPath, outPath: tmpPath, ffmpegPath: ff, modelPath: mp },
    })
    let settled = false
    activeWorkers.set(videoPath, worker)
    const cleanup = () => activeWorkers.delete(videoPath)

    worker.on('message', (m) => {
      if (!m || !m.type) return
      if (m.type === 'progress') {
        onProgress?.(m.done, m.total, m.phase)
      } else if (m.type === 'done') {
        if (settled) return
        try {
          fs.renameSync(tmpPath, cached) // 原子落盘：半途失败不会留下坏缓存
        } catch (e) {
          settled = true; cleanup(); worker.terminate().catch(() => {})
          reject(e)
          return
        }
        settled = true; cleanup()
        worker.terminate().catch(() => {})
        // ⚠️ 返回改名后的最终缓存路径，不能用 tmpPath（已被 rename 掉）
        resolve({ maskPath: cached, frames: m.frames || 0, ms: m.ms || 0, cached: false })
      } else if (m.type === 'error') {
        if (settled) return
        settled = true; cleanup()
        worker.terminate().catch(() => {})
        reject(new Error(m.message || '人像预计算失败'))
      }
    })
    worker.on('error', (e) => {
      if (settled) return
      settled = true; cleanup()
      reject(e)
    })
    worker.on('exit', (code) => {
      // 取消（terminate）或崩溃都会走这里；done/error 已 settle 则忽略
      if (settled) return
      settled = true; cleanup()
      reject(new Error(code === 1 ? '已取消' : `人像预计算进程异常退出（code ${code}）`))
    })
  })
}

/** 取消：终止所有正在跑的 worker（关闭项目 / 主动取消时调用） */
function cancel() {
  for (const w of activeWorkers.values()) {
    try { w.terminate() } catch { /* 已退出 */ }
  }
  activeWorkers.clear()
}

module.exports = { ensureMask, maskCachePath, modelPath, ffmpegPath, cancel }
