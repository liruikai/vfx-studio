/**
 * VFX STUDIO 桌面客户端主进程
 * - 打开应用窗口（内置 Chromium，不依赖用户浏览器）
 * - 生产模式用内置本地服务器加载页面（file:// 会拦截 ES module）
 * - 通过 IPC 接收渲染进程产出的透明 PNG 帧
 * - 调用内置 ffmpeg 合成 ProRes 4444 透明 MOV
 */
const { app, BrowserWindow, ipcMain, dialog, shell, nativeTheme, screen, Menu } = require('electron')
// 任务栏归属：与 electron-builder 的 appId 一致。
// 不设置的话 Windows 会按 exe 元数据（手工拼装的便携版是 "Electron"）显示悬停提示与分组。
app.setAppUserModelId('com.vfxstudio.overlay')
const path = require('node:path')
const fs = require('node:fs')
const fsp = require('node:fs/promises')
const os = require('node:os')
const http = require('node:http')
const crypto = require('node:crypto')
const { execFile, spawn } = require('node:child_process')

// 第②层 PRO 门控（主进程权威版）：验签 / 机器码 / PRO 卡种集合。
// 机器码提供方用主进程自身的 systemMachineId（与 renderer 桌面端同源），保证验签口径一致。
/**
 * PRO 门控模块：优先加载 V8 字节码 pro-gate.jsc（源码不可读，防「读懂逻辑后改 isPro / 删 exp 判断」）；
 * 只有字节码与当前 Electron/V8 不兼容（cachedDataRejected）时才回退 pro-gate.cjs。
 * 两个文件都在 dist/integrity.json 签名清单内 ⇒ 改任何一个都会被启动校验拦下。
 */
let proGateMode = 'jsc'
const proGate = (() => {
  try {
    require('bytenode')
    return require('./pro-gate.jsc')
  } catch (e) {
    proGateMode = 'cjs(fallback)'
    console.error('[pro-gate] 字节码加载失败，回退 pro-gate.cjs：', e && e.message)
    return require('./pro-gate.cjs')
  }
})()
proGate.setMachineIdProvider(systemMachineId)

const isDev = !app.isPackaged
/** @type {BrowserWindow | null} */
let win = null
/** @type {BrowserWindow | null} */
let activationWin = null
/** 真正退出应用时才允许激活窗口关闭；平时点「完成」/关闭按钮只隐藏，避免连带关闭主窗口 */
let activationAllowClose = false
/** @type {import('node:http').Server | null} */
let staticServer = null
/** 本地静态服务器端口（激活窗口复用同一服务器） */
let serverPort = 0

/* ------------------------------------------------------------------ *
 * R26：草稿箱首屏 / 编辑器 双档窗口尺寸
 *  - 首屏默认小窗，且这个尺寸同时就是首屏的「最小尺寸」：只能放大、不能缩小。
 *  - 打开草稿自动恢复到编辑器工作台尺寸；返回首屏再回到用户调过的首屏尺寸。
 *  - 两档各自记住用户手动放大的宽高，切换时只重置尺寸、不动 userData。
 * ------------------------------------------------------------------ */
const DRAFT_HOME_WIN = { width: 1040, height: 765 }
let winMode = 'home'
/** @type {{w:number,h:number}|null} */
let homeWinSize = null
/** @type {{w:number,h:number}|null} */
let editorWinSize = null
/**
 * R27：编辑器态点「关闭」时，先拦下来通知渲染层回草稿客户端首屏。
 * 置位期间再点一次关闭则视为「确实要退出」（渲染层无响应时的逃生口）。
 */
let closeToDraftsPending = false

function draftWindowSizes() {
  const area = screen.getPrimaryDisplay().workAreaSize
  return {
    area,
    home: {
      w: Math.min(DRAFT_HOME_WIN.width, Math.max(880, area.width - 40)),
      h: Math.min(DRAFT_HOME_WIN.height, Math.max(560, area.height - 40)),
    },
    editor: {
      w: Math.min(1620, Math.max(1100, area.width - 40)),
      h: Math.min(980, Math.max(680, area.height - 40)),
    },
  }
}

/** 切换窗口档位；同一档位重复调用只刷新最小尺寸，避免每次刷新列表都跳窗口 */
function applyDraftWindowMode(mode) {
  if (!win || win.isDestroyed()) return
  const next = mode === 'editor' ? 'editor' : 'home'
  // 回到首屏 = 本次「关闭转跳草稿箱」已完成，清掉拦截标志
  if (next === 'home') closeToDraftsPending = false
  const sz = draftWindowSizes()
  const minW = next === 'home' ? sz.home.w : Math.min(1540, sz.editor.w)
  const minH = next === 'home' ? sz.home.h : Math.min(680, sz.editor.h)
  if (winMode === next) {
    win.setMinimumSize(minW, minH)
    return
  }
  const wasMaximized = win.isMaximized()
  if (wasMaximized) win.unmaximize()
  const cur = win.getBounds()
  // 记住离开那一档时用户手动调整过的尺寸（只放大不缩小的语义靠 min 尺寸保证）
  if (winMode === 'home') homeWinSize = { w: Math.max(sz.home.w, cur.width), h: Math.max(sz.home.h, cur.height) }
  else editorWinSize = { w: Math.max(sz.editor.w, cur.width), h: Math.max(sz.editor.h, cur.height) }
  winMode = next
  const saved = next === 'home' ? homeWinSize : editorWinSize
  const base = next === 'home' ? sz.home : sz.editor
  const w = Math.min(sz.area.width - 20, Math.max(saved ? saved.w : base.w, base.w))
  const h = Math.min(sz.area.height - 20, Math.max(saved ? saved.h : base.h, base.h))
  win.setMinimumSize(minW, minH)
  win.setSize(w, h)
  win.center()
}

/**
 * 应用图标（窗口左上角 / 任务栏 / 快捷方式）。
 * public/icon.ico 会被 vite 原样拷进 dist，主进程在 electron/ 下，故取 ../dist/icon.ico。
 */
const APP_ICON = path.join(__dirname, '..', 'dist', 'icon.ico')


// 客户端完整性自校验（2026-10-16，防破解第一层）。配套脚本：scripts/sign-integrity.cjs
//
// 背景：打包用的是 asar:false ⇒ resources/app 是明文目录，改 dist 里的版本判断 / 换掉内置
// 公钥自签激活码都很廉价（AI 辅助下尤其）。签名清单让「改文件」这件事必须在加载界面之前
// 就被发现：改 dist ⇒ 哈希不符 ⇒ 不加载应用界面（被改的代码根本没机会运行）。
//
// 校验侧只用公钥（公开信息）；私钥只在开发者机器上，所以伪造清单做不到。
// ⚠️ 本文件自身也在清单里 ⇒ 改这里的公钥 / 删掉校验逻辑，同样会让哈希不符。
const INTEGRITY_PUBKEY_PEM = `-----BEGIN PUBLIC KEY-----
MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE1ShQHULsoWvG771ufhVoZkJO4x+X
JjIHUjYGEdFd+LAZ2LfMXR3bZxA2UoHIertqLM76e7XDjg624G9xApYagQ==
-----END PUBLIC KEY-----`

/** @type {boolean} fail-closed：清单缺失 / 验签失败 / 任一文件不符 ⇒ false */
let integrityOk = true
/** @type {string} 失败原因（只写进日志，绝不弹给用户，避免给破解者反馈） */
let integrityReason = 'not-checked'

/** 与 scripts/sign-integrity.cjs 的 canonical() 严格同构：顺序无关、内容一变就换签名 */
function canonicalIntegrity(files) {
  const lines = ['vfx-integrity-v1']
  for (const rel of Object.keys(files).sort()) lines.push(`${rel}|${files[rel].h}|${files[rel].s}`)
  return lines.join('\n')
}

/**
 * 校验 dist/integrity.json 与磁盘实际文件是否一致。
 * 仅开发态（vite dev server，没有 dist 清单）放行。
 * ⚠️ 2026-11-02 安全加固：原先 `VFX_NO_INTEGRITY=1` 与 isDev 并列放行，等于正式包带一个
 *    环境变量就能关掉整套校验（一条快捷方式参数即可破解）。已改为只认 isDev。
 */
function verifyIntegrity() {
  if (isDev) return { ok: true, reason: 'skipped' }
  const mfPath = path.join(__dirname, '..', 'dist', 'integrity.json')
  try {
    const mf = JSON.parse(fs.readFileSync(mfPath, 'utf8'))
    if (!mf || typeof mf.files !== 'object' || typeof mf.sig !== 'string') {
      return { ok: false, reason: 'manifest-invalid' }
    }
    const v = crypto.createVerify('SHA256')
    v.update(canonicalIntegrity(mf.files), 'utf8')
    if (!v.verify(INTEGRITY_PUBKEY_PEM, Buffer.from(mf.sig, 'base64'))) {
      return { ok: false, reason: 'sig-invalid' }
    }
    for (const rel of Object.keys(mf.files)) {
      const full = path.join(__dirname, '..', rel)
      if (!fs.existsSync(full)) return { ok: false, reason: `missing:${rel}` }
      const st = fs.statSync(full)
      if (st.size !== mf.files[rel].s) return { ok: false, reason: `size:${rel}` }
      const h = crypto.createHash('sha256').update(fs.readFileSync(full)).digest('hex')
      if (h !== mf.files[rel].h) return { ok: false, reason: `hash:${rel}` }
    }
    return { ok: true, reason: 'ok' }
  } catch {
    return { ok: false, reason: 'manifest-unreadable' }
  }
}

/** 校验没过时显示的替代页（不加载应用界面 ⇒ 被改的前端代码没有执行机会） */
const INTEGRITY_ERROR_HTML = `<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><title>MOCUT</title>
<style>
body{margin:0;height:100vh;display:flex;align-items:center;justify-content:center;
background:#16161a;color:#e8e6e1;font-family:system-ui,-apple-system,sans-serif}
.box{max-width:460px;padding:28px 32px;border-radius:14px;background:#1f1f24;line-height:1.7}
h1{margin:0 0 12px;font-size:17px;font-weight:500}
p{margin:8px 0;font-size:13px;color:#b9b6b0}
</style></head><body><div class="box">
<h1>客户端完整性校验未通过</h1>
<p>程序文件与官方签发的不一致（可能被修改或损坏），已停止加载。</p>
<p>请卸载后从官方渠道重新安装 MOCUT；若重装仍如此，请把 userData 下的 startup.log 发给开发者。</p>
</div></body></html>`

function loadIntegrityErrorPage(w) {
  try {
    const p = path.join(app.getPath('userData'), 'integrity-error.html')
    fs.writeFileSync(p, INTEGRITY_ERROR_HTML)
    w.loadFile(p)
  } catch {
    /* 写不出来就算了（窗口保持空白，也不会加载被改的界面） */
  }
}

/**
 * 第②层 PRO 门控的「导出边界」判定：给定本次导出涉及的卡种集合，
 * 返回是否放行 + 应被剔除的 pro 卡种。
 * - 仅开发态：主进程不强制拦截（本地调试交给 renderer 自决），放行（VFX_NO_INTEGRITY 后门已移除）。
 * - 生产态：独立用主进程持有的激活码验签（不信任 renderer 的布尔），
 *   BASE 态下含 pro 卡即 fail-closed 拦截。
 */
async function exportProOk(kinds) {
  if (isDev) return { ok: true, pro: null, blocked: [] }
  const pro = await proGate.isPro(loadAppState(), { clockSuspect })
  const blocked = proGate.blockedKinds(kinds, pro)
  return { ok: blocked.length === 0, pro, blocked }
}

// 浏览器类快捷键护栏（Ctrl+Shift+I 等）：分组开关在 electron/shortcutGuard.cjs
// ⚠️ 独立文件，已在 scripts/sync-portable.cjs 同步清单里 —— 漏同步客户端会 require 不到直接打不开
const shortcutGuard = require('./shortcutGuard.cjs')
/** 给窗口装护栏（开发模式放行，方便调试） */
function installWebShortcutGuard(wc) {
  const on = !isDev
  shortcutGuard.installWebShortcutGuard(wc, on)
  // 写进启动日志：① 证明模块真被加载（漏同步会直接崩，日志停在更前面）
  //             ② 便于用户报障时确认当前客户端生效的是哪套开关
  logStartup('shortcut guard installed:', on ? 'ON' : 'off(dev)', JSON.stringify(shortcutGuard.SHORTCUT_GUARD))
}

/**
 * 启动诊断日志：写到 userData/startup.log。
 * 客户端「打不开」时，把这份日志发给开发者即可定位卡在哪个阶段
 * （app 未就绪 / 窗口未创建 / 页面未加载 / 渲染进程崩溃）。
 */
function logStartup(...args) {
  try {
    const p = path.join(app.getPath('userData'), 'startup.log')
    fs.appendFileSync(p, `[${new Date().toISOString()}] ${args.join(' ')}\n`)
  } catch {
    /* 忽略 */
  }
}

/**
 * 是否运行在「已安装模式」。
 * 判据：exe 同目录存在 NSIS 生成的 Uninstall 程序（便携版没有）。
 * 用来区分「安装包装的版本」与「免安装解压版」——只有前者才自动补快捷方式。
 */
function isInstalledMode() {
  if (process.platform !== 'win32') return false
  try {
    const dir = path.dirname(process.execPath)
    return fs
      .readdirSync(dir)
      .some((f) => f.toLowerCase().startsWith('uninstall') && f.toLowerCase().endsWith('.exe'))
  } catch {
    return false
  }
}

/**
 * 桌面 / 开始菜单快捷方式兜底（2026-09-28）
 *
 * 背景：electron-builder 的 NSIS 模板在「覆盖安装」时走 keepShortcuts 分支，
 * 若旧快捷方式本来就不存在，模板既不新建也不重建 → 装完桌面没有图标。
 * build/installer.nsh 的 customInstall 已无条件补建，这里再兜一层：
 * 应用每次启动自检，安装模式下发现快捷方式缺失就直接补上（已存在则不动，
 * 尊重用户手动删除以外的意外丢失）。
 *
 * 便携版不触发（避免往用户桌面乱写东西）。
 */
function ensureShortcuts() {
  if (!isInstalledMode()) return
  const exe = process.execPath
  const dir = path.dirname(exe)
  const targets = []
  try {
    targets.push(path.join(app.getPath('desktop'), '魔卡MOCUT.lnk'))
  } catch {
    /* 忽略 */
  }
  try {
    targets.push(
      path.join(
        app.getPath('appData'),
        'Microsoft',
        'Windows',
        'Start Menu',
        'Programs',
        '魔卡MOCUT.lnk'
      )
    )
  } catch {
    /* 忽略 */
  }
  for (const lnk of targets) {
    if (fs.existsSync(lnk)) continue
    try {
      shell.writeShortcutLink(lnk, 'create', {
        target: exe,
        cwd: dir,
        icon: exe,
        iconIndex: 0,
        description: '魔卡MOCUT 视频特效创作工作台'
      })
      logStartup('shortcut created:', lnk)
    } catch (err) {
      logStartup('shortcut failed:', lnk, String((err && err.message) || err))
    }
  }
}

/** 音乐保存目录（随应用数据持久化） */
function musicDir() {
  const d = path.join(app.getPath('userData'), 'music')
  if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true })
  return d
}

/** 定位 ffmpeg：打包后在 resources，开发时用项目内置，兜底走系统 PATH。
 *  ⚠️ 便携版（免安装）未走 electron-builder 打包，app.isPackaged 为 false，但 ffmpeg
 *  同样放在 <exe目录>/resources/ffmpeg.exe —— 故不再用 isPackaged 门控，始终先试该位置；
 *  开发态该路径不存在会自动落到 __dirname/bin（项目内置）。 */
function ffmpegPath() {
  const candidates = [
    path.join(process.resourcesPath, 'ffmpeg.exe'),
    path.join(__dirname, 'bin', 'ffmpeg.exe'),
  ]
  for (const c of candidates) {
    if (fs.existsSync(c)) return c
  }
  return 'ffmpeg'
}

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
  '.bmp': 'image/bmp',
  '.avif': 'image/avif',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.mp4': 'video/mp4',
  '.webm': 'video/webm',
  '.mov': 'video/quicktime',
  '.m4v': 'video/x-m4v',
  '.srt': 'text/plain; charset=utf-8',
}

/** 最近媒体注册表：token → 文件路径（用于刷新/重启后恢复源视频） */
function mediaRegistryPath() {
  return path.join(app.getPath('userData'), 'media-registry.json')
}

function loadMediaRegistry() {
  try {
    return JSON.parse(fs.readFileSync(mediaRegistryPath(), 'utf8'))
  } catch {
    return {}
  }
}

function saveMediaRegistry(reg) {
  fs.writeFileSync(mediaRegistryPath(), JSON.stringify(reg, null, 2))
}

/**
 * 编排自动保存文件：存在 userData 下。
 * 不用 localStorage 的原因：生产模式本地服务器每次随机端口，页面 origin 每次都变，
 * localStorage 按 origin 隔离 → 换端口就取不到旧数据（重启看似被清空）。
 */
function autosavePath() {
  return path.join(app.getPath('userData'), 'autosave.json')
}

/** 「历史舞台」快照文件：同样放 userData，与页面 origin 无关 */
function historyPath() {
  return path.join(app.getPath('userData'), 'history.json')
}

/** 带 Range 支持的文件流（视频拖动进度需要） */
function serveWithRange(req, res, filePath) {
  let stat
  try {
    stat = fs.statSync(filePath)
  } catch {
    res.writeHead(404)
    res.end()
    return
  }
  const mime = MIME[path.extname(filePath).toLowerCase()] || 'application/octet-stream'
  const range = req.headers.range
  if (range) {
    const m = /bytes=(\d*)-(\d*)/.exec(range)
    let start = m && m[1] ? parseInt(m[1], 10) : 0
    let end = m && m[2] ? parseInt(m[2], 10) : stat.size - 1
    if (Number.isNaN(start)) start = 0
    if (Number.isNaN(end) || end >= stat.size) end = stat.size - 1
    if (start > end) {
      res.writeHead(416, { 'Content-Range': `bytes */${stat.size}` })
      res.end()
      return
    }
    res.writeHead(206, {
      'Content-Range': `bytes ${start}-${end}/${stat.size}`,
      'Accept-Ranges': 'bytes',
      'Content-Length': end - start + 1,
      'Content-Type': mime,
    })
    fs.createReadStream(filePath, { start, end }).pipe(res)
  } else {
    res.writeHead(200, {
      'Accept-Ranges': 'bytes',
      'Content-Length': stat.size,
      'Content-Type': mime,
    })
    fs.createReadStream(filePath).pipe(res)
  }
}

/** 起一个本地服务器：/ 服务 dist 页面，/music/<file> 服务已保存的音乐 */
function startStaticServer(root) {
  return new Promise((resolve, reject) => {
    const server = http.createServer((req, res) => {
      try {
        let rel = decodeURIComponent(new URL(req.url || '/', 'http://localhost').pathname)
        if (rel === '/' || rel === '') rel = '/index.html'

        // 源视频路由（token → 原文件路径，支持 Range 以便拖动进度）
        // /img 是同一通道的别名：image-wall-1 的图片素材也走 token，同源加载才不会污染导出 canvas
        if (rel === '/video' || rel === '/img') {
          const u = new URL(req.url || '/', 'http://localhost')
          const token = u.searchParams.get('token')
          const reg = loadMediaRegistry()
          const p = token ? reg[token] : null
          if (!p || !fs.existsSync(p)) {
            res.writeHead(404)
            res.end('not found')
            return
          }
          serveWithRange(req, res, p)
          return
        }

        // 音乐文件路由（来自 userData/music 目录）
        if (rel.startsWith('/music/')) {
          /* R63-3：改走 serveWithRange。
             旧写法「回 200 全量 + 谎报 Accept-Ranges: bytes」会让 <audio> 每次 seek
             （起播定位、拖动播放头、轨道片段起播）都只能从字节 0 重新整包下载再丢弃，
             表现为起播有延迟、播放中反复缓冲 —— 听感就是「一卡一卡」。
             视频走 /video?token 早就是 206 分片，音频这条补齐后就同源了。 */
          serveWithRange(req, res, path.join(musicDir(), path.basename(rel)))
          return
        }

        const file = path.join(root, rel)
        if (!path.resolve(file).startsWith(path.resolve(root))) {
          res.writeHead(403)
          res.end('forbidden')
          return
        }
        fs.readFile(file, (err, data) => {
          if (err) {
            res.writeHead(404)
            res.end('not found')
            return
          }
          res.writeHead(200, { 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream' })
          res.end(data)
        })
      } catch (e) {
        res.writeHead(500)
        res.end(String(e))
      }
    })
    server.on('error', reject)
    server.listen(0, '127.0.0.1', () => {
      staticServer = server
      serverPort = server.address().port
      resolve(serverPort)
    })
  })
}

async function createWindow() {
  // R26：启动即草稿箱首屏 ⇒ 默认开小窗，这个尺寸同时是首屏最小尺寸（只能放大、不能缩小）。
  // 打开草稿时渲染进程发 window:draftMode('editor')，由 applyDraftWindowMode 恢复工作台尺寸。
  const sz = draftWindowSizes()
  const width = sz.home.w
  const height = sz.home.h
  logStartup('createWindow: workArea', `${sz.area.width}x${sz.area.height}`, '-> home', `${width}x${height}`)
  win = new BrowserWindow({
    width,
    height,
    minWidth: width,
    minHeight: height,
    center: true,
    // ⚠️ 圆角关键点：frameless 窗口若设不透明 backgroundColor，Windows 11 的 DWM
    // 在「拖拽/缩放」时会把四角抖回直角。改成全透明背景后，DWM 始终保留圆角；
    // 深色外观由渲染进程 .app（var(--bg-page)）兜底绘制，仅四角透明露出桌面。
    backgroundColor: '#00000000',
    roundedCorners: 'on',
    title: 'MOCUT 视频特效创作工作台',
    icon: APP_ICON,
    autoHideMenuBar: true,
    // Windows 下无边框，由渲染进程自绘「缩小/最大化/关闭」按钮
    frame: process.platform !== 'win32',
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
  })

  // 屏蔽浏览器类快捷键（Ctrl+Shift+I 弹出 DevTools 等）：必须在任何页面交互之前装好
  installWebShortcutGuard(win.webContents)

  // 最大化状态回传渲染进程，用于切换「最大化/还原」图标
  win.on('maximize', () => win?.webContents.send('window:maximized', true))
  win.on('unmaximize', () => win?.webContents.send('window:maximized', false))

  // 主窗口关闭时，真正销毁激活窗口；否则若激活窗口只是隐藏，会导致 window-all-closed 不触发。
  // ★ R27：编辑器态（winMode==='editor'）第一次点关闭不退出应用，改为回草稿客户端首屏。
  //   渲染层收到 window:close-to-drafts → backToHome() → 发 window:draftMode('home')，
  //   由 applyDraftWindowMode 清掉 closeToDraftsPending。首屏态关闭才真正退出。
  win.on('close', (e) => {
    if (winMode === 'editor' && !closeToDraftsPending) {
      e.preventDefault()
      closeToDraftsPending = true
      try { win.webContents.send('window:close-to-drafts') } catch { closeToDraftsPending = false }
      return
    }
    activationAllowClose = true
    if (activationWin && !activationWin.isDestroyed()) {
      activationWin.destroy()
      activationWin = null
    }
  })

  // 渲染进程崩溃 / 消失：记录日志并弹原生提示，便于定位「白屏/打不开」
  win.webContents.on('did-finish-load', () => logStartup('did-finish-load'))
  win.webContents.on('render-process-gone', (_e, det) => {
    logStartup('render-process-gone:', det?.reason || 'unknown')
    dialog.showErrorBox(
      '渲染进程已崩溃',
      `原因：${det?.reason || '未知'}\n\n请重新打开 MOCUT。若反复出现，请把 userData 下的 startup.log 发给开发者。`,
    )
  })

  // ⚠️ 完整性没过 ⇒ 只加载说明页，**绝不能**走到下面的 loadURL：
  //    一旦加载了 dist，被改过的渲染层代码就有了执行机会，校验就白做了。
  if (!integrityOk) {
    logStartup('load: integrity FAILED -> error page')
    loadIntegrityErrorPage(win)
  } else if (isDev) {
    logStartup('load: dev http://localhost:5173')
    win.loadURL('http://localhost:5173')
  } else {
    const port = await startStaticServer(path.join(__dirname, '..', 'dist'))
    logStartup('load: http://127.0.0.1:' + port + '/index.html')
    win.loadURL(`http://127.0.0.1:${port}/index.html`)
  }

  win.on('closed', () => {
    win = null
  })
}

/** 创建「版本与激活」独立窗口 */
async function createActivationWindow() {
  if (activationWin) {
    activationWin.show()
    activationWin.focus()
    return
  }
  // 基础版要展示「价格 + 首发说明」，内容比原来长（实测内容高约 941px）；
  // 专业版没有价格区 / 激活输入框，内容矮很多（约 600px）⇒ 不再固定死高度，
  // 先给一个够基础版用的初值，渲染进程量出真实内容高后再收紧（见 activation:content-height）。
  // ⚠️ minHeight 必须留得比「专业版内容高」还小，否则 setContentSize 会被它卡住、收不紧。
  const area = screen.getPrimaryDisplay().workAreaSize
  activationWin = new BrowserWindow({
    width: 560,
    height: Math.min(960, Math.max(620, area.height - 80)),
    minWidth: 480,
    minHeight: 460,
    backgroundColor: '#14161c',
    title: '版本与激活',
    icon: APP_ICON,
    autoHideMenuBar: true,
    resizable: true,
    frame: true,
    center: true,
    parent: win ?? undefined,
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
  })

  // 屏蔽浏览器类快捷键：激活窗口同样要护住（里面有激活码输入框）
  installWebShortcutGuard(activationWin.webContents)

  // 确保窗口一定可见并置顶于主窗口之前（曾出现过点了没反应像「没打开」的反馈）
  activationWin.once('ready-to-show', () => {
    if (!activationWin) return
    activationWin.show()
    activationWin.focus()
  })

  // 固定系统标题栏为「版本与激活」：index.html 的 <title> 加载后不再覆盖
  activationWin.on('page-title-updated', (e) => e.preventDefault())

  if (!integrityOk) {
    // 与主窗口同口径：完整性没过就不加载应用界面（否则激活窗口是绕过口）
    loadIntegrityErrorPage(activationWin)
  } else if (isDev) {
    await activationWin.loadURL('http://localhost:5173/?activation=1')
  } else {
    if (!serverPort) await startStaticServer(path.join(__dirname, '..', 'dist'))
    await activationWin.loadURL(`http://127.0.0.1:${serverPort}/index.html?activation=1`)
  }

  // 点右上角关闭或渲染进程调用 window.close() 时，默认只隐藏不复用；
  // 只有主窗口关闭 / 应用退出时 allowClose=true 才真正销毁。
  activationWin.on('close', (e) => {
    if (activationAllowClose || !activationWin) return
    e.preventDefault()
    activationWin.hide()
  })
}

// 单实例锁：避免用户多次双击堆积出多个无边框窗口（互相盖住、像「打不开」）
if (!app.requestSingleInstanceLock()) {
  app.quit()
} else {
  app.on('second-instance', () => {
    if (win) {
      if (win.isMinimized()) win.restore()
      win.focus()
    }
  })

  app.whenReady().then(() => {
    // 移除 Electron 出厂菜单栏（Alt 呼出的 File/Edit/View/…）：
    // ① 无边框自绘 UI 里挂一条系统菜单栏不搭；② 菜单里自带
    //    「Reload / Toggle Developer Tools / Zoom」等项，是快捷键之外的第二条后门。
    //    开发模式保留（调试要用）。
    if (!isDev) Menu.setApplicationMenu(null)
    // 深色模式：让 Windows 原生标题栏跟随深色（titleBarOverlay 之外的双保险）
    nativeTheme.themeSource = 'dark'
    logStartup('app ready')
    // 记录本次实际加载的是字节码还是回退源码（排查「加固到底生效没」的唯一可靠依据）
    logStartup(
      'boot mode:',
      global.__vfxBootMode || 'main.cjs(no-bootstrap)',
      '| pro-gate:',
      proGateMode,
    )
    // 时钟回拨检测必须在门控之前：它决定本会话「期限码」是否按已到期处理
    touchClockGuard()
    // 完整性校验必须在 createWindow 之前：它决定到底加载应用界面还是错误页
    const ig = verifyIntegrity()
    integrityOk = ig.ok
    integrityReason = ig.reason
    logStartup('integrity:', ig.ok ? 'ok' : `FAIL(${ig.reason})`)
    ensureShortcuts()
    void createWindow()
    app.on('activate', () => {
      if (BrowserWindow.getAllWindows().length === 0) void createWindow()
    })
  })
}

app.on('before-quit', () => {
  activationAllowClose = true
  if (activationWin && !activationWin.isDestroyed()) {
    activationWin.destroy()
    activationWin = null
  }
})

app.on('window-all-closed', () => {
  if (staticServer) {
    staticServer.close()
    staticServer = null
  }
  if (process.platform !== 'darwin') app.quit()
})

/* ------------------------------------------------------------------ *
 * 导出：透明 PNG 帧 → ffmpeg → ProRes 4444 透明 MOV
 * ------------------------------------------------------------------ */

/** 当前导出会话 */
let session = null // { dir: string, total: number, digits: number }

async function cleanupSession() {
  if (session) {
    try {
      await fsp.rm(session.dir, { recursive: true, force: true })
    } catch {
      /* 忽略清理失败 */
    }
    session = null
  }
}

function runFfmpeg(args) {
  return new Promise((resolve, reject) => {
    execFile(ffmpegPath(), args, { maxBuffer: 1024 * 1024 * 64 }, (err, _stdout, stderr) => {
      if (err) {
        const tail = String(stderr || err.message).trim().split('\n').slice(-6).join('\n')
        reject(new Error(tail || 'ffmpeg 执行失败'))
      } else {
        resolve()
      }
    })
  })
}

/** 探测视频是否含音轨（ffmpeg -i 会往 stderr 打印流信息，退出码非 0 属正常） */
function probeHasAudio(filePath) {
  return new Promise((resolve) => {
    execFile(
      ffmpegPath(),
      ['-hide_banner', '-i', filePath],
      { maxBuffer: 1024 * 1024 * 8, timeout: 20000 },
      (_err, _stdout, stderr) => {
        resolve(/Stream #\d+:\d+(?:\[0x[0-9a-f]+\])?(\([a-z]{3}\))?: Audio:/.test(String(stderr || '')))
      },
    )
  })
}

ipcMain.handle('export:start', async (_e, { total }) => {
  await cleanupSession()
  const dir = await fsp.mkdtemp(path.join(os.tmpdir(), 'vfx-frames-'))
  session = { dir, total, digits: String(total).length }
  return { dir }
})

/**
 * 渲染层帧接收。每帧写入 frame_* 序列，主进程合成时叠在原视频/底板之上。
 */
ipcMain.handle('export:frames', async (_e, { startIndex, frames }) => {
  if (!session) throw new Error('导出会话不存在，请重新开始')
  for (let i = 0; i < frames.length; i++) {
    const name = `frame_${String(startIndex + i).padStart(session.digits, '0')}.png`
    await fsp.writeFile(path.join(session.dir, name), Buffer.from(frames[i]))
  }
  return true
})

/**
 * ProRes 4444 透明 MOV 的 ffmpeg 参数（export:finish 与 export:finishTo 共用）。
 * 抽出来是为了保证「弹窗保存」与「直写目录」两条路的输出编码完全一致，
 * 否则分段导出的 N 条素材里只要有一条编码不同，剪映就可能出现某段不透明。
 *
 * 2026-10-16 备注：曾尝试换更小体积的编码（qtrle/PNG 只要 11% 体积且无损），
 * 但剪映官方支持列表只有 H.264/H.265/ProRes 422/4444，前者一律不认；
 * H.264/H.265 又没有 alpha 通道。**带透明通道进剪映只会是 ProRes 4444**，
 * 故维持现状，不要再动编码。
 */
/**
 * ProRes 4444 的 alpha 规范是**预乘（premultiplied）**：Apple 官方规定 4444 里 RGB 已乘过 alpha。
 * ffmpeg 默认把 yuva 当「直通（straight）」写入。
 *
 * ⚠️ 2026-10-24 晚翻转默认（预乘 → 直通）。全链路实测（node-canvas 渲帧 → 本函数编码 → 解码对账）：
 *  - 预乘数据的倒影区 = RGB 37 / alpha 42（写入正确、alpha 完整保留）；
 *  - 但剪映实际管线把它按**直通**解释 ⇒ 白倒影合成 = 86（比背景 96 还暗）⇒ 倒影隐形
 *    （用户实报「导入剪映再导出成片，倒影消失」）；按规范解释则是 117（可见）。
 *  - **纯白内容（文字/倒影）的直通数据是解释无关的**：un-premultiply(255/α) 钳回 255，
 *    预乘解释与直通解释的合成结果逐像素相同 ⇒ premul=false 对白字内容两种解码器都正确，
 *    只有非白内容（蓝光团）在规范解释下轻微偏色，无乱码风险。
 *  - 早前「直通=剪映全亮乱码」的归因（RGB 直接亮出=255）数学上不自洽（255+α0.18 两种解释
 *    都合成 ≈122），当时代码还叠着倒影渐变失效 bug（同日已修），归因被污染。
 * premul === true 时才追加 `premultiply=inplace=1`（放在 crop/scale 之后）。
 */
function proresMovArgs({ fps, digits, dir, width, height, duration, outPath, srcWidth, srcHeight, crop, premul, codec }) {
  const args = [
    '-framerate',
    String(fps),
    '-i',
    path.join(dir, `frame_%0${digits}d.png`),
  ]

  // ── 输出画面处理（2026-10-17）──────────────────────────────────────────
  // crop：切掉卡片周围的纯透明区（**画质无损**，像素 1:1 保留），剪映解码面积骤降。
  // scale：满屏卡裁不动 ⇒ 整体降采样（有损，但它是模糊装饰层看不出）。
  // 二者互斥；crop 之后输出尺寸由滤镜决定，不能再叠加 -s，否则会被二次缩放。
  let vf = movVideoFilter({ srcWidth, srcHeight, width, height, crop })
  // 预乘 alpha 必须放在最后一步（crop/scale 之后再乘），否则缩放会先把半透明边缘糊坏
  // 默认直通（2026-10-24 晚翻转）：premul === true 才预乘，理由见函数头注释
  if (premul === true) vf = vf ? `${vf},format=rgba,premultiply=inplace=1` : 'format=rgba,premultiply=inplace=1'
  if (vf) {
    args.push('-vf', vf)
  } else if (width && height) {
    args.push('-s', `${width}x${height}`)
  }

  if (codec === 'png') {
    // PNG-in-MOV（2026-10-24 深夜新增，**默认**）：rgba 直通逐帧无损。
    // 判定实验实测：剪映对 PNG 编码的预览与二导走同一个 RGB×α 模型，半透明内容
    // （倒影/光晕）两端都正确；而 ProRes 的预览器会把半透明像素 RGB 直出成实心。
    // premul 不适用（PNG 本身就是非预乘直通，正是两端都正确的数据形态）。
    args.push('-c:v', 'png', '-pix_fmt', 'rgba')
  } else {
    args.push(
      '-c:v',
      'prores_ks',
      '-profile:v',
      '4444',
      '-pix_fmt',
      'yuva444p10le',
      '-alpha_bits',
      '8',
      '-vendor',
      'apl0',
    )
  }
  // 精确对齐时长：帧数向上取整后输出可能略长，用 -t 裁到目标时长
  if (Number.isFinite(duration) && duration > 0) args.push('-t', String(duration))
  args.push('-y', outPath)
  return args
}

/**
 * 透明 MOV 的画面处理滤镜（纯函数，闸门可数值断言）。
 * 返回 null = 不需要滤镜（保持老行为的 -s 或直接原样）。
 */
function movVideoFilter({ srcWidth, srcHeight, width, height, crop }) {
  if (crop && Number(crop.width) > 0 && Number(crop.height) > 0) {
    const x = Math.max(0, Math.round(Number(crop.x) || 0))
    const y = Math.max(0, Math.round(Number(crop.y) || 0))
    const w = Math.max(2, Math.round(Number(crop.width) || 0))
    const h = Math.max(2, Math.round(Number(crop.height) || 0))
    return `crop=${w}:${h}:${x}:${y}`
  }
  // 无裁剪但输出尺寸小于源帧 ⇒ 合成阶段降采样
  const sw = Number(srcWidth) || 0
  const sh = Number(srcHeight) || 0
  const dw = Number(width) || 0
  const dh = Number(height) || 0
  if (sw > 0 && sh > 0 && dw > 0 && dh > 0 && (dw !== sw || dh !== sh)) {
    return `scale=${dw}:${dh}`
  }
  return null
}

ipcMain.handle('export:finish', async (_e, { fps, fileName, width, height, duration, kinds, outPath, premul, codec }) => {
  if (!session) throw new Error('导出会话不存在，请重新开始')
  // 第②层（补充项）：整条透明 MOV 合成前，主进程独立复核卡清单；
  // BASE 态含 pro 卡即 fail-closed 整条拒绝（像素级无法逐卡剔除，故整条拦截）。
  const { ok: proOk, blocked } = await exportProOk(Array.isArray(kinds) ? kinds : [])
  if (!proOk) {
    await cleanupSession()
    return { ok: false, blocked: true, reason: 'edition' }
  }
  const { dir, digits } = session

  // 保存位置：渲染前已由 renderer 选好（export:pickSave）⇒ 直接写，不再弹对话框；
  //   没带 outPath 时才弹（兜底：老调用方 / 分段渲染失败回退整条时）。
  let target = typeof outPath === 'string' ? outPath.trim() : ''
  if (!target) {
    const { canceled, filePath } = await dialog.showSaveDialog(win ?? undefined, {
      title: '保存透明 MOV',
      defaultPath: fileName || 'overlay.mov',
      filters: [{ name: 'QuickTime 透明视频 (*.mov)', extensions: ['mov'] }],
    })
    if (canceled || !filePath) {
      await cleanupSession()
      return { ok: false, cancelled: true }
    }
    target = filePath
  }

  const args = proresMovArgs({ fps, digits, dir, width, height, duration, outPath: target, premul, codec })

  try {
    await runFfmpeg(args)
  } catch (err) {
    await cleanupSession()
    throw err
  }
  await cleanupSession()
  return { ok: true, filePath: target }
})

/**
 * 导出前先选保存位置（2026-10-16 用户要求）：渲染前就定好目标文件，
 * 避免「渲完几分钟才弹保存对话框、一取消就白渲」。取消返回空串。
 * 与 export:pickDir 分开：那边选目录（分段素材用），这边选具体文件（整条 MOV / MP4 用）。
 */
ipcMain.handle('export:pickSave', async (_e, opts) => {
  const o = opts || {}
  const exts = Array.isArray(o.extensions) && o.extensions.length ? o.extensions : ['mov']
  const { canceled, filePath } = await dialog.showSaveDialog(win ?? undefined, {
    title: String(o.title || '保存文件'),
    defaultPath: String(o.fileName || `output.${exts[0]}`),
    filters: [{ name: String(o.filterName || '视频文件'), extensions: exts }],
  })
  return canceled || !filePath ? '' : filePath
})

/**
 * 选择输出目录（「只渲分段、不导整条」时用）。
 * 以前整条成片的保存对话框顺带确定了输出目录；跳过整条后必须单独让用户指一次。
 * 与 jianying:selectFolder 分开：那边标题写死「剪映草稿目录」，语义不同。
 */
ipcMain.handle('export:pickDir', async (_e, title) => {
  const r = dialog.showOpenDialogSync(win ?? undefined, {
    title: String(title || '选择导出目录（分段素材存放位置）'),
    properties: ['openDirectory'],
  })
  return r && r[0] ? r[0] : ''
})

/**
 * 直写版 finish（按卡分段导出用）：**不弹保存对话框**，直接合成到 outDir/fileName。
 * 逐卡导出会调用 N 次，弹 N 次对话框不可接受，所以单开一条通道。
 */
ipcMain.handle('export:finishTo', async (_e, { fps, outDir, fileName, width, height, duration, kind, srcWidth, srcHeight, crop, premul, codec }) => {
  if (!session) throw new Error('导出会话不存在，请重新开始')
  if (!outDir || !fileName) return { ok: false }
  // 第②层：BASE 态导出 pro 卡片段 ⇒ fail-closed 剔除（不合成、不落盘）
  const { ok: proOk, blocked } = await exportProOk(kind ? [kind] : [])
  if (!proOk) {
    await cleanupSession()
    return { ok: false, blocked: true, reason: 'edition' }
  }
  const { dir, digits } = session
  await fsp.mkdir(outDir, { recursive: true })
  const outPath = path.join(outDir, String(fileName))
  const args = proresMovArgs({
    fps,
    digits,
    dir,
    width,
    height,
    duration,
    outPath,
    srcWidth,
    srcHeight,
    crop,
    premul,
    codec,
  })

  try {
    await runFfmpeg(args)
  } catch (err) {
    await cleanupSession()
    throw err
  }
  await cleanupSession()
  return { ok: true, filePath: outPath }
})

/**
 * 导出时顺手写一份文本产物（如配音脚本 .md）：和 finishTo 同源信任——只写到用户已选定的
 * 导出目录里，不弹对话框、不跨目录。路径做了基本安全校验（必须绝对目录、禁止 `..` 逃逸）。
 */
ipcMain.handle('export:writeTextFile', async (_e, { dir, fileName, content }) => {
  try {
    if (typeof dir !== 'string' || typeof fileName !== 'string' || typeof content !== 'string') {
      return { ok: false, reason: 'bad-args' }
    }
    if (!path.isAbsolute(dir)) return { ok: false, reason: 'bad-dir' }
    if (fileName.includes('\\') || fileName.includes('/') || fileName.includes('..')) {
      return { ok: false, reason: 'bad-name' }
    }
    // 防 `..` 逃逸：归一化后必须仍在 dir 内
    const abs = path.resolve(dir, fileName)
    if (!abs.startsWith(path.resolve(dir) + path.sep) && abs !== path.resolve(dir)) {
      return { ok: false, reason: 'escape' }
    }
    await fsp.mkdir(dir, { recursive: true })
    const outPath = path.join(dir, fileName)
    await fsp.writeFile(outPath, content, 'utf8')
    return { ok: true, path: outPath }
  } catch (err) {
    return { ok: false, reason: err instanceof Error ? err.message : String(err) }
  }
})

/** 导出时顺手写一份二进制产物（如音效素材 WAV）：落到指定导出目录内，文件名做防逃逸校验 */
ipcMain.handle('export:writeBinaryFile', async (_e, { dir, fileName, data }) => {
  try {
    if (typeof dir !== 'string' || typeof fileName !== 'string') return { ok: false, reason: 'bad-args' }
    if (!path.isAbsolute(dir)) return { ok: false, reason: 'bad-dir' }
    if (fileName.includes('\\') || fileName.includes('/') || fileName.includes('..')) {
      return { ok: false, reason: 'bad-name' }
    }
    const abs = path.resolve(dir, fileName)
    if (!abs.startsWith(path.resolve(dir) + path.sep) && abs !== path.resolve(dir)) {
      return { ok: false, reason: 'escape' }
    }
    await fsp.mkdir(dir, { recursive: true })
    const outPath = path.join(dir, fileName)
    const buf = Buffer.isBuffer(data) ? data : Buffer.from(data)
    await fsp.writeFile(outPath, buf)
    return { ok: true, path: outPath }
  } catch (err) {
    return { ok: false, reason: err instanceof Error ? err.message : String(err) }
  }
})

ipcMain.handle('export:cancel', async () => {
  await cleanupSession()
  return true
})

/* 成片导出：可选原视频 + 透明动效层帧 + 音乐轨混音 → H.264 MP4；
   无原视频时直接以动效层帧为画面输出（背景由卡片/舞台本身填充） */
ipcMain.handle(
  'videoexport:finish',
  async (_e, opts) => {
    const { fps, fileName, width, height, videoToken, music, kinds, outPath, sfxTrackB64 } = opts
    if (!session) throw new Error('导出会话不存在，请重新开始')
    // 第②层（补充项）：整条 MP4 成片合成前，主进程独立复核卡清单
    const { ok: proOk, blocked } = await exportProOk(Array.isArray(kinds) ? kinds : [])
    if (!proOk) {
      await cleanupSession()
      return { ok: false, blocked: true, reason: 'edition' }
    }
    const { dir, digits } = session

    // R30/R31：视频源声音量。轨道总音量（opts.videoVolume）× 每段自己的 volume = 该段最终倍率，
    //   与渲染层 <video>.volume 同一算式，故「预览听到的」与「成片里的」一致。
    //   缺省 / 非法值一律回 1（原声），保证老工程输出不变。
    // R32：音量倍率合法区间上限提到 9（=900%，对应 300% 片段 × 300% 轨道）。原生 <video>.volume 只接受
    // [0,1]，但此处走 ffmpeg volume 滤镜 / amix 权重，均可承载 >1，与渲染端 Web Audio GainNode 同口径。
    const clampGain = (n, d = 1) => (Number.isFinite(n) ? Math.min(9, Math.max(0, n)) : d)
    const srcVolume = clampGain(Number(opts.videoVolume))
    // R32：音乐 / 音效轨总音量（缺省 1），用于合成 amix 权重时乘以每段 volume
    const musicTrackVol = clampGain(Number(opts.musicVolume ?? 1))
    const sfxTrackVol = clampGain(Number(opts.sfxVolume ?? 1))
    // 恒等（1.0）时不加滤镜：少一层滤镜 = 少一次采样转换，导出更快，且与历史行为完全一致
    const volFilter = (v) => (v >= 0.999 ? '' : `,volume=${v.toFixed(3)}`)

    // K2（2026-11-11）：片段加速倍率 1~10。1 以外的值：
    //   画面 → setpts 压缩时间戳（再由 fps 重采样成 CFR）；声音 → atempo 链（单个 atempo 只吃
    //   0.5~2.0，10 倍拆成 2×2×2×1.25）。缺省/非法值一律按 1（老工程输出与历史完全一致）。
    const clampSpeedOf = (n) => {
      const v = Number(n)
      return Number.isFinite(v) ? Math.min(10, Math.max(1, v)) : 1
    }
    const atempoChain = (speed) => {
      const s = clampSpeedOf(speed)
      if (Math.abs(s - 1) < 0.005) return ''
      const out = []
      let rest = s
      while (rest > 2.0001) {
        out.push(2)
        rest /= 2
      }
      if (Math.abs(rest - 1) > 0.005) out.push(Math.round(rest * 1000) / 1000)
      return out.map((v) => `atempo=${v}`).join(',')
    }

    const reg = loadMediaRegistry()

    // 多视频成片：把视频轨道上的每一段按时间轴位置拼接（取代旧的单 videoToken 口径）
    const rawClips = Array.isArray(opts.videoClips) ? opts.videoClips : []
    const T = session.total > 0 ? session.total / fps : 0
    const vclips = []
    for (const c of rawClips) {
      if (!c || !c.token) continue
      const p = reg[c.token]
      if (!p || !fs.existsSync(p)) continue
      const start = Math.max(0, Number(c.start) || 0)
      const trimStart = Math.max(0, Number(c.trimStart) || 0)
      const trimEnd = Math.max(trimStart, Number(c.trimEnd) || 0)
      // K2：渲染层传上来的 trimEnd 已经是「源内终点」= trimStart + 轴长 × 倍率，
      //   所以这里减出来的是**源内长度**，轴上占的时长 = 源长 / 倍率。
      const speed = clampSpeedOf(c.speed)
      const srcLen = Math.max(0.05, trimEnd - trimStart)
      const len = Math.max(0.05, srcLen / speed)
      const tail = Math.max(0, T - start - len)
      if (len <= 0) continue
      // R31：该段自己的原声音量（缺省 1）。最终倍率 = 本值 × 轨道总音量，见下方滤镜链。
      const clipVol = clampGain(Number(c.volume))
      vclips.push({ path: p, start, len, srcLen, speed, tail, trimStart, volume: clipVol, token: c.token })
    }
    const hasMulti = vclips.length > 0
    // 单视频（旧口径）仅在「没有多段、且传了 videoToken」时生效；多段优先
    const singleToken = opts.videoToken || (vclips.length ? vclips[0].token : '')
    const videoPath = singleToken ? reg[singleToken] : null
    const hasVideo = !hasMulti && !!videoPath && fs.existsSync(videoPath)

    // 音乐轨：只保留确实存在的文件
    const musicClips = []
    for (const m of Array.isArray(opts.music) ? opts.music : []) {
      if (!m || !m.file) continue
      const fp = path.join(musicDir(), path.basename(String(m.file)))
      if (fs.existsSync(fp)) musicClips.push({ ...m, path: fp })
    }

    // 入场音效合成音轨：base64 解码落临时文件；解码失败则跳过，不影响画面
    const sfxClips = []
    if (typeof sfxTrackB64 === 'string' && sfxTrackB64.length) {
      try {
        const buf = Buffer.from(sfxTrackB64, 'base64')
        const sfxDir = path.join(app.getPath('temp'), 'vfx-sfx')
        fs.mkdirSync(sfxDir, { recursive: true })
        const sfxPath = path.join(sfxDir, `sfx_${Date.now()}.wav`)
        fs.writeFileSync(sfxPath, buf)
        if (fs.existsSync(sfxPath)) sfxClips.push({ file: sfxPath, start: 0, volume: 1 })
      } catch {
        /* 解码/落盘失败静默跳过 */
      }
    }

    const vClipHasAudio = hasMulti
      ? await Promise.all(vclips.map((c) => probeHasAudio(c.path)))
      : []
    const hasSrcAudio = hasMulti
      ? vClipHasAudio.some(Boolean)
      : hasVideo
        ? await probeHasAudio(videoPath)
        : false

    // 保存位置：渲染前已由 renderer 选好（export:pickSave）⇒ 直接写，不再弹对话框
    let target = typeof outPath === 'string' ? outPath.trim() : ''
    if (!target) {
      const { canceled, filePath } = await dialog.showSaveDialog(win ?? undefined, {
        title: '保存成片视频',
        defaultPath: fileName || 'video.mp4',
        filters: [{ name: 'MP4 视频 (*.mp4)', extensions: ['mp4'] }],
      })
      if (canceled || !filePath) {
        await cleanupSession()
        return { ok: false, cancelled: true }
      }
      target = filePath
    }

    const pattern = path.join(session.dir, `frame_%0${session.digits}d.png`)
    const parts = []
    const inputs = []
    const audioLabels = []
    const audioWeights = []

    let multiInputCount = 0
    if (hasMulti) {
      // 多段拼接：每段裁成 WxH、CFR=fps 的底板，用透明间隙拼成完整时间轴，再叠动效层帧。
      // 间隙用「全透明」黑色填充（alpha=0），叠加时不会互相覆盖；后导入的片段盖在更上层。
      let inIdx = 0 // 输入索引与 inputs.push 顺序严格同步（音频 / 动效帧全靠它引用）
      vclips.forEach((c, idx) => {
        // ⚠️ ffmpeg 输入选项作用于「其后的 -i 文件」⇒ -ss/-t 必须放在 -i 之前。
        // K2：-t 取**源内长度**（srcLen），加速后由下面的 setpts 压回轴上长度（len）。
        inputs.push(
          { flag: '-ss', val: c.trimStart.toFixed(3) },
          { flag: '-t', val: c.srcLen.toFixed(3) },
          { flag: '-i', val: c.path },
        )
        const vIdx = inIdx++
        c.vIdx = vIdx
        // K2：加速时先压缩时间戳 (PTS-STARTPTS)/speed，再用 fps 重采样成 CFR（顺序不能反，
        //   反了会得到 1/(fps*speed) 的非均匀帧间隔，与间隙 concat 对不上）。
        const vChain =
          c.speed > 1.0001
            ? `setpts=(PTS-STARTPTS)/${c.speed.toFixed(6)},fps=${fps}`
            : `fps=${fps},setpts=PTS-STARTPTS`
        parts.push(
          `[${vIdx}:v]${vChain},scale=${width}:${height}:force_original_aspect_ratio=increase,crop=${width}:${height},setsar=1,format=yuva420p[seg${idx}]`,
        )
        // 底板 concat（前间隙 + 底板 + 后间隙）
        const mkGap = (tag) => {
          parts.push(
            `color=c=black:s=${width}x${height}:r=${fps}:d=${c.start.toFixed(3)},format=yuva420p,colorchannelmixer=aa=0,setsar=1[g${tag}]`,
          )
          return `[g${tag}]`
        }
        const vpGap = []
        if (c.start > 0.001) {
          vpGap.push(mkGap(`0${idx}a`))
        }
        vpGap.push(`[seg${idx}]`)
        if (c.tail > 0.001) {
          vpGap.push(mkGap(`1${idx}a`))
        }
        parts.push(`${vpGap.join('')}concat=n=${vpGap.length}:v=1:a=0[vp${idx}]`)
      })
      // 把所有底板叠加（间隙透明 ⇒ 不会互相覆盖；后导入的盖在更上层）
      let acc = 'vp0'
      for (let k = 1; k < vclips.length; k++) {
        parts.push(`[${acc}][vp${k}]overlay[vacc${k}]`)
        acc = `vacc${k}`
      }
      // 动效层帧（含卡片）作为输入，叠在最上层
      const framesIdx = inIdx
      inputs.push({ flag: '-framerate', val: String(fps) }, { flag: '-i', val: pattern })
      parts.push(`[${acc}][${framesIdx}:v]overlay=0:0[v]`)
      // ⚠️ 关键：frames 输入占用了 inIdx 这个索引位，故「音乐/BGM 起始输入」必须 +1，
      // 否则 musicStart 会指向 frames（纯视频序列、无音轨）→ 滤镜图报
      // “Stream specifier ':a' ... matches no streams”。
      multiInputCount = inIdx + 1
      // 音轨：每段源音频按时间轴位置延迟，并补齐到整条时长 T（输入索引用 vIdx，勿用段序号）
      vclips.forEach((c, idx) => {
        // 逐段探测音轨：只有「该段本身」有音频才生成 [vIdx:a] 链；
        // 不能共用 hasSrcAudio（任意段有音即 true），否则无音轨的段会引用到不存在的音频流。
        if (!vClipHasAudio[idx]) return
        const ms = Math.round(c.start * 1000)
        // R31：每段各自的原声倍率 = 轨道总音量 × 该段 volume（不同素材音量常常差很多）
        const segVol = clampGain(srcVolume * clampGain(c.volume))
        // K2：加速段的声音同步变速（atempo 链，1 倍速时不加 = 与历史行为一致）
        const at = atempoChain(c.speed)
        parts.push(
          `[${c.vIdx}:a]aformat=sample_fmts=fltp:sample_rates=44100:channel_layouts=stereo${at ? ',' + at : ''},adelay=${ms}|${ms},apad,atrim=end=${T.toFixed(3)}${volFilter(segVol)}[ca${idx}]`,
        )
        audioLabels.push(`[ca${idx}]`)
        audioWeights.push(1)
      })
    } else if (hasVideo) {
      // 画面：原视频严格按目标比例（9:16 / 16:9）放大裁切铺满，再叠动效层（与舞台预览一致）
      inputs.push(
        { flag: '-i', val: videoPath },
        { flag: '-framerate', val: String(fps) },
        { flag: '-i', val: pattern },
      )
      const baseChain = `[0:v]fps=${fps},setpts=PTS-STARTPTS,scale=${width}:${height}:force_original_aspect_ratio=increase,crop=${width}:${height}`
      // 画面：原视频严格按目标比例（9:16 / 16:9）放大裁切铺满，再叠动效层（与舞台预览一致）。
      // ⚠️ 关键修复：手机/抖音录屏多为 VFR（可变帧率），前 1~2s 帧间隔稀疏。
      //    ffmpeg 以源视频做主同步输入时，会把视频首帧按住重复填充时间轴，
      //    导致成片开头 1-2 秒「定格」在首帧。这里先把源视频转成与导出一致的 CFR
      //    （fps），并把时间基准对齐到 0（setpts），再叠遮罩层，消除开头定格。
      parts.push(`${baseChain}[base];[base][1:v]overlay=0:0[v]`)
      if (hasSrcAudio) {
        // R31：单段口径（老调用方）也要带上这一段自己的音量；没传就按 1（原声）
        const onlyVol = clampGain(Number(rawClips.length ? rawClips[0].volume : 1))
        parts.push(
          `[0:a]aformat=sample_fmts=fltp:sample_rates=44100:channel_layouts=stereo${volFilter(clampGain(srcVolume * onlyVol))}[sa]`,
        )
        audioLabels.push('[sa]')
        audioWeights.push(1)
      }
    } else {
      // 画面：没有原视频，把动效层帧合成到黑底再编码。
      // ⚠️ 不能直接 format=yuv420p —— 那是「丢 alpha 保 RGB」：半透明内容（倒影 /
      //    光晕 / 羽化 / 暗角遮罩）的 RGB 是满值（如白倒影 RGB=255,A=46），直转后
      //    整片变全亮实心（2026-10-24 用户实报：无网格背景时倒影成实心白）。
      //    overlay 到 color 黑底才是按 alpha 正确合成（255×0.18≈46 灰，透明处=黑）。
      inputs.push({ flag: '-framerate', val: String(fps) }, { flag: '-i', val: pattern })
      parts.push(
        `[0:v]scale=${width}:${height}:force_original_aspect_ratio=disable[sc]` +
          `;color=c=black:s=${width}x${height}[bg]` +
          `;[bg][sc]overlay=0:0:shortest=1,format=yuv420p[v]`,
      )
    }

    // 音频：每段 BGM（裁剪起点 / 淡入淡出 / 延迟到落点），多段模式下补齐到整条时长 T
    const musicStart = hasMulti ? multiInputCount : hasVideo ? 2 : 1
    musicClips.forEach((c, i) => {
      const idx = musicStart + i
      const offset = Math.max(0, Number(c.offset) || 0)
      const dur = Math.max(0, Number(c.duration) || 0)
      // K2：加速后这条音频在时间轴上的长度 = 源时长 / 倍率（淡出起点也要按这个算）
      const speed = clampSpeedOf(c.speed)
      const outDur = dur > 0 ? dur / speed : 0
      const fi = Math.max(0, Number(c.fadeIn) || 0)
      const fo = Math.max(0, Number(c.fadeOut) || 0)
      let chain = `[${idx}:a]aformat=sample_fmts=fltp:sample_rates=44100:channel_layouts=stereo`
      if (offset > 0 || dur > 0) {
        const end = dur > 0 ? `:end=${(offset + dur).toFixed(3)}` : ''
        chain += `,atrim=start=${offset.toFixed(3)}${end},asetpts=PTS-STARTPTS`
      }
      // K2：变速（atempo 链）。放在 atrim 之后、afade 之前 —— 淡入淡出的时间轴是「输出时间」。
      const musAt = atempoChain(speed)
      if (musAt) chain += `,${musAt}`
      if (fi > 0) chain += `,afade=t=in:st=0:d=${fi.toFixed(3)}`
      if (fo > 0 && outDur > 0) {
        chain += `,afade=t=out:st=${Math.max(0, outDur - fo).toFixed(3)}:d=${fo.toFixed(3)}`
      }
      const ms = Math.max(0, Math.round((Number(c.start) || 0) * 1000))
      if (ms > 0) chain += `,adelay=${ms}|${ms}`
      // 多段模式：补齐到整条时长，避免 amix 因首段过短而被截断
      if (hasMulti) chain += `,apad,atrim=end=${T.toFixed(3)}`
      chain += `[bgm${i}]`
      parts.push(chain)
      // R32：amix 权重 = 片段音量 × 轨道总音量（音乐 / 音效轨各自的总音量倍率）。
      //   clipV∈[0,3]、轨道总音量∈[0,3] ⇒ 乘积封顶 9，与渲染端 Web Audio GainNode 同口径；
      //   amix 按「权重之和」归一化、末端 volume=${sum} 还原，故权重即各轨实际增益。
      const trk = c.track === 'sfx' ? sfxTrackVol : musicTrackVol
      const clipV = clampGain(Number(c.volume ?? 0.9))
      const w = Math.max(0, Math.min(9, clipV * trk))
      audioWeights.push(w)
      audioLabels.push(`[bgm${i}]`)
    })

    // 入场音效：每条音效已烘焙好对应事件长度，按事件起点延迟到时间轴，再补零到整条时长 T，
    // 与音乐/源音频一起 Amix。音量已烘焙进 WAV（per-call 音量），故权重取 1，由末端 volume=${sum} 还原。
    // ⚠️ SFX 输入只在末尾（args.push('-i', c.file)）追加一次，与音乐同模式；切勿在此处 inputs.push，
    //    否则会重复添加且 sfxClips 无 path 字段 → 末尾读到 undefined 输入而 ffmpeg 报错。
    const sfxStart = musicStart + musicClips.length
    sfxClips.forEach((c, i) => {
      const idx = sfxStart + i
      let chain = `[${idx}:a]aformat=sample_fmts=fltp:sample_rates=44100:channel_layouts=stereo`
      const ms = Math.max(0, Math.round((Number(c.start) || 0) * 1000))
      if (ms > 0) chain += `,adelay=${ms}|${ms}`
      chain += `,apad,atrim=end=${T.toFixed(3)}[sfx${i}]`
      parts.push(chain)
      audioWeights.push(1)
      audioLabels.push(`[sfx${i}]`)
    })

    const hasAudioOut = audioLabels.length > 0
    if (hasAudioOut) {
      // amix 按「权重之和」归一化，因此末端补一个 volume 还原真实音量
      const sum = audioWeights.reduce((s, w) => s + w, 0)
      parts.push(
        `${audioLabels.join('')}amix=inputs=${audioLabels.length}:duration=first:weights=${audioWeights
          .map((w) => w.toFixed(3))
          .join(' ')}${sum > 0 ? `,volume=${sum.toFixed(3)}` : ''},alimiter=limit=0.95[a]`,
      )
    }

    const args = []
    for (const inp of inputs) {
      args.push(inp.flag, inp.val)
    }
    for (const c of musicClips) args.push('-i', c.path)
    for (const c of sfxClips) args.push('-i', c.file)
    args.push(
      '-filter_complex',
      parts.join(';'),
      '-map',
      '[v]',
      '-c:v',
      'libx264',
      '-crf',
      '18',
      '-preset',
      'medium',
      '-pix_fmt',
      'yuv420p',
    )
    if (hasAudioOut) {
      args.push('-map', '[a]', '-c:a', 'aac', '-b:a', '192k')
    }
    args.push('-movflags', '+faststart', '-shortest', '-y', target)

    try {
      await runFfmpeg(args)
    } catch (err) {
      await cleanupSession()
      throw err
    }
    await cleanupSession()
    return { ok: true, filePath: target }
  },
)

ipcMain.handle('shell:showItem', async (_e, p) => {
  if (p) shell.showItemInFolder(p)
  return true
})

ipcMain.handle('app:info', async () => ({
  version: app.getVersion(),
  ffmpeg: ffmpegPath(),
  packaged: app.isPackaged,
  integrity: integrityOk,
}))

// 完整性状态（渲染层用来把 PRO 强制降级到 BASE；真正的拦截在加载阶段，这里只是状态同步）
ipcMain.handle('app:integrity', async () => ({ ok: integrityOk, reason: integrityReason }))

/* ------------------------------------------------------------------ *
 * 检查更新（2026-09-28）
 *
 * 设计：客户端只做「拉取版本清单 → 比对 → 提示 → 跳浏览器下载」，不自动替换文件。
 * 理由：主力交付是便携版（自包含目录），没有安装器可走静默升级；
 * 且自动覆盖 app.asar 会打断用户正在编辑的工程。
 *
 * 清单托管在腾讯云 COS（或任意 https 静态地址），字段见 update/manifest.example.json。
 * ------------------------------------------------------------------ */

/**
 * 我们自己的代码根目录：resources/app（dist + electron/ + package.json）
 * 主进程在 resources/app/electron/ 下，故取上一级。
 * ⚠️ scripts/pack-code-update.cjs 打包的就是这个目录，改名必须同步。
 *
 * 安装器默认会把代码打包成 resources/app.asar（一个文件），而便携版是 resources/app 目录。
 * 增量更新必须往目录里写文件，所以检测到 app.asar 文件时，把目标目录切到 resources/app，
 * 并在写出新代码后移走 app.asar，让重启后的 Electron 从 app/ 目录加载新版本。
 */
let APP_CODE_ROOT = path.resolve(__dirname, '..')
const APP_DIR_CANDIDATE = path.join(path.dirname(APP_CODE_ROOT), 'app')
const APP_ASAR_FILE = path.join(path.dirname(APP_CODE_ROOT), 'app.asar')
const IS_PACKED_ASAR =
  path.basename(APP_CODE_ROOT) === 'app.asar' ||
  (fs.existsSync(APP_ASAR_FILE) && (!fs.existsSync(APP_CODE_ROOT) || !fs.statSync(APP_CODE_ROOT).isDirectory()))
if (IS_PACKED_ASAR) {
  APP_CODE_ROOT = APP_DIR_CANDIDATE
}

/**
 * 运行时标签：必须与 scripts/pack-code-update.cjs 的 RUNTIME_TAG 一致（改必同步）。
 * 只有 Electron 大版本升级时才递增——标签不匹配的旧客户端会自动回退到全量安装包，
 * 避免新代码跑在旧运行时上。
 */
const CODE_UPDATE_RUNTIME_TAG = 'r1'

/** 更新清单地址：读 package.json 的 updateManifest 字段；为空 = 未配置，客户端不联网 */
function updateManifestUrl() {
  try {
    return String(require('../package.json').updateManifest || '').trim()
  } catch {
    return ''
  }
}

/** 便携版（portable）运行时，electron-builder 会注入 PORTABLE_EXECUTABLE_DIR */
function isPortableMode() {
  return !!process.env.PORTABLE_EXECUTABLE_DIR
}

/** 语义化版本比较：a > b 返回 1，相等 0，小于 -1。容忍 '1.2' / 'v1.2.0' 这类写法 */
function compareVersion(a, b) {
  const pa = String(a || '').replace(/^v/i, '').split('.')
  const pb = String(b || '').replace(/^v/i, '').split('.')
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const na = parseInt(pa[i], 10) || 0
    const nb = parseInt(pb[i], 10) || 0
    if (na !== nb) return na > nb ? 1 : -1
  }
  return 0
}

/** 清单超时：宁可「检查失败」，也不能让启动卡在网络上 */
const UPDATE_TIMEOUT_MS = 8000

/**
 * 更新相关地址的安全校验：
 * - 一律要求 https（防止明文传输被劫持、替换成恶意安装包）
 * - 例外：本机 http（127.0.0.1 / localhost），方便本地联调与内网测试
 */
function isSafeUpdateUrl(u) {
  const s = String(u || '')
  if (/^https:\/\//i.test(s)) return true
  return /^http:\/\/(127\.0\.0\.1|localhost)(:\d+)?\//i.test(s)
}

/**
 * 把 Node / Electron 的英文网络错误翻译成中文，避免用户看到 "fetch failed" 这类原始报错。
 * scope 用来区分环节，例如「检查更新」「下载更新包」。
 */
function friendlyNetError(e, scope) {
  const raw = String((e && e.message) || e || '')
  const name = String((e && e.name) || '')
  const prefix = String(scope || '更新')
  let cause = ''
  if (name === 'AbortError' || /aborted|timeout/i.test(raw)) cause = '连接超时'
  else if (/fetch failed/i.test(raw)) cause = '无法连接到服务器'
  else if (/ENOTFOUND|EAI_AGAIN|getaddrinfo/i.test(raw)) cause = '服务器地址解析失败'
  else if (/ECONNREFUSED/i.test(raw)) cause = '服务器拒绝连接'
  else if (/ECONNRESET|EPIPE|socket hang/i.test(raw)) cause = '网络连接被中断'
  else if (/CERT|certificate|SELF_SIGNED/i.test(raw)) cause = '服务器证书校验失败'
  else if (/network|ETIMEDOUT|EHOSTUNREACH|ENETUNREACH/i.test(raw)) cause = '网络异常'
  else if (raw) cause = '发生未知错误（' + raw + '）'
  return `${prefix}失败：${cause || '发生未知错误'}，请检查网络后重试。`
}

/** HTTP 响应码也要说人话：404 多半是清单还没上传 */
function friendlyHttpError(status) {
  if (status === 404) return '服务器返回 404：找不到更新清单文件，请确认清单已上传到正确地址。'
  if (status === 403 || status === 401) return `服务器返回 ${status}：没有访问权限，请确认更新文件已设为公开。`
  if (status >= 500) return `服务器返回 ${status}：更新服务器暂时不可用，请稍后再试。`
  return `服务器返回 HTTP ${status}，请稍后重试。`
}

ipcMain.handle('update:check', async () => {
  // 更新资格判定（第②层，主进程权威）：仅「永久」与「在期订阅」可接收更新；
  // 免费基础版与到期订阅冻结在旧版本。前端无法绕过（此文件在 integrity.json 签名清单内）。
  const elg = await proGate.updateEligible(loadAppState(), { clockSuspect })
  if (elg !== 'active') {
    logStartup('update check: blocked, eligibility=' + elg)
    return {
      ok: false,
      reason: 'subscription-blocked',
      blockedReason: elg === 'clock' ? 'clock-suspect' : elg === 'expired' ? 'subscription-expired' : 'not-activated',
      current: app.getVersion(),
    }
  }
  const current = app.getVersion()
  const url = updateManifestUrl()
  if (!url) {
    logStartup('update check: skipped (updateManifest 未配置)')
    return { ok: false, reason: 'not-configured', current }
  }
  if (!isSafeUpdateUrl(url)) {
    logStartup('update check: 地址不安全 ->', url)
    return { ok: false, reason: 'bad-url', current }
  }

  const ac = new AbortController()
  const timer = setTimeout(() => ac.abort(), UPDATE_TIMEOUT_MS)
  try {
    // 加时间戳查询参数绕开 CDN 缓存：raw.githubusercontent.com（Fastly）会缓存约 5 分钟，
    // 刚改完清单就点检查会拿到旧版本号，误报「已是最新版本」。cache:'no-store' 只是请求头，
    // 拦不住 CDN 边缘缓存，必须让每次请求的 URL 都不一样。
    const bust = url + (url.includes('?') ? '&' : '?') + '_t=' + Date.now()
    const res = await fetch(bust, {
      signal: ac.signal,
      cache: 'no-store',
      headers: { accept: 'application/json' },
    })
    if (!res.ok) return { ok: false, reason: 'http', current, message: friendlyHttpError(res.status) }

    const m = await res.json()
    const latest = String(m.version || '').trim()
    if (!latest) return { ok: false, reason: 'bad-json', current }

    const notes = Array.isArray(m.notes)
      ? m.notes.map((s) => String(s))
      : String(m.notes || '')
          .split('\n')
          .map((s) => s.trim())
          .filter(Boolean)

    // 唯一的更新方式：轻量增量包（只含 resources/app，约 0.6MB）。
    // 2026-09-29 起移除完整安装包（exe）路径：130MB 里 99% 是永不变的 Electron 运行时，
    // 没必要重下；runtimeTag 不匹配 = 运行时结构变了，只提示联系开发者，不再尝试全量安装。
    let codePackage = null
    const cp = m.codePackage
    if (cp && String(cp.url || '').trim()) {
      const cpUrl = String(cp.url).trim()
      if (String(cp.runtimeTag || '') !== CODE_UPDATE_RUNTIME_TAG) {
        logStartup('code package skipped: runtimeTag 不匹配', String(cp.runtimeTag), '!=', CODE_UPDATE_RUNTIME_TAG)
      } else if (!isSafeUpdateUrl(cpUrl)) {
        logStartup('code package skipped: 地址不安全 ->', cpUrl)
      } else {
        codePackage = {
          url: cpUrl,
          sha256: String(cp.sha256 || '').trim(),
          size: Number(cp.size || 0),
          runtimeTag: String(cp.runtimeTag || ''),
        }
      }
    }

    logStartup('update check: current=' + current + ' latest=' + latest + ' hasUpdate=' + (compareVersion(latest, current) > 0) + ' codePackage=' + !!codePackage)

    // 有新版本但拿不到可用的增量包 → 直接报错，不要假装可以更新
    if (compareVersion(latest, current) > 0 && !codePackage) {
      return {
        ok: false,
        reason: 'no-package',
        current,
        message: '云端未提供可用的更新包（可能运行时版本不匹配或清单缺少 codePackage），请联系开发者。',
      }
    }

    return {
      ok: true,
      current,
      latest,
      hasUpdate: compareVersion(latest, current) > 0,
      notes,
      publishedAt: String(m.publishedAt || ''),
      force: !!m.force,
      codePackage,
    }
  } catch (e) {
    const msg = friendlyNetError(e, '检查更新')
    logStartup('update check failed:', String((e && e.message) || e), '(url=' + url + ')')
    return { ok: false, reason: 'network', current, message: msg }
  } finally {
    clearTimeout(timer)
  }
})

/** 用系统默认浏览器打开下载页（只允许 http/https，避免被拿来执行本地文件） */
ipcMain.handle('shell:openExternal', async (_e, url) => {
  const u = String(url || '')
  if (!/^https?:\/\//i.test(u)) return false
  await shell.openExternal(u)
  return true
})

/* ------------------------------------------------------------------ *
 * 下载更新包 → 覆盖安装（2026-09-28）
 * ------------------------------------------------------------------ */

/** 同一时刻只允许一个下载任务 */
const updateDownload = { busy: false }

const UPDATE_DOWNLOAD_TIMEOUT_MS = 5 * 60 * 1000

function updateDownloadDir() {
  return path.join(os.tmpdir(), 'vfx-studio-update')
}

/** 下载更新包到系统临时目录，进度通过 update:progress 事件推给窗口 */
ipcMain.handle('update:download', async (event, opts) => {
  // 下载同样受更新资格限制：资格不足（基础版/到期）不允许拉取增量包。
  const elg = await proGate.updateEligible(loadAppState(), { clockSuspect })
  if (elg !== 'active') {
    logStartup('update download: blocked, eligibility=' + elg)
    return {
      ok: false,
      reason: 'subscription-blocked',
      blockedReason: elg === 'clock' ? 'clock-suspect' : elg === 'expired' ? 'subscription-expired' : 'not-activated',
    }
  }
  const url = String((opts && opts.url) || '')
  const sha256 = String((opts && opts.sha256) || '').trim()
  if (updateDownload.busy) return { ok: false, reason: 'busy' }
  if (!isSafeUpdateUrl(url)) return { ok: false, reason: 'bad-url' }

  const name = String((opts && opts.fileName) || '').replace(/[^a-zA-Z0-9._-]/g, '_')
  // 只接受轻量增量包 .zip（exe 完整安装包路径已于 2026-09-29 移除）
  if (!name.toLowerCase().endsWith('.zip')) return { ok: false, reason: 'bad-file' }

  updateDownload.busy = true
  try {
    const dir = updateDownloadDir()
    await fsp.mkdir(dir, { recursive: true })
    const file = path.join(dir, name)

    const ac = new AbortController()
    const timer = setTimeout(() => ac.abort(), UPDATE_DOWNLOAD_TIMEOUT_MS)
    try {
      const res = await fetch(url, { signal: ac.signal, redirect: 'follow' })
      if (!res.ok || !res.body) return { ok: false, reason: 'http', message: friendlyHttpError(res.status) }
      const total = Number(res.headers.get('content-length') || 0)

      const reader = res.body.getReader()
      const chunks = []
      let received = 0
      let lastSent = 0
      for (;;) {
        const { done, value } = await reader.read()
        if (done) break
        chunks.push(Buffer.from(value))
        received += value.length
        const now = Date.now()
        if (now - lastSent > 120) {
          lastSent = now
          event.sender.send('update:progress', { received, total })
        }
      }
      const buf = Buffer.concat(chunks)

      // 清单给了 sha256 就校验，防止下载损坏或被劫持
      if (sha256) {
        const hash = require('node:crypto').createHash('sha256').update(buf).digest('hex')
        if (hash.toLowerCase() !== sha256.toLowerCase()) {
          return { ok: false, reason: 'checksum', message: '文件校验不一致，已中止' }
        }
      }

      await fsp.writeFile(file, buf)
      event.sender.send('update:progress', { received: buf.length, total: buf.length || total, done: true })
      return { ok: true, file, size: buf.length }
    } finally {
      clearTimeout(timer)
    }
  } catch (e) {
    const msg = friendlyNetError(e, '下载更新包')
    logStartup('update download failed:', String((e && e.message) || e))
    return { ok: false, reason: 'network', message: msg }
  } finally {
    updateDownload.busy = false
  }
})

/* ------------------------------------------------------------------ *
 * 轻量增量更新 —— 唯一的更新方式（2026-09-29 起移除 exe 完整安装包路径）
 *
 * 完整安装包 130MB，但其中 99% 是永远不变的 Electron 运行时与 ffmpeg；
 * 我们每次真正改的只有 resources/app（实测 1.01MB，打包后 0.58MB）。
 * 所以只发这个代码包：下载几百 KB → 覆盖 resources/app → 重启。
 * runtimeTag 不匹配（Electron 大版本升级）时不再尝试全量安装，只提示联系开发者。
 * ------------------------------------------------------------------ */

/** CRC32 查表（手写，避免依赖 zlib.crc32——旧版 Electron 内置 Node 可能没有） */
const CRC_TABLE = (() => {
  const t = new Int32Array(256)
  for (let n = 0; n < 256; n++) {
    let c = n
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1
    t[n] = c
  }
  return t
})()

function crc32Buf(buf) {
  let c = ~0
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8)
  return (~c) >>> 0
}

/**
 * 解析标准 zip（方法 0=store / 8=deflate），只用 Node 内置 zlib，零第三方依赖。
 * 与 scripts/pack-code-update.cjs 生成的包配套。
 */
function unzipBuffer(buf) {
  let eo = -1
  for (let i = buf.length - 22; i >= 0; i--) {
    if (buf.readUInt32LE(i) === 0x06054b50) {
      eo = i
      break
    }
  }
  if (eo < 0) throw new Error('不是有效的 zip 包')
  const count = buf.readUInt16LE(eo + 10)
  let p = buf.readUInt32LE(eo + 16)
  const out = []
  for (let i = 0; i < count; i++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('zip 中央目录损坏')
    const method = buf.readUInt16LE(p + 10)
    const wantCrc = buf.readUInt32LE(p + 16)
    const compSize = buf.readUInt32LE(p + 20)
    const uncompSize = buf.readUInt32LE(p + 24)
    const nameLen = buf.readUInt16LE(p + 28)
    const extraLen = buf.readUInt16LE(p + 30)
    const commentLen = buf.readUInt16LE(p + 32)
    const localOff = buf.readUInt32LE(p + 42)
    const name = buf.toString('utf8', p + 46, p + 46 + nameLen)
    p += 46 + nameLen + extraLen + commentLen

    const lNameLen = buf.readUInt16LE(localOff + 26)
    const lExtraLen = buf.readUInt16LE(localOff + 28)
    const start = localOff + 30 + lNameLen + lExtraLen
    const raw = buf.subarray(start, start + compSize)
    const data = method === 8 ? require('node:zlib').inflateRawSync(raw) : Buffer.from(raw)
    if (data.length !== uncompSize) throw new Error('解压后大小不符：' + name)
    if (crc32Buf(data) !== wantCrc) throw new Error('校验不一致：' + name)
    out.push({ name: String(name).replace(/\\/g, '/').replace(/^\/+/, ''), data })
  }
  return out
}

/** 覆盖前备份当前代码，万一新版起不来还能手工回滚（最多留 2 份） */
function backupCode() {
  try {
    const ud = app.getPath('userData')
    const dest = path.join(ud, 'code-backup-' + new Date().toISOString().slice(0, 10).replace(/-/g, ''))
    fs.mkdirSync(dest, { recursive: true })
    for (const rel of ['dist', 'electron']) {
      const from = path.join(APP_CODE_ROOT, rel)
      if (fs.existsSync(from)) fs.cpSync(from, path.join(dest, rel), { recursive: true, force: true })
    }
    const pj = path.join(APP_CODE_ROOT, 'package.json')
    if (fs.existsSync(pj)) fs.copyFileSync(pj, path.join(dest, 'package.json'))
    try {
      const olds = fs.readdirSync(ud).filter((d) => /^code-backup-\d{8}$/.test(d)).sort()
      while (olds.length > 2) {
        const first = olds.shift()
        if (first) fs.rmSync(path.join(ud, first), { recursive: true, force: true })
      }
    } catch {
      /* 忽略 */
    }
    logStartup('code backup ->', dest)
    return dest
  } catch (e) {
    logStartup('code backup failed:', String((e && e.message) || e))
    return ''
  }
}

/**
 * 应用轻量增量包：校验 → 备份 → 写出新文件 → 清理旧资源 → 重启。
 *
 * 为什么可以在运行中直接覆盖：实测 Windows 上 Node 加载过的 .js/.html/.css
 * 文件句柄已释放，允许覆盖甚至删除（electron.exe 本身被占用，但我们不动它）。
 * 用户数据（app-state.json / autosave.json / music）在 userData 目录，完全不受影响。
 */
ipcMain.handle('update:applyCode', async (_e, opts) => {
  // 应用更新包同样受更新资格限制（防御性：避免绕过 check/download 直接投递包）。
  const elg = await proGate.updateEligible(loadAppState(), { clockSuspect })
  if (elg !== 'active') {
    logStartup('update applyCode: blocked, eligibility=' + elg)
    return {
      ok: false,
      reason: 'subscription-blocked',
      blockedReason: elg === 'clock' ? 'clock-suspect' : elg === 'expired' ? 'subscription-expired' : 'not-activated',
    }
  }
  const file = String((opts && opts.file) || '')
  const sha256 = String((opts && opts.sha256) || '').trim()
  if (!file.toLowerCase().endsWith('.zip') || !fs.existsSync(file)) return { ok: false, reason: 'no-file' }

  try {
    const buf = fs.readFileSync(file)
    if (sha256) {
      const h = require('node:crypto').createHash('sha256').update(buf).digest('hex')
      if (h.toLowerCase() !== sha256.toLowerCase()) {
        return { ok: false, reason: 'checksum', message: '更新包校验不一致，已中止' }
      }
    }

    const entries = unzipBuffer(buf)
    if (!entries.length) return { ok: false, reason: 'empty', message: '更新包里没有文件' }

    const root = APP_CODE_ROOT
    const keep = new Set()
    // 越界检查：任何 ../ 都拒绝，只允许写进 APP_CODE_ROOT
    for (const e of entries) {
      const rel = e.name
      if (!rel || rel.split('/').includes('..')) return { ok: false, reason: 'bad-entry', message: '更新包含非法路径' }
      const dest = path.join(root, rel)
      if (!path.resolve(dest).startsWith(path.resolve(root))) {
        return { ok: false, reason: 'bad-entry', message: '更新包含越界路径' }
      }
      keep.add(rel)
    }

    // 更新会覆盖 resources/app（甚至把 app.asar 改名），先把示例素材捞进 userData 保命，
    // 否则「不带示例素材」的增量包一装，用户这台机器上的示例就再也没了
    const seeded = seedSampleMedia()
    if (seeded) logStartup('sample media preserved before update ->', seeded)

    // 备份旧代码（必须在覆盖之前，否则备份到的就是新代码了）
    const backup = backupCode()

    // 写出全部新文件
    for (const e of entries) {
      const dest = path.join(root, e.name)
      fs.mkdirSync(path.dirname(dest), { recursive: true })
      fs.writeFileSync(dest, e.data)
    }

    // 清理 dist/assets 里的旧 hash 文件（新版文件名带新 hash，旧的已无用）
    const assets = path.join(root, 'dist', 'assets')
    if (fs.existsSync(assets)) {
      for (const f of fs.readdirSync(assets)) {
        if (keep.has(`dist/assets/${f}`)) continue
        try {
          fs.rmSync(path.join(assets, f), { force: true })
        } catch {
          /* 占用中就算了，下次启动再清 */
        }
      }
    }

    // 安装版（resources/app.asar）需要把 asar 文件移走，重启后 Electron 才会加载刚写好的 resources/app/ 目录
    if (IS_PACKED_ASAR && fs.existsSync(APP_ASAR_FILE)) {
      try {
        const bak = APP_ASAR_FILE + '.bak'
        if (fs.existsSync(bak)) fs.rmSync(bak, { force: true })
        fs.renameSync(APP_ASAR_FILE, bak)
        logStartup('asar moved ->', bak)
      } catch (e) {
        logStartup('asar move failed:', String((e && e.message) || e))
        // 不把 asar 移走的话，重启仍然加载旧 asar，新代码不会生效。
        return {
          ok: false,
          reason: 'asar-locked',
          message: '旧安装包（app.asar）无法替换，请关闭客户端后重试，或下载完整安装包覆盖安装。',
        }
      }
    }

    logStartup('code update applied ->', root, entries.length + ' files')
    // 重启让新代码生效
    setTimeout(() => {
      app.relaunch()
      app.exit(0)
    }, 700)
    return { ok: true, files: entries.length, backup }
  } catch (e) {
    const msg = friendlyNetError(e, '写入新版本')
    logStartup('code update failed:', String((e && e.message) || e))
    return { ok: false, reason: 'apply', message: msg }
  }
})

/* ------------------------------------------------------------------ *
 * 音乐库：上传保存 / 列表
 * ------------------------------------------------------------------ */

ipcMain.handle('music:save', async (_e, { name, ext, data }) => {
  const id = 'm' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6)
  const safeExt = String(ext || 'mp3').replace(/[^a-z0-9]/gi, '').toLowerCase() || 'mp3'
  const file = `${id}.${safeExt}`
  await fsp.writeFile(path.join(musicDir(), file), Buffer.from(data))
  return { file, name: String(name || file).slice(0, 80) }
})

ipcMain.handle('music:list', async () => {
  try {
    const files = await fsp.readdir(musicDir())
    return files
      .filter((f) => /\.(mp3|wav|m4a|ogg|flac|aac)$/i.test(f))
      .map((f) => ({ file: f, name: f.replace(/\.[^.]+$/, '') }))
  } catch {
    return []
  }
})

ipcMain.handle('music:delete', async (_e, { file }) => {
  try {
    const safe = path.basename(String(file || ''))
    if (!safe) return { ok: false }
    const fp = path.join(musicDir(), safe)
    await fsp.unlink(fp)
    return { ok: true }
  } catch {
    return { ok: false }
  }
})

/* ------------------------------------------------------------------ *
 * 本地素材持久化：注册原路径（源视频 / ImageWall 的图片），刷新或重启后仍可加载
 * ------------------------------------------------------------------ */

/** 媒体注册（video:register 与人像 mask 注册共用）：已注册过直接复用 token */
function registerMedia(filePath) {
  if (!filePath || !fs.existsSync(filePath)) throw new Error('素材文件不存在')
  const reg = loadMediaRegistry()
  let token = Object.keys(reg).find((k) => reg[k] === filePath)
  if (!token) {
    token = 'v' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6)
    reg[token] = filePath
    saveMediaRegistry(reg)
  }
  return token
}

ipcMain.handle('video:register', async (_e, filePath) => {
  return { token: registerMedia(filePath) }
})


/** 从 `ffmpeg -i` 的 stderr 解析时长（秒）与视频尺寸（宽×高） */
function parseVideoMeta(stderr) {
  const s = String(stderr || '')
  let duration = 0
  const dm = s.match(/Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)/)
  if (dm) {
    duration = (+dm[1]) * 3600 + (+dm[2]) * 60 + parseFloat(dm[3])
  } else {
    const ds = s.match(/Duration:\s*(\d+(?:\.\d+)?)\s*s/i)
    if (ds) duration = parseFloat(ds[1])
  }
  let width = 0
  let height = 0
  const vm = s.match(/Stream #\d+:\d+.*?Video:.*?(\d{2,5})x(\d{2,5})/)
  if (vm) {
    width = parseInt(vm[1], 10)
    height = parseInt(vm[2], 10)
  }
  return { duration, width, height }
}

/**
 * 视频分析：抽帧缩略图 + 解码音频波形（真实解析，还原剪映观感）。
 * 桌面端 filePath 即用户导入文件原路径；返回 jpeg dataURL 缩略图与 0..1 归一化波形。
 */
ipcMain.handle('video:probe', async (_e, filePath, opts) => {
  if (!filePath || !fs.existsSync(filePath)) return { ok: false, reason: '素材文件不存在' }
  const thumbs = Math.min(24, Math.max(1, opts?.thumbs ?? 8))
  const waveBuckets = Math.min(800, Math.max(20, opts?.wave ?? 200))
  const tmp = await fsp.mkdtemp(path.join(os.tmpdir(), 'vfx-probe-'))
  const log = (_m, ...a) => {}
  try {
    // 1) 时长 / 尺寸
    const meta = await new Promise((resolve) => {
      execFile(
        ffmpegPath(),
        ['-hide_banner', '-i', filePath],
        { maxBuffer: 1024 * 1024 * 8, timeout: 30000 },
        (_err, _stdout, stderr) => resolve(parseVideoMeta(stderr)),
      )
    })
    const dur = meta.duration || 0
    if (dur <= 0) return { ok: false, reason: '无法解析视频时长' }

    // 2) 等距抽帧缩略图（单条 ffmpeg，fps=N/duration 保证均匀分布）
    const thumbPattern = path.join(tmp, 't_%03d.jpg')
    await new Promise((resolve) => {
      const vf = `fps=${thumbs}/${dur.toFixed(3)},scale=160:-2`
      execFile(
        ffmpegPath(),
        ['-y', '-i', filePath, '-vf', vf, '-frames:v', String(thumbs), thumbPattern],
        { maxBuffer: 16 * 1024 * 1024, timeout: 60000 },
        () => resolve(),
      )
    })
    const thumbnailData = []
    for (let i = 1; i <= thumbs; i++) {
      const p = path.join(tmp, `t_${String(i).padStart(3, '0')}.jpg`)
      if (fs.existsSync(p)) {
        const b64 = fs.readFileSync(p).toString('base64')
        thumbnailData.push(`data:image/jpeg;base64,${b64}`)
      }
    }

    // 3) 解码音频为 PCM，按桶取峰谷归一化为波形（无音轨则回退为平直波形）
    let waveform = []
    try {
      const pcm = await new Promise((resolve, reject) => {
        execFile(
          ffmpegPath(),
          ['-y', '-i', filePath, '-vn', '-ac', '1', '-ar', '8000', '-f', 's16le', '-'],
          { encoding: 'buffer', maxBuffer: 64 * 1024 * 1024, timeout: 60000 },
          (err, stdout) => (err ? reject(err) : resolve(stdout)),
        )
      })
      const samples = new Int16Array(pcm.buffer, pcm.byteOffset, pcm.length >> 1)
      const step = Math.max(1, Math.floor(samples.length / waveBuckets))
      let maxAbs = 0
      for (let i = 0; i < samples.length; i++) maxAbs = Math.max(maxAbs, Math.abs(samples[i]))
      const norm = maxAbs > 0 ? 1 / maxAbs : 0
      for (let b = 0; b < waveBuckets; b++) {
        let peak = 0
        const from = b * step
        const to = Math.min(samples.length, from + step)
        for (let i = from; i < to; i++) peak = Math.max(peak, Math.abs(samples[i]) * norm)
        waveform.push(peak)
      }
    } catch {
      // 无音轨或解码失败：用极低的平直波形占位（前端仍会画出一条线）
      waveform = new Array(waveBuckets).fill(0.04)
    }

    // 4) 首帧封面（供历史舞台缩略图，与缩略图同分辨率档）
    let poster = ''
    try {
      const posterPath = path.join(tmp, 'poster.jpg')
      await new Promise((resolve) => {
        execFile(
          ffmpegPath(),
          ['-y', '-ss', '0.1', '-i', filePath, '-frames:v', '1', '-vf', 'scale=360:-2', '-q:v', '5', posterPath],
          { maxBuffer: 8 * 1024 * 1024, timeout: 30000 },
          () => resolve(),
        )
      })
      if (fs.existsSync(posterPath)) {
        poster = `data:image/jpeg;base64,${fs.readFileSync(posterPath).toString('base64')}`
      }
    } catch {
      /* 封面失败不影响主流程 */
    }

    return {
      ok: true,
      thumbnails: thumbnailData,
      waveform,
      poster,
      duration: meta.duration,
      width: meta.width,
      height: meta.height,
    }
  } catch (e) {
    return { ok: false, reason: String((e && e.message) || e) }
  } finally {
    try {
      fs.rmSync(tmp, { recursive: true, force: true })
    } catch {
      /* 忽略 */
    }
  }
})

/* 新手「看个示例」：把打包内的示例素材整包 seed 到 userData 并逐个注册 token，
   走与用户导入完全相同的播放通道（/video?token=、/img?token=），这样时长/导出行为都一致。
   main.cjs 在 resources/app/electron/ 下，故示例素材在 ../dist/samples/media/ */
const SAMPLE_MEDIA_REL = ['dist', 'samples', 'media']

/** 示例素材在 userData 里的落点（整包目录） */
function sampleMediaUserDir() {
  return path.join(app.getPath('userData'), 'samples', 'media')
}

/** 代码区里示例素材目录的可能落点（asar 内 / app 目录 / 开发态多一层） */
function findBundledSampleMediaDir() {
  const candidates = [
    path.join(__dirname, '..', ...SAMPLE_MEDIA_REL),
    // 兜底：目录层级不同（如开发态）时再上一层找
    path.join(__dirname, '..', '..', ...SAMPLE_MEDIA_REL),
    path.join(APP_CODE_ROOT, ...SAMPLE_MEDIA_REL),
  ]
  return candidates.find((c) => fs.existsSync(c) && fs.statSync(c).isDirectory()) || ''
}

/** 把打包内的示例素材「捞」一份到 userData。
 *  ⚠️ 为什么必须复制到 userData：
 *    resources/app 是「代码区」，每次增量更新都会被 zip 覆盖；而示例素材不进增量包
 *    （mp4 压不动，带上会让包从 0.59MB 涨到 20MB+）。靠代码区里那份，用户一升级就可能没了。
 *    userData 是「数据区」，更新永远不碰（安装前也会备份），所以放这里最稳。
 *  另外安装版更凶险：装的是 resources/app.asar，第一次收到增量更新时 asar 会被改名成
 *    .bak，程序改从 resources/app/ 目录加载 —— 那份目录是 zip 解出来的，zip 里没素材就真没了。
 *  逐个文件比对大小：缺的、变了名的、换过内容的都补一遍（示例换版后自动跟上）。 */
function seedSampleMedia() {
  const src = findBundledSampleMediaDir()
  const dest = sampleMediaUserDir()
  // 代码区没有素材目录（升级包覆盖后）→ userData 里已有的那份就是全部家底，直接用
  if (!src) return fs.existsSync(dest) ? dest : ''
  try {
    fs.mkdirSync(dest, { recursive: true })
    for (const f of fs.readdirSync(src)) {
      const s = path.join(src, f)
      if (!fs.statSync(s).isFile()) continue
      const d = path.join(dest, f)
      let same = false
      try {
        same = fs.existsSync(d) && fs.statSync(d).size === fs.statSync(s).size
      } catch {
        same = false
      }
      if (same) continue
      // 用 readFileSync + writeFileSync，不用 copyFileSync：源可能在 asar 里，读接口更稳
      fs.writeFileSync(d, fs.readFileSync(s))
      logStartup('sample media seeded ->', d)
    }
  } catch (e) {
    logStartup('sample media seed failed:', String((e && e.message) || e))
    return ''
  }
  return dest
}

/** 示例素材：seed 到 userData 后为每个文件注册 token，返回 文件名 → token 映射。
 *  前端拿到映射后回填进卡片参数，示例里的图片/视频就能正常显示。 */
ipcMain.handle('sample:media', async () => {
  const dir = seedSampleMedia()
  if (!dir) return { ok: false, reason: 'missing', map: {} }
  const reg = loadMediaRegistry()
  const map = {}
  let dirty = false
  try {
    for (const f of fs.readdirSync(dir)) {
      const p = path.join(dir, f)
      if (!fs.statSync(p).isFile()) continue
      let token = Object.keys(reg).find((k) => reg[k] === p)
      if (!token) {
        token = 'v' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6)
        reg[token] = p
        dirty = true
      }
      map[f] = token
    }
  } catch (e) {
    logStartup('sample media token failed:', String((e && e.message) || e))
    return { ok: false, reason: 'read', map: {} }
  }
  if (dirty) saveMediaRegistry(reg)
  return { ok: true, map }
})

/* ------------------------------------------------------------------ *
 * 编排自动保存：写入 userData/autosave.json（与页面 origin 无关，重启必恢复）
 * ------------------------------------------------------------------ */

ipcMain.on('autosave:load', (e) => {
  try {
    e.returnValue = fs.readFileSync(autosavePath(), 'utf8')
  } catch {
    e.returnValue = ''
  }
})

ipcMain.on('autosave:save', (_e, data) => {
  try {
    fs.writeFileSync(autosavePath(), typeof data === 'string' ? data : '')
  } catch {
    /* 忽略写入失败 */
  }
})

/* ------------------------------------------------------------------ *
 * 历史舞台快照：写入 userData/history.json（与页面 origin 无关）
 * ------------------------------------------------------------------ */

ipcMain.on('history:load', (e) => {
  try {
    e.returnValue = fs.readFileSync(historyPath(), 'utf8')
  } catch {
    e.returnValue = ''
  }
})

ipcMain.on('history:save', (_e, data) => {
  try {
    fs.writeFileSync(historyPath(), typeof data === 'string' ? data : '')
  } catch {
    /* 忽略写入失败 */
  }
})

/* ------------------------------------------------------------------ *
 * AI 状态键值存储：userData/app-state.json（与页面 origin 无关，重启必恢复）。
 * 存风格档案 / 修正记录 / 编排基线 / 导出快照 / AI 配置等小体量 JSON 字符串。
 * 一次启动只在首次读取时读盘，之后走内存缓存。
 * ------------------------------------------------------------------ */

function appStatePath() {
  return path.join(app.getPath('userData'), 'app-state.json')
}

let appStateCache = null

function loadAppState() {
  if (appStateCache) return appStateCache
  try {
    const obj = JSON.parse(fs.readFileSync(appStatePath(), 'utf8'))
    appStateCache = obj && typeof obj === 'object' ? obj : {}
  } catch {
    appStateCache = {}
  }
  return appStateCache
}

/* ------------------------------------------------------------------ *
 * 时钟回拨检测（2026-11-02 安全加固）
 * 订阅有效性只靠 payload.exp 与本地 Date.now() 比 ⇒ 用户把 Windows 日期往回拨
 * 几天，PRO 就一直不过期（零成本破解，比改代码简单得多）。
 * 对策：每次启动把「见过的最晚时间」当高水位写进两处（app-state.json + HKCU 注册表），
 * 下次启动若 now 比高水位倒退超过 24h ⇒ 判定时钟异常，**期限码一律按已到期处理**
 * （永久码 exp=0 不受影响）；时钟正常时持续推进高水位。
 * 用注册表作第二处：删掉 json 删不掉它；两处都清也得先知道有这回事。
 * ------------------------------------------------------------------ */
const CLOCK_KEY = 'vfx-clock:lastSeen'
const CLOCK_SLACK = 24 * 3600 * 1000
/** 本次启动是否判定为「时钟被回拨」，供 PRO 门控 / 更新门控 / 渲染层提示共用 */
let clockSuspect = false

function regReadLastSeen() {
  if (process.platform !== 'win32') return 0
  try {
    const { execFileSync } = require('child_process')
    const out = execFileSync('reg', ['query', 'HKCU\\Software\\VFXStudio', '/v', 'lastSeen'], {
      encoding: 'utf8',
      timeout: 4000,
      windowsHide: true,
    })
    const m = out.match(/lastSeen\s+REG_SZ\s+(\d+)/i)
    return m ? Number(m[1]) || 0 : 0
  } catch {
    return 0
  }
}

function regWriteLastSeen(v) {
  if (process.platform !== 'win32') return
  try {
    const { execFileSync } = require('child_process')
    execFileSync(
      'reg',
      ['add', 'HKCU\\Software\\VFXStudio', '/v', 'lastSeen', '/t', 'REG_SZ', '/d', String(v), '/f'],
      { encoding: 'utf8', timeout: 4000, windowsHide: true },
    )
  } catch {
    /* 注册表写不进去不影响主流程（还有 app-state 那一路高水位） */
  }
}

/** 启动时调一次：比对高水位 → 判定回拨 → 推进高水位 */
function touchClockGuard() {
  const now = Date.now()
  const state = loadAppState()
  const fromState = Number(state[CLOCK_KEY]) || 0
  const fromReg = regReadLastSeen()
  const lastSeen = Math.max(fromState, fromReg)
  const suspect = lastSeen > 0 && now < lastSeen - CLOCK_SLACK
  clockSuspect = suspect
  if (!suspect) {
    const next = Math.max(lastSeen, now)
    if (next > fromState) {
      state[CLOCK_KEY] = String(next)
      try {
        fs.writeFileSync(appStatePath(), JSON.stringify(state))
      } catch {
        /* 忽略 */
      }
    }
    if (next > fromReg) regWriteLastSeen(next)
  }
  logStartup(
    'clock guard:',
    suspect
      ? `SUSPECT now=${new Date(now).toISOString()} lastSeen=${new Date(lastSeen).toISOString()}`
      : 'ok',
  )
  return suspect
}

ipcMain.on('kv:load', (e, key) => {
  e.returnValue = typeof key === 'string' ? loadAppState()[key] || '' : ''
})

ipcMain.on('kv:save', (_e, { key, data }) => {
  if (typeof key !== 'string' || !key) return
  const state = loadAppState()
  if (typeof data === 'string' && data) state[key] = data
  else delete state[key]
  try {
    fs.writeFileSync(appStatePath(), JSON.stringify(state))
  } catch {
    /* 忽略写入失败 */
  }
})

/* ------------------------------------------------------------------ *
 * R25 草稿箱：多槽工程持久化（userData/drafts/）
 * ------------------------------------------------------------------ *
 * 为什么不用 localStorage / IndexedDB：生产态页面由本地 HTTP server 的随机端口
 * 提供，origin 每次启动都变，按 origin 隔离的持久层换端口就读不到旧数据。
 *
 * 目录布局：
 *   userData/drafts/index.json            索引 + 元数据（缩略图 dataURL 直接放 meta）
 *   userData/drafts/d-<id>.json          单份草稿全文（project / chat / media）
 *   userData/drafts/d-<id>.corrupt-<ts>  损坏草稿隔离（不覆盖、不静默丢弃）
 *
 * 写入一律 tmp → rename 原子替换，避免写到一半断电留下半截 JSON。
 * 素材只存 token 引用，绝不随草稿复制源文件；删草稿也不动 media-registry / music。
 * ------------------------------------------------------------------ */

const DRAFTS_INDEX_SCHEMA = 1

function draftsDir() {
  const d = path.join(app.getPath('userData'), 'drafts')
  if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true })
  return d
}

function draftsIndexPath() {
  return path.join(draftsDir(), 'index.json')
}

/** id 只接受 [A-Za-z0-9_-]，杜绝路径穿越 */
function safeProjectDraftId(id) {
  return typeof id === 'string' && /^[A-Za-z0-9_-]{1,64}$/.test(id) ? id : ''
}

function draftDocPath(id) {
  return path.join(draftsDir(), `d-${id}.json`)
}

function newProjectDraftId() {
  return 'd' + Date.now().toString(36) + '-' + crypto.randomBytes(4).toString('hex')
}

function appVersionSafe() {
  try {
    return typeof app.getVersion === 'function' ? app.getVersion() : ''
  } catch {
    return ''
  }
}

/** JSON 原子写：先写同目录 tmp，再 rename 覆盖（Node 在 Windows 的 rename 支持覆盖）。
 *  杀软偶尔会锁住目标文件 ⇒ 兜底先 unlink 再 rename；仍失败则异常上抛由 handler 处理。 */
function atomicWriteJson(file, value) {
  const tmp = `${file}.tmp-${process.pid}-${crypto.randomBytes(3).toString('hex')}`
  const text = typeof value === 'string' ? value : JSON.stringify(value)
  try {
    fs.writeFileSync(tmp, text, 'utf8')
    try {
      fs.renameSync(tmp, file)
    } catch {
      try {
        fs.unlinkSync(file)
      } catch {
        /* 目标本来就不存在 */
      }
      fs.renameSync(tmp, file)
    }
  } finally {
    try {
      if (fs.existsSync(tmp)) fs.unlinkSync(tmp)
    } catch {
      /* ignore */
    }
  }
}

function emptyDraftIndex() {
  return { schema: DRAFTS_INDEX_SCHEMA, lastDraftId: '', items: [], migrated: false }
}

/** 读索引：坏档隔离成 index.json.corrupt-<ts> 后重建空索引，绝不静默丢弃用户数据 */
function loadDraftIndex() {
  const p = draftsIndexPath()
  try {
    const obj = JSON.parse(fs.readFileSync(p, 'utf8'))
    if (!obj || typeof obj !== 'object' || !Array.isArray(obj.items)) throw new Error('bad index')
    return obj
  } catch {
    try {
      if (fs.existsSync(p)) fs.renameSync(p, `${p}.corrupt-${Date.now()}`)
    } catch {
      /* ignore */
    }
    const empty = emptyDraftIndex()
    try {
      atomicWriteJson(p, empty)
    } catch {
      /* ignore */
    }
    return empty
  }
}

function saveDraftIndex(idx) {
  atomicWriteJson(draftsIndexPath(), idx)
}

/** 读单档：结构损坏时隔离成 d-<id>.corrupt-<ts>.json，返回 corrupt 供 UI 提示 */
function readDraftDoc(id) {
  const safe = safeProjectDraftId(id)
  if (!safe) return { ok: false, reason: 'bad-id' }
  const p = draftDocPath(safe)
  let raw
  try {
    raw = fs.readFileSync(p, 'utf8')
  } catch {
    return { ok: false, reason: 'missing' }
  }
  try {
    const doc = JSON.parse(raw)
    if (!doc || typeof doc !== 'object' || !doc.project || typeof doc.project !== 'object') {
      throw new Error('bad doc')
    }
    return { ok: true, doc }
  } catch {
    const dst = path.join(draftsDir(), `d-${safe}.corrupt-${Date.now()}.json`)
    try {
      fs.renameSync(p, dst)
    } catch {
      /* ignore */
    }
    return { ok: false, reason: 'corrupt', quarantined: dst }
  }
}

function emptyProject() {
  return {
    overlay: { version: 1, theme: 'dark', cards: [] },
    srt: [],
    srtName: '',
    stageId: '',
    videos: [],
    videoAssets: [],
    audioAssets: [],
    ratio: '',
  }
}

function cardCountOf(doc) {
  const o = doc && doc.project && doc.project.overlay
  return o && Array.isArray(o.cards) ? o.cards.length : 0
}

/**
 * R27：草稿时长（秒），口径与渲染层 projectDurationSeconds / App 的 contentEnd 完全一致：
 *   「时间轴上最后一个元素的末端」。不含 overlay.duration（默认 30s 兜底）、不含 8s 轴尾余量、
 *   不含 videoAssets 素材池、不含源片被裁掉的部分（只认 videos[].end）。
 */
function durationOf(doc) {
  const num = (v) => { const n = Number(v); return Number.isFinite(n) && n > 0 ? n : 0 }
  const p = doc && doc.project
  const ov = p && p.overlay
  let max = 0
  for (const v of (Array.isArray(p && p.videos) ? p.videos : [])) max = Math.max(max, num(v && v.end))
  for (const c of (ov && Array.isArray(ov.cards) ? ov.cards : [])) max = Math.max(max, num(c && c.end))
  for (const m of (ov && Array.isArray(ov.music) ? ov.music : [])) {
    // K2：加速片段的轴长 = 源时长 / 倍率（这里只影响草稿列表上显示的时长，容错即可）
    const sp = Number(m && m.speed)
    const k = Number.isFinite(sp) && sp >= 1 ? Math.min(10, sp) : 1
    max = Math.max(max, num(m && m.start) + num(m && m.duration) / k)
  }
  for (const l of (Array.isArray(p && p.srt) ? p.srt : [])) max = Math.max(max, num(l && l.end))
  return max
}

/**
 * R26：修正「上次编辑」锚点。
 * lastDraftId 只应由 drafts:setLast（真正打开 / 编辑某份草稿）写入；
 * create / duplicate 绝不抢占。索引里的 id 一旦指向已删除的草稿，
 * 就回落到「最近修改的现存草稿」，绝不变成空串让「上次编辑」整块消失。
 */
function resolveLastDraftId(items, lastId) {
  const list = Array.isArray(items) ? items : []
  if (lastId && list.some((it) => it && it.id === lastId)) return lastId
  const sorted = list.slice().sort((a, b) =>
    (Number(b && b.lastModified) || 0) - (Number(a && a.lastModified) || 0))
  return (sorted[0] && sorted[0].id) || ''
}

/** 把 meta 同步进索引（单点维护，避免各 handler 各写一份导致字段漂移） */
function upsertDraftIndexMeta(id, meta) {
  const idx = loadDraftIndex()
  const prev = idx.items.find((it) => it && it.id === id)
  const nextMeta = { ...(prev || {}), ...(meta || {}), id }
  // ★ R27：渲染层的 docRef 快照可能还是「生成封面之前」的旧 meta.thumb=''。
  //   防抖保存拿旧快照覆盖索引会把刚生成的缩略图抹掉 ⇒ 只要新值没带封面就保留旧封面。
  if (!nextMeta.thumb && prev && prev.thumb) nextMeta.thumb = prev.thumb
  idx.items = idx.items.filter((it) => it && it.id !== id)
  idx.items.push(nextMeta)
  // ★ 绝不在这里把 lastDraftId 改成 id：复制 / 新建草稿会抢走「上次编辑」锚点，
  //   随后删掉那份副本就会连「上次编辑」一起清空（R26 修复的 BUG）。只做自愈。
  idx.lastDraftId = resolveLastDraftId(idx.items, idx.lastDraftId)
  saveDraftIndex(idx)
  return idx
}

ipcMain.handle('drafts:list', async () => {
  try {
    const idx = loadDraftIndex()
    const before = Array.isArray(idx.items) ? idx.items.length : 0
    const items = (Array.isArray(idx.items) ? idx.items : []).filter((it) => {
      if (!it || !safeProjectDraftId(it.id)) return false
      return fs.existsSync(draftDocPath(it.id))
    })
    // 用户手动删了 json 文件 ⇒ 顺手把索引里的僵尸条目清掉
    const healedLast = resolveLastDraftId(items, idx.lastDraftId || '')
    if (items.length !== before || healedLast !== (idx.lastDraftId || '')) {
      idx.items = items
      idx.lastDraftId = healedLast
      saveDraftIndex(idx)
    }
    // R27：老草稿（R26 及以前）索引里没有 duration ⇒ 首次列列表时按工程内容回填一次
    let durationPatched = false
    for (const it of items) {
      if (typeof it.duration === 'number') continue
      let sec = 0
      try {
        sec = durationOf(JSON.parse(fs.readFileSync(draftDocPath(it.id), 'utf8')))
      } catch {
        /* 坏档不影响列表展示；由 drafts:load 负责隔离 */
      }
      it.duration = sec
      durationPatched = true
    }
    if (durationPatched) {
      idx.items = items
      saveDraftIndex(idx)
    }
    items.sort((a, b) => (Number(b.lastModified) || 0) - (Number(a.lastModified) || 0))
    return { ok: true, items, lastDraftId: healedLast }
  } catch (e) {
    return { ok: false, reason: 'list-failed', message: String((e && e.message) || e), items: [], lastDraftId: '' }
  }
})

ipcMain.handle('drafts:create', async (_e, arg) => {
  try {
    const a = arg && typeof arg === 'object' ? arg : {}
    const id = newProjectDraftId()
    const now = Date.now()
    const name = typeof a.name === 'string' && a.name.trim() ? a.name.trim().slice(0, 80) : '未命名草稿'
    const doc = {
      schema: 1,
      meta: {
        id,
        name,
        createdAt: now,
        lastModified: now,
        appVersion: appVersionSafe(),
        edition: typeof a.edition === 'string' ? a.edition : '',
        thumb: '',
        cardCount: 0,
        duration: 0,
        migrated: !!a.migrated,
      },
      project: a.project && typeof a.project === 'object' ? a.project : emptyProject(),
      chat: Array.isArray(a.chat) ? a.chat : [],
      playhead: Number.isFinite(a.playhead) ? a.playhead : 0,
      media: Array.isArray(a.media) ? a.media : [],
    }
    doc.meta.cardCount = cardCountOf(doc)
    doc.meta.duration = durationOf(doc)
    atomicWriteJson(draftDocPath(id), doc)
    upsertDraftIndexMeta(id, doc.meta)
    return { ok: true, id, doc }
  } catch (e) {
    return { ok: false, reason: 'create-failed', message: String((e && e.message) || e) }
  }
})

ipcMain.handle('drafts:load', async (_e, id) => {
  const r = readDraftDoc(id)
  if (!r.ok) return r
  return { ok: true, doc: r.doc }
})

ipcMain.handle('drafts:save', async (_e, arg) => {
  const a = arg && typeof arg === 'object' ? arg : {}
  const id = safeProjectDraftId(a.id)
  if (!id) return { ok: false, reason: 'bad-id' }
  const doc = a.doc
  if (!doc || typeof doc !== 'object' || !doc.project || typeof doc.project !== 'object') {
    return { ok: false, reason: 'bad-doc' }
  }
  try {
    const now = Date.now()
    doc.schema = 1
    doc.meta = { ...(doc.meta || {}), id, lastModified: now }
    if (!doc.meta.createdAt) doc.meta.createdAt = now
    if (!doc.meta.appVersion) doc.meta.appVersion = appVersionSafe()
    doc.meta.cardCount = cardCountOf(doc)
    doc.meta.duration = durationOf(doc)
    atomicWriteJson(draftDocPath(id), doc)
    upsertDraftIndexMeta(id, doc.meta)
    return { ok: true, lastModified: now }
  } catch (e) {
    return { ok: false, reason: 'save-failed', message: String((e && e.message) || e) }
  }
})

ipcMain.handle('drafts:rename', async (_e, arg) => {
  const a = arg && typeof arg === 'object' ? arg : {}
  const id = safeProjectDraftId(a.id)
  const name = typeof a.name === 'string' ? a.name.trim().slice(0, 80) : ''
  if (!id || !name) return { ok: false, reason: 'bad-arg' }
  try {
    const idx = loadDraftIndex()
    const it = idx.items.find((x) => x && x.id === id)
    if (it) it.name = name
    saveDraftIndex(idx)
    const r = readDraftDoc(id)
    if (r.ok) {
      r.doc.meta = { ...(r.doc.meta || {}), name }
      atomicWriteJson(draftDocPath(id), r.doc)
    }
    return { ok: true }
  } catch (e) {
    return { ok: false, reason: 'rename-failed', message: String((e && e.message) || e) }
  }
})

ipcMain.handle('drafts:duplicate', async (_e, id) => {
  const safe = safeProjectDraftId(id)
  if (!safe) return { ok: false, reason: 'bad-id' }
  try {
    const r = readDraftDoc(safe)
    if (!r.ok) return r
    const newId = newProjectDraftId()
    const now = Date.now()
    const copy = JSON.parse(JSON.stringify(r.doc))
    copy.meta = {
      ...(copy.meta || {}),
      id: newId,
      name: `${(copy.meta && copy.meta.name) || '未命名草稿'} 副本`.slice(0, 80),
      createdAt: now,
      lastModified: now,
      migrated: false,
    }
    atomicWriteJson(draftDocPath(newId), copy)
    upsertDraftIndexMeta(newId, copy.meta)
    const idx = loadDraftIndex()
    return { ok: true, id: newId, items: idx.items }
  } catch (e) {
    return { ok: false, reason: 'duplicate-failed', message: String((e && e.message) || e) }
  }
})

/** 删草稿只删自己的 doc / 索引条目；media-registry.json 与 userData/music 是共享池，一律不动 */
ipcMain.handle('drafts:remove', async (_e, id) => {
  const safe = safeProjectDraftId(id)
  if (!safe) return { ok: false, reason: 'bad-id' }
  try {
    try {
      fs.unlinkSync(draftDocPath(safe))
    } catch {
      /* 文件已不存在也算删成功 */
    }
    const idx = loadDraftIndex()
    idx.items = (Array.isArray(idx.items) ? idx.items : []).filter((it) => !it || it.id !== safe)
    // 删掉「上次编辑」所指的那份时，回落到最近修改的现存草稿，而不是清空整块
    idx.lastDraftId = resolveLastDraftId(idx.items, idx.lastDraftId || '')
    saveDraftIndex(idx)
    return { ok: true, items: idx.items }
  } catch (e) {
    return { ok: false, reason: 'remove-failed', message: String((e && e.message) || e) }
  }
})

/** 缩略图直接作为 dataURL 存进 index 的 meta（320px webp 约 10~30KB），
 *  省掉独立 thumb 文件与额外一次 IPC；列表一次 drafts:list 就能全拿到。 */
ipcMain.handle('drafts:setThumb', async (_e, arg) => {
  const a = arg && typeof arg === 'object' ? arg : {}
  const id = safeProjectDraftId(a.id)
  const thumb = typeof a.thumb === 'string' ? a.thumb.slice(0, 400000) : ''
  if (!id) return { ok: false, reason: 'bad-id' }
  try {
    const idx = loadDraftIndex()
    const it = idx.items.find((x) => x && x.id === id)
    if (it) it.thumb = thumb
    saveDraftIndex(idx)
    const r = readDraftDoc(id)
    if (r.ok) {
      r.doc.meta = { ...(r.doc.meta || {}), thumb }
      atomicWriteJson(draftDocPath(id), r.doc)
    }
    return { ok: true }
  } catch (e) {
    return { ok: false, reason: 'thumb-failed', message: String((e && e.message) || e) }
  }
})

ipcMain.handle('drafts:setLast', async (_e, id) => {
  const safe = safeProjectDraftId(id)
  if (!safe) return { ok: false, reason: 'bad-id' }
  try {
    const idx = loadDraftIndex()
    idx.lastDraftId = safe
    saveDraftIndex(idx)
    return { ok: true }
  } catch (e) {
    return { ok: false, reason: 'setlast-failed', message: String((e && e.message) || e) }
  }
})

/** 素材失效降级：批量解析 token → 磁盘路径是否仍存在，供 UI 打红色角标 / 引导重新指定 */
ipcMain.handle('drafts:resolveMedia', async (_e, arg) => {
  const tokens = arg && Array.isArray(arg.tokens) ? arg.tokens : []
  const reg = loadMediaRegistry()
  const map = {}
  for (const t of tokens.slice(0, 500)) {
    if (typeof t !== 'string' || !t) continue
    const p = reg[t]
    if (!p) {
      map[t] = { exists: false, path: '', name: '' }
      continue
    }
    map[t] = { exists: fs.existsSync(p), path: String(p), name: path.basename(String(p)) }
  }
  return { ok: true, map }
})

/** 重新指定失效素材：只更新 registry 里该 token 的映射，草稿内的引用保持不变 */
ipcMain.handle('drafts:relinkMedia', async (_e, arg) => {
  const a = arg && typeof arg === 'object' ? arg : {}
  const token = typeof a.token === 'string' && /^[A-Za-z0-9_-]+$/.test(a.token) ? a.token : ''
  const filePath = typeof a.filePath === 'string' ? a.filePath : ''
  if (!token || !filePath || !fs.existsSync(filePath)) return { ok: false, reason: 'bad-arg' }
  try {
    const reg = loadMediaRegistry()
    reg[token] = filePath
    saveMediaRegistry(reg)
    return { ok: true, token, path: filePath }
  } catch (e) {
    return { ok: false, reason: 'relink-failed', message: String((e && e.message) || e) }
  }
})

/** 弹系统对话框重新选一个媒体文件（配合 relinkMedia 用） */
ipcMain.handle('drafts:pickMediaFile', async (_e, arg) => {
  const a = arg && typeof arg === 'object' ? arg : {}
  try {
    const r = await dialog.showOpenDialog({
      title: a.title || '重新指定素材文件',
      properties: ['openFile'],
      filters: [
        { name: '媒体文件', extensions: ['mp4', 'mov', 'm4v', 'webm', 'png', 'jpg', 'jpeg', 'webp', 'gif', 'bmp'] },
        { name: '所有文件', extensions: ['*'] },
      ],
    })
    if (r.canceled || !r.filePaths || !r.filePaths[0]) return { ok: false, cancelled: true, path: '' }
    return { ok: true, path: r.filePaths[0] }
  } catch (e) {
    return { ok: false, reason: 'pick-failed', message: String((e && e.message) || e), path: '' }
  }
})

/** 首启迁移：把旧的「单槽 autosave.json + 全局 AI 对话」升级成第一份草稿。
 *  ★ 只复制、不删除旧数据：autosave.json 与 vfx-studio:ai-chat-v1 都保留作兜底，
 *    迁移后 index.migrated=true，后续启动不会再跑一次，旧 key 残留也无害。 */
ipcMain.handle('drafts:migrateAutosave', async () => {
  try {
    const idx = loadDraftIndex()
    if (idx.migrated || (Array.isArray(idx.items) && idx.items.length > 0)) {
      return { ok: true, migrated: false, id: idx.lastDraftId || '', reason: 'already-migrated' }
    }

    // 1) 旧单槽工程
    let project = emptyProject()
    try {
      const raw = fs.readFileSync(autosavePath(), 'utf8')
      const parsed = raw ? JSON.parse(raw) : null
      if (parsed && typeof parsed === 'object') {
        const { srt, srtName, stageId, videos, videoAssets, audioAssets, ratio, ...doc } = parsed
        project = {
          overlay: doc && typeof doc === 'object' ? doc : emptyProject().overlay,
          srt: Array.isArray(srt) ? srt : [],
          srtName: typeof srtName === 'string' ? srtName : '',
          stageId: typeof stageId === 'string' ? stageId : '',
          videos: Array.isArray(videos) ? videos : [],
          videoAssets: Array.isArray(videoAssets) ? videoAssets : [],
          audioAssets: Array.isArray(audioAssets) ? audioAssets : [],
          ratio: typeof ratio === 'string' ? ratio : '',
        }
      }
    } catch {
      /* 坏 autosave 不阻断迁移，退回空工程 */
    }

    // 2) 旧全局 AI 对话（app-state.json 的 vfx-studio:ai-chat-v1）
    let chat = []
    try {
      const st = loadAppState()
      const c = st['vfx-studio:ai-chat-v1']
      if (typeof c === 'string' && c) {
        const arr = JSON.parse(c)
        if (Array.isArray(arr)) chat = arr.slice(-40)
      }
    } catch {
      /* ignore */
    }

    // 3) 收集素材引用（只存 token → 路径，不复制文件）
    const reg = loadMediaRegistry()
    const media = []
    const seen = new Set()
    const pushToken = (t) => {
      if (typeof t !== 'string' || !t || seen.has(t)) return
      const p = reg[t]
      if (!p) return
      seen.add(t)
      media.push({ token: t, path: String(p), name: path.basename(String(p)) })
    }
    const allVideos = [...(project.videos || []), ...(project.videoAssets || [])]
    for (const v of allVideos) {
      if (v && typeof v.token === 'string') pushToken(v.token)
    }
    const cards = project.overlay && Array.isArray(project.overlay.cards) ? project.overlay.cards : []
    for (const c of cards) {
      const params = c && c.params
      if (!params || typeof params !== 'object') continue
      for (const key of Object.keys(params)) {
        const val = params[key]
        if (typeof val !== 'string') continue
        if (/^[A-Za-z0-9_-]+$/.test(val.trim())) pushToken(val.trim())
        else if (/[\n|,，]/.test(val)) {
          for (const part of val.split(/[\n|,，]/)) pushToken(part.trim())
        }
      }
    }

    // 4) 空启动不凭空造草稿
    const hasContent =
      cards.length > 0 ||
      (project.srt || []).length > 0 ||
      (project.videos || []).length > 0 ||
      (project.videoAssets || []).length > 0 ||
      (project.audioAssets || []).length > 0 ||
      chat.length > 0
    if (!hasContent) {
      idx.migrated = true
      saveDraftIndex(idx)
      return { ok: true, migrated: false, id: '', reason: 'nothing-to-migrate' }
    }

    // 5) 落第一份草稿
    const id = newProjectDraftId()
    const now = Date.now()
    const name = project.srtName && project.srtName.trim()
      ? project.srtName.trim().slice(0, 80)
      : '从自动保存恢复'
    const doc = {
      schema: 1,
      meta: {
        id,
        name,
        createdAt: now,
        lastModified: now,
        appVersion: appVersionSafe(),
        edition: '',
        thumb: '',
        cardCount: cards.length,
        migrated: true,
      },
      project,
      chat,
      playhead: 0,
      media,
    }
    atomicWriteJson(draftDocPath(id), doc)
    idx.items.push({ ...doc.meta })
    idx.lastDraftId = id
    idx.migrated = true
    saveDraftIndex(idx)
    return { ok: true, migrated: true, id, doc }
  } catch (e) {
    return {
      ok: false,
      migrated: false,
      id: '',
      reason: 'migrate-failed',
      message: String((e && e.message) || e),
    }
  }
})

/* ------------------------------------------------------------------ *
 * 系统级机器 ID（一机一码激活用）：
 * 取操作系统自身的稳定标识，与应用版本 / Electron 版本完全无关——
 * 否则每次增量更新版本号一变，机器码跟着变，PRO 会被启动重验误清（2026-09-29 踩坑）。
 *   Windows: 注册表 HKLM\SOFTWARE\Microsoft\Cryptography\MachineGuid（Users 可读，无需管理员）
 *   macOS:   IOPlatformUUID；Linux: /etc/machine-id
 * 读不到时返回 'na'，前端会退回「剥离版本号的环境指纹」。
 * ------------------------------------------------------------------ */

let machineIdCache = ''

function systemMachineId() {
  if (machineIdCache) return machineIdCache
  try {
    const { execFileSync } = require('child_process')
    if (process.platform === 'win32') {
      const out = execFileSync(
        'reg',
        ['query', 'HKLM\\SOFTWARE\\Microsoft\\Cryptography', '/v', 'MachineGuid'],
        { encoding: 'utf8', timeout: 4000, windowsHide: true },
      )
      const m = out.match(/MachineGuid\s+REG_SZ\s+(\S+)/i)
      if (m) machineIdCache = 'w:' + m[1]
    } else if (process.platform === 'darwin') {
      const out = execFileSync('ioreg', ['-rd1', '-c', 'IOPlatformExpertDevice'], {
        encoding: 'utf8',
        timeout: 4000,
      })
      const m = out.match(/"IOPlatformUUID"\s*=\s*"([^"]+)"/)
      if (m) machineIdCache = 'm:' + m[1]
    } else {
      for (const f of ['/etc/machine-id', '/var/lib/dbus/machine-id']) {
        if (fs.existsSync(f)) {
          machineIdCache = 'l:' + fs.readFileSync(f, 'utf8').trim()
          break
        }
      }
    }
  } catch {
    /* 走前端回退指纹 */
  }
  if (!machineIdCache) machineIdCache = 'na'
  return machineIdCache
}

ipcMain.on('machine:id', (e) => {
  e.returnValue = systemMachineId()
})

/**
 * 主进程权威 PRO 判定（第②层：门控下沉主进程）。
 * 开发态返回 { pro: null } 表示「主进程不下结论」，renderer 退回自身验签；
 * 生产态返回独立验签结果（读 app-state 里自己持有的激活码，不信任 renderer 布尔）。
 */
ipcMain.handle('app:isPro', async () => {
  if (isDev) return { pro: null }
  return { pro: await proGate.isPro(loadAppState(), { clockSuspect }), clockSuspect }
})

/* ------------------------------------------------------------------ *
 * 窗口控制：缩小 / 最大化(还原) / 关闭（无边框窗口自绘按钮）
 * ------------------------------------------------------------------ */

ipcMain.on('window:minimize', () => win?.minimize())

ipcMain.on('window:maximize', () => {
  if (!win) return
  if (win.isMaximized()) win.unmaximize()
  else win.maximize()
})

ipcMain.on('window:close', () => win?.close())

ipcMain.handle('window:isMaximized', () => !!win?.isMaximized())

/** R26：草稿箱首屏 / 编辑器 双档尺寸。渲染进程在启动、打开草稿、返回首屏时各发一次。 */
ipcMain.on('window:draftMode', (_e, mode) => applyDraftWindowMode(mode))

/* ------------------------------------------------------------------ *
 * 激活窗口：独立小窗 + 状态变更通知主窗口刷新 PRO 标识
 * ------------------------------------------------------------------ */

ipcMain.handle('activation:open', () => createActivationWindow())

/** 激活窗口：按渲染进程量出的「内容真实高度」收紧窗口，消掉底部的空白。
 *  专业版比基础版矮近 300px（少了价格 / 首发说明区与激活输入框），固定高度必然一侧留白。
 *  只改高度（宽度保留用户手动调过的），上限锁主屏可用区，下限 = 最小可读高度。 */
ipcMain.on('activation:content-height', (e, h) => {
  const w = activationWin
  if (!w || w.isDestroyed()) return
  if (e.sender !== w.webContents) return
  const n = Math.round(Number(h) || 0)
  if (!(n > 200)) return
  const area = screen.getPrimaryDisplay().workAreaSize
  const target = Math.max(460, Math.min(n, area.height - 80))
  const [cw, ch] = w.getContentSize()
  if (Math.abs(ch - target) < 4) return
  w.setContentSize(cw, target)
  // 收紧高度后重新居中：setContentSize 会保持左上角锚点，不重定位就会停在左上、偏离屏幕中央
  w.center()
})

/** 激活窗口：渲染进程请求隐藏窗口（替代 window.close()，避免连带关闭主窗口） */
ipcMain.on('activation:close', () => {
  if (activationWin && !activationWin.isDestroyed()) {
    activationWin.hide()
  }
})

/* ------------------------------------------------------------------ *
 * 剪映对接：克隆信封法（clone-envelope）
 *  - 用户在剪映里建好「画布比例 + 主轨已放一个占位视频」的草稿当信封
 *  - 这里把信封复制到本地缓存（绝不引用源文件），之后每次导出只改
 *    path/duration/target_timerange/source_timerange 等稳定字段，写回剪映草稿目录
 *  - 所有操作都被限制在「剪映草稿根目录」与「本应用 userData 缓存」两个沙盒内
 * ------------------------------------------------------------------ */

/** 剪映「索引目录」：root_meta_info.json 所在位置；
 *  新版剪映把草稿实际文件夹路径写在这个索引里，而不是直接放在本目录下。 */
function jianyingMetaRoot() {
  if (process.platform === 'win32') {
    const local = process.env.LOCALAPPDATA
    return local
      ? path.join(local, 'JianyingPro', 'User Data', 'Projects', 'com.lveditor.draft')
      : path.join(os.homedir(), 'AppData', 'Local', 'JianyingPro', 'User Data', 'Projects', 'com.lveditor.draft')
  }
  return path.join(os.homedir(), 'JianyingPro', 'User Data', 'Projects', 'com.lveditor.draft')
}

/** 兼容旧命名：返回「索引目录」，调用处如需真正草稿文件夹请用 jianyingDraftRoot() */
function jianyingDefaultRoot() {
  return jianyingMetaRoot()
}

/** 从指定索引目录解析出用户实际存放草稿的目录（取出现次数最多的 draft_root_path） */
function resolveDraftRoot(metaRoot) {
  const resolved = resolveMetaRoot(metaRoot)
  const meta = readMetaStore(resolved)
  if (!meta) return resolved
  const map = new Map()
  for (const e of meta.all_draft_store || []) {
    const rp = e.draft_root_path ? path.normalize(e.draft_root_path) : ''
    const fp = e.draft_fold_path ? path.normalize(e.draft_fold_path) : ''
    const root = rp || (fp ? path.dirname(fp) : '')
    if (!root) continue
    map.set(root, (map.get(root) || 0) + 1)
  }
  let best = ''
  let bestCount = 0
  for (const [root, count] of map) {
    if (count > bestCount && fs.existsSync(root)) {
      best = root
      bestCount = count
    }
  }
  return best || resolved
}

/** 兼容旧命名：未指定输入时返回默认索引目录对应的实际草稿根 */
function jianyingDraftRoot(metaRoot) {
  return resolveDraftRoot(metaRoot)
}

/** 读剪映索引文件；解析失败返回 null */
function readMetaStore(metaRoot) {
  const p = path.join(metaRoot, 'root_meta_info.json')
  if (!fs.existsSync(p)) return null
  return readJson(p)
}

/**
 * 解析 EXIF orientation（1..8）；找不到/无法解析返回 1。
 * segStart 指向 0xFFE1 之后（段长度字段之后）的段数据起点，segLen 为完整段长度（含 2 字节长度字段）。
 */
function readExifOrientation(buf, segStart, segLen) {
  try {
    const exif = buf.subarray(segStart, segStart + segLen - 2)
    // 期望以 "Exif\0\0" 开头
    if (exif.toString('ascii', 0, 6) !== 'Exif' + String.fromCharCode(0, 0)) return 1
    const tiff = exif.subarray(6)
    if (tiff.length < 8) return 1
    const le = tiff.toString('ascii', 0, 2) === 'II' // 'II' = little-endian, 'MM' = big-endian
    const rd16 = (o) => (le ? tiff.readUInt16LE(o) : tiff.readUInt16BE(o))
    const rd32 = (o) => (le ? tiff.readUInt32LE(o) : tiff.readUInt32BE(o))
    if (rd16(2) !== 0x2a) return 1 // TIFF magic
    const ifd0 = rd32(4)
    if (ifd0 + 2 > tiff.length) return 1
    const count = rd16(ifd0)
    for (let k = 0; k < count; k++) {
      const eo = ifd0 + 2 + k * 12
      if (eo + 12 > tiff.length) break
      const tag = rd16(eo)
      if (tag === 0x0112) {
        // Orientation
        const val = rd16(eo + 8)
        return val >= 1 && val <= 8 ? val : 1
      }
    }
  } catch {
    /* ignore */
  }
  return 1
}

/** 解析 JPEG/PNG 宽高（用于从 draft_cover.jpg 推断画布比例） */
function readImageSize(p) {
  try {
    const buf = fs.readFileSync(p)
    if (!buf || buf.length < 8) return null
    if (buf[0] === 0xff && buf[1] === 0xd8) {
      let orientation = 1
      let i = 2
      while (i < buf.length) {
        if (buf[i] !== 0xff) break
        const marker = buf[i + 1]
        if (marker === 0xd9 || marker === 0xda) break
        const len = buf.readUInt16BE(i + 2)
        if (marker === 0xe1) {
          // APP1/Exif：先读 orientation（5..8 需要交换宽高）
          const ori = readExifOrientation(buf, i + 4, len)
          if (ori !== 1) orientation = ori
        } else if (
          marker >= 0xc0 &&
          marker <= 0xcf &&
          marker !== 0xc4 && // DHT
          marker !== 0xc8 && // JPG
          marker !== 0xcc // DAC
        ) {
          // JPEG SOF 段布局：+5 = height，+7 = width（旧代码两字段写反 → 16:9 封面被误判为 9:16）
          const h = buf.readUInt16BE(i + 5)
          const w = buf.readUInt16BE(i + 7)
          const swap = orientation >= 5 && orientation <= 8
          return { width: swap ? h : w, height: swap ? w : h }
        }
        i += 2 + len
      }
    } else if (buf.toString('ascii', 0, 8) === String.fromCharCode(0x89) + 'PNG\r\n\x1a\n') {
      const idx = buf.indexOf('IHDR')
      if (idx >= 0) {
        return { width: buf.readUInt32BE(idx + 4), height: buf.readUInt32BE(idx + 8) }
      }
    }
  } catch {
    /* ignore */
  }
  return null
}

/** 若用户选的目录包含 root_meta_info.json 就直接用，否则回默认索引目录 */
function resolveMetaRoot(input) {
  if (input) {
    const p = path.join(input, 'root_meta_info.json')
    if (fs.existsSync(p)) return input
  }
  return jianyingMetaRoot()
}

function jianyingCacheRoot() {
  return path.join(app.getPath('userData'), 'jianying', 'envelopes')
}

function jianyingEnvelopeDir(ratioKey) {
  // Windows 下目录名不能含冒号（Node 会按 NTFS 备用数据流解析，mkdir 直接 ENOENT），
  // 所以比例键 '16:9' 落盘为 '16x9'；envelope.json 内仍存原始 ratioKey，前端无感。
  return path.join(jianyingCacheRoot(), String(ratioKey).replace(/:/g, 'x'))
}

const JY_MEDIA_EXT = new Set([
  '.mp4', '.mov', '.m4v', '.avi', '.mkv', '.webm', '.mp3', '.wav', '.m4a', '.aac', '.flac',
  '.png', '.jpg', '.jpeg', '.webp', '.gif', '.bmp', '.tiff',
])

/** 递归拷贝目录；excludeMedia=true 时跳过音视频/图片二进制（信封只留 JSON，占位媒体无意义且可能巨大）；
 *  skipTransient=true 时跳过剪映运行时瞬态物（.backup 历史 / *.bak / *.tmp / 采用台账 db）。 */
function copyDir(src, dest, opts = {}) {
  fs.mkdirSync(dest, { recursive: true })
  for (const name of fs.readdirSync(src)) {
    if (opts.skipTransient) {
      if (name === '.backup' || name === 'agent_adoption_ledger.db') continue
      if (/\.(bak|tmp)$/i.test(name)) continue
    }
    const s = path.join(src, name)
    const d = path.join(dest, name)
    const st = fs.statSync(s)
    if (st.isDirectory()) {
      copyDir(s, d, opts)
    } else if (opts.excludeMedia && JY_MEDIA_EXT.has(path.extname(name).toLowerCase())) {
      // 跳过占位媒体
    } else {
      fs.copyFileSync(s, d)
    }
  }
}

function safeReaddir(p) {
  try {
    return fs.readdirSync(p)
  } catch {
    return []
  }
}

function readJson(p) {
  try {
    return JSON.parse(fs.readFileSync(p, 'utf8'))
  } catch {
    return null
  }
}

function ratioKeyFromCanvas(w, h) {
  if (!w || !h) return null
  const r = w / h
  if (r > 1.5) return '16:9'
  if (r < 0.7) return '9:16'
  if (r > 0.9 && r < 1.1) return '1:1'
  return null
}

/** 剪映草稿/素材 ID：32 位小写 hex（与参考实现 pyJianYingDraft 的 uuid4().hex 一致） */
function newDraftId() {
  let s = ''
  for (let i = 0; i < 32; i++) s += '0123456789abcdef'[Math.floor(Math.random() * 16)]
  return s
}

/** 剪映多时间线结构（Timelines/project.json 等）使用的 8-4-4-4-12 大写 GUID */
function newGuid() {
  const seg = (n) => {
    let s = ''
    for (let i = 0; i < n; i++) s += '0123456789ABCDEF'[Math.floor(Math.random() * 16)]
    return s
  }
  return `${seg(8)}-${seg(4)}-${seg(4)}-${seg(4)}-${seg(12)}`
}

/** 草稿文件夹名：M月d日（与剪映原生草稿命名风格一致，如「10月15日」「10月2日」）。
 *  同一自然天内重复导出时自动追加「 (n)」后缀去重（剪映自身也是这个风格）。
 *  注意：不要含 ASCII 冒号「:」——Windows 文件夹名非法，Node 会按 NTFS 备用数据流解析，
 *  mkdir 直接 ENOENT（与信封目录 16:9 踩的是同一个坑）。 */
function jyDraftFolderName(d) {
  return `${d.getMonth() + 1}月${d.getDate()}日`
}

/** 内置 jy-draftc（剪映草稿加解密 CLI，MIT：github.com/wenshui330/jy-draftc）。
 *  该工具与剪映版本一一对应（每个剪映版本需匹配对应工具版本，见其 README 对照表），
 *  当前内置的是适配「剪映 11.5.0.14471」的构建；打包后在 resources，开发时用项目内置。 */
const JY_DRAFTC_SUPPORT = '11.5.0.14471'
function jyDraftcPath() {
  // 同 ffmpeg：便携版未走 electron-builder 打包，app.isPackaged 为 false，但 jy-draftc.exe
  // 同样放在 <exe目录>/resources/ —— 不再门控，始终先试该位置，再回落 __dirname/bin（开发态）。
  const candidates = [
    path.join(process.resourcesPath, 'jy-draftc.exe'),
    path.join(__dirname, 'bin', 'jy-draftc.exe'),
  ]
  for (const c of candidates) {
    if (fs.existsSync(c)) return c
  }
  return ''
}

/** 小写 8-4-4-4-12 GUID（剪映 local_material_id 等字段用小写形式） */
function newGuidLower() {
  return newGuid().toLowerCase()
}

/**
 * 把剪映加密的 draft_content.json 解密为「明文模板」（存到 outFile）。
 * 返回 { ok, newVersion?, jyVersion?, reason?, detail? }：
 *  - srcFile 已是明文（旧版剪映/个别版本）时直接采用，不跑工具；
 *  - 工具缺失 / 找不到 videoeditor.dll / 解密失败分别返回 no-tool / no-dll / decrypt-failed。
 *
 * 为什么必须解密：新版剪映（11.5 → new_version 187.0.0）打不开手搓的旧代最小模板
 * （pyJianYingDraft 的 110.0.0 结构）——差一代结构，加载即失败。以用户自己剪映
 * 解出来的同代结构做基准注入成片，才能保证「打开就能播」。
 */
function jyDecryptContentFile(srcFile, outFile) {
  const direct = readJson(srcFile)
  if (direct && (direct.new_version || Array.isArray(direct.tracks))) {
    try {
      fs.copyFileSync(srcFile, outFile)
      return { ok: true, newVersion: direct.new_version || '' }
    } catch (e) {
      return { ok: false, reason: 'decrypt-failed', detail: String((e && e.message) || e) }
    }
  }
  const exe = jyDraftcPath()
  if (!exe) return { ok: false, reason: 'no-tool' }
  const inst = detectJianyingInstall()
  if (!inst.dllPath) return { ok: false, reason: 'no-dll', jyVersion: inst.version }
  // jy-draftc 要的是「版本目录」（videoeditor.dll 所在层），不是安装根目录
  const jyDir = path.dirname(inst.dllPath)
  const tmpOut = `${outFile}.decrypting`
  try { fs.rmSync(tmpOut, { force: true }) } catch { /* 忽略 */ }
  return new Promise((resolve) => {
    execFile(
      exe,
      ['-dc', srcFile, '-o', tmpOut, '--jy-dir', jyDir],
      { maxBuffer: 8 * 1024 * 1024, windowsHide: true },
      (err, _stdout, stderr) => {
        const fail = (detail) => {
          try { fs.rmSync(tmpOut, { force: true }) } catch { /* 忽略 */ }
          resolve({ ok: false, reason: 'decrypt-failed', jyVersion: inst.version, support: JY_DRAFTC_SUPPORT, detail })
        }
        if (err || !fs.existsSync(tmpOut)) {
          // 引擎日志混在 stdout/stderr，取最后一行非空文本当详情
          const lines = `${stderr || ''}`.split('\n').map((s) => s.trim()).filter(Boolean)
          fail(lines.length ? lines[lines.length - 1].slice(0, 200) : `jy-draftc 退出码 ${err && err.code}`)
          return
        }
        const tpl = readJson(tmpOut)
        if (!tpl || !Array.isArray(tpl.tracks)) {
          fail('解密结果不是有效的草稿结构')
          return
        }
        try {
          fs.renameSync(tmpOut, outFile)
        } catch (e) {
          fail(String((e && e.message) || e))
          return
        }
        resolve({ ok: true, newVersion: tpl.new_version || '', jyVersion: inst.version })
      },
    )
  })
}

/** 读单个草稿的剪映版本（供列表逐条展示）：明文 dc 直读 platform.app_version；
 *  密文 dc 用 jy-draftc 解密到临时文件读完后删除。读不到返回 null。
 *  jyDir 为 videoeditor.dll 所在的版本子目录（由 detectJianyingInstall 提供，为空表示无法解密）。 */
function jyVersionFromContentFile(dcFile, jyDir) {
  const direct = readJson(dcFile)
  if (direct && direct.platform && direct.platform.app_version) {
    return Promise.resolve({ appVersion: String(direct.platform.app_version), newVersion: String(direct.new_version || '') })
  }
  const exe = jyDraftcPath()
  if (!exe || !jyDir || !fs.existsSync(dcFile)) return Promise.resolve(null)
  const tmpOut = path.join(os.tmpdir(), `vfx-jyver-${process.pid}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}.json`)
  return new Promise((resolve) => {
    execFile(exe, ['-dc', dcFile, '-o', tmpOut, '--jy-dir', jyDir], { maxBuffer: 8 * 1024 * 1024, windowsHide: true }, (err) => {
      const done = (v) => {
        try { fs.rmSync(tmpOut, { force: true }) } catch { /* 忽略 */ }
        resolve(v)
      }
      if (err || !fs.existsSync(tmpOut)) return done(null)
      const t = readJson(tmpOut)
      if (!t) return done(null)
      const av = t.platform && t.platform.app_version ? String(t.platform.app_version) : ''
      done(av || t.new_version ? { appVersion: av, newVersion: String(t.new_version || '') } : null)
    })
  })
}

/** 给草稿列表补充剪映版本号（并行解密；无解密工具/无 dll 时静默跳过，列表不显示版本徽章）。
 *  只对将要展示的条目解密，控制耗时——每条一次 jy-draftc 进程，10 条并行约 1s 内完成。 */
async function enrichJyVersions(list) {
  const inst = detectJianyingInstall()
  const jyDir = inst.dllPath ? path.dirname(inst.dllPath) : ''
  if (!jyDraftcPath() || !jyDir) return list
  await Promise.all(
    list.map(async (d) => {
      try {
        const v = await jyVersionFromContentFile(path.join(d.draftPath, 'draft_content.json'), jyDir)
        if (v) {
          if (v.appVersion) d.appVersion = v.appVersion
          if (v.newVersion) d.newVersion = v.newVersion
        }
      } catch { /* 单条失败不影响其他条目 */ }
    }),
  )
  return list
}

/** 从成片抽一帧写为草稿封面（剪映列表页缩略图）；失败返回 false */
function extractVideoCover(videoPath, outJpg) {
  const ok = () => {
    try {
      return fs.existsSync(outJpg) && fs.statSync(outJpg).size > 1024
    } catch {
      return false
    }
  }
  return new Promise((resolve) => {
    if (!videoPath || !fs.existsSync(videoPath)) { resolve(false); return }
    // 封面不需要全分辨率，限宽 960 足够列表页展示（滤镜里的逗号要转义）
    const args = ['-y', '-ss', '0.1', '-i', videoPath, '-frames:v', '1', '-vf', 'scale=min(960\\,iw):-2', '-q:v', '4', outJpg]
    execFile(ffmpegPath(), args, { maxBuffer: 8 * 1024 * 1024, windowsHide: true }, (err) => {
      if (!err && ok()) { resolve(true); return }
      // 兜底：不 seek 直接取第 1 帧（个别容器 -ss 0.1 取不到帧）
      execFile(ffmpegPath(), ['-y', '-i', videoPath, '-frames:v', '1', '-q:v', '4', outJpg], { maxBuffer: 8 * 1024 * 1024, windowsHide: true }, (err2) => {
        resolve(!err2 && ok())
      })
    })
  })
}

/** 拷贝剪映草稿的「配套文件」：内容/元数据之外的配置原样带过来。
 *  跳过剪映运行时瞬态物（.backup 历史 / *.bak / *.tmp / 采用台账 db）与 skipNames。 */
function copyJySupportFiles(src, dest, skipNames = []) {
  if (!fs.existsSync(src)) return
  fs.mkdirSync(dest, { recursive: true })
  for (const name of fs.readdirSync(src)) {
    if (skipNames.includes(name)) continue
    if (name === '.backup' || name === 'agent_adoption_ledger.db') continue
    if (/\.(bak|tmp)$/i.test(name)) continue
    const s = path.join(src, name)
    const d = path.join(dest, name)
    const st = fs.statSync(s)
    if (st.isDirectory()) copyJySupportFiles(s, d, [])
    else fs.copyFileSync(s, d)
  }
}

/** 信封里模板使用的「当前时间线」目录：优先 timeline_layout.json 的 activeTimeline，兜底唯一子目录 */
function findTemplateTimelineDir(env) {
  const tlRoot = path.join(env, 'Timelines')
  if (!fs.existsSync(tlRoot)) return ''
  const layout = readJson(path.join(env, 'timeline_layout.json'))
  const active = layout && layout.activeTimeline
  if (active && fs.existsSync(path.join(tlRoot, active))) return path.join(tlRoot, active)
  const dirs = fs.readdirSync(tlRoot, { withFileTypes: true }).filter((d) => d.isDirectory())
  return dirs.length === 1 ? path.join(tlRoot, dirs[0].name) : ''
}

/**
 * 以「明文模板」（用户当前剪映的同代结构）为基准，注入成片生成新草稿内容。
 * 只动与成片相关的字段（画布 / 时长 / 顶层 id / 轨道 / 片段 / 视频素材）；
 * 模板里被片段 extra_material_refs 引用的支撑素材（speed / canvas / placeholder 等）原样保留，
 * 其余内容类素材（文本 / 特效 / 音频等）清空。
 * 轨道结构：空主轨 + 一条放成片的叠加视频轨——MOV 透明层不占主轨道，
 * 用户打开草稿后可直接往主轨放自己的实拍素材，透明 MOV 自然叠加在上面。
 */
/**
 * 草稿里片段的摆放方式（clip.scale / clip.transform）—— 纯函数，闸门可数值断言。
 *
 * 两种模式：
 * - **crop**（传了裁剪矩形）：素材被切小 ⇒ scale 恒为 1（像素 1:1，画质无损），
 *   用 transform 把内容从「画面正中」移回它原本所在的位置。
 * - **fill**（没裁剪，但整体降采样过）：scale = 画布 ÷ 素材，**位移恒为 0** ——
 *   缩放是整体等比的，卡片相对位置没变，不用碰 transform（该字段语义未实证）。
 * - 都不满足（素材 = 画布尺寸）⇒ 返回 null，保持模板原样（scale 1 / transform 0）。
 *
 * ⚠️ transform 的归一化单位**至今未实证**：本机真实草稿（10月14日 / 10月12日）
 *    里所有片段都是 transform=0，找不到样本反推。这里采用「以画面半宽/半高为单位；
 *    剪映画面 y 轴朝上、画布 y 轴朝下 ⇒ y 取负」。
 *    **真机标定后只需要改这一个函数**（renderer 侧同源函数：`clipTransformOf`）。
 */
function clipPlacement({ crop, matW, matH, canvasW, canvasH }) {
  if (crop && Number(crop.width) > 0 && Number(crop.height) > 0) {
    const w = Number(crop.width) || 0
    const h = Number(crop.height) || 0
    const cx = (Number(crop.x) || 0) + w / 2
    const cy = (Number(crop.y) || 0) + h / 2
    // ── clip 语义（2026-10-17 已实证，来源 pyJianYingDraft 源码注释 + 真机）──
    // scale=1 是「剪映导入素材时自动适配画布后」的大小（contain：fit=min(W/w,H/h)），
    // 不是素材原始像素大小！裁剪素材要还原原始大小须再除以 fit，即 scale = max(w/W, h/H)。
    const s = Math.max(w / canvasW, h / canvasH)
    return {
      scale: { x: s, y: s },
      // transform 单位 = 半个画布宽/高，画布中心为原点，y 轴朝上（与画布 y 朝下相反）
      transform: {
        x: (cx - canvasW / 2) / (canvasW / 2),
        y: -(cy - canvasH / 2) / (canvasH / 2),
      },
    }
  }
  // 无裁剪（fill 降采样或原样）：素材与画布同宽高比 ⇒ 剪映自动适配恰好铺满画布，
  // scale=1 就是正确还原，**不要再乘 canvasW/w**——那会双重放大（2026-10-17 真机踩坑：
  // 症状为「所有卡都放大一圈、位置全偏」，用户截图实证）。
  return null
}

/**
 * 构建一条视频轨片段（含素材引用）：卡片透明层 / 视频轨实拍片段共用。
 * 闭合在 buildDraftFromTemplate 内（而非模块级），原因：回归闸门用 extractFn 抽出
 * buildDraftFromTemplate 函数体、注入 4 个依赖后用 new Function 实跑；若抽成模块级函数，
 * 闸门里没注入它就会 ReferenceError。嵌套后它随函数体一起被抽出，闸门零改动。
 */
function buildDraftFromTemplate(tpl, { timelineId, videoPath, dur, canvasW, canvasH, fps, clips, videos }) {
  const dc = JSON.parse(JSON.stringify(tpl))

  function buildClipSeg(item) {
    const { startUs, durUs, srcStartUs, clipPath, mw, mh, crop, speed } = item
    // K2：加速倍率。durUs 是「时间轴上的时长」，源内取用长度 = durUs × speed
    //   （剪映按 seg.speed 自行变速，所以 source_timerange 要放宽到源内真实长度）。
    const sp = Number.isFinite(Number(speed)) && Number(speed) > 0 ? Math.min(10, Math.max(1, Number(speed))) : 1
    const srcDurUs = Math.max(1, Math.round(durUs * sp))
    const seg = JSON.parse(JSON.stringify(baseSeg))
    seg.id = newGuid()
    const materialId = newGuid()
    seg.material_id = materialId
    // 源内裁剪起点：卡片透明层恒为 0；视频轨实拍片段 = trimStart（从源文件某处取一段）
    seg.source_timerange = range(seg.source_timerange, srcStartUs || 0, srcDurUs)
    seg.target_timerange = range(seg.target_timerange, startUs, durUs)
    // render_timerange 保持「素材内相对起点 = 0」，只有 target 决定摆在哪
    seg.render_timerange = range(seg.render_timerange, 0, durUs)
    if (typeof seg.speed === 'number') seg.speed = sp
    const matW = mw > 0 ? mw : canvasW
    const matH = mh > 0 ? mh : canvasH
    if (seg.clip && typeof seg.clip === 'object') {
      const place = clipPlacement({ crop, matW, matH, canvasW, canvasH })
      if (place) seg.clip = { ...seg.clip, scale: place.scale, transform: place.transform }
    }
    clipMats.push({
      id: materialId,
      path: String(clipPath).replace(/\\/g, '/'),
      // 素材自身的时长按源内长度登记（1 倍速时与轴长相同，历史行为不变）
      duration: srcDurUs,
      start: startUs,
      w: matW,
      h: matH,
    })
    return seg
  }

  // 画布与时长
  if (dc.canvas_config && typeof dc.canvas_config === 'object') {
    dc.canvas_config.width = canvasW
    dc.canvas_config.height = canvasH
  }
  dc.duration = dur
  if (typeof dc.fps === 'number' && fps) dc.fps = fps
  // 真实结构里顶层内容 id 与主时间线 GUID 同值
  dc.id = timelineId

  // 轨道：MOV 透明层**不放主轨道**——
  //   主轨（第一条视频轨）保留结构但清空片段（真实空主轨连 segments 键都没有），
  //   留给用户自己往主轨放实拍素材；MOV 放到新增的叠加视频轨。
  //   真实多轨草稿实证：主轨无 flag 字段，叠加视频轨 flag=2（见 10月8日 / 3月12日 解密样本）。
  const tracks = Array.isArray(dc.tracks) ? dc.tracks : []
  const srcTrack = tracks.find((t) => t && t.type === 'video') || tracks[0] || { type: 'video' }

  // 主轨：克隆模板轨结构换新 id，去掉片段与 flag（空主轨）
  const mainTrack = JSON.parse(JSON.stringify(srcTrack))
  mainTrack.type = 'video'
  mainTrack.id = newGuid()
  delete mainTrack.segments
  delete mainTrack.flag

  // 叠加轨的基准段结构：从「有片段」的视频轨取第一段当骨架（携带 clip 等支撑引用）。
  // ⚠️ 2026-10-28 定位的真 bug：本机信封模板里「第一条视频轨 = 空主轨（无 segments）」，
  //   若只从 srcTrack（第一条视频轨）取骨架，baseSeg 会退化成 {} ⇒ 生成的每个分段
  //   都没有 seg.clip 对象 ⇒ 落位（scale/transform）写不进去 ⇒ 剪映里所有卡片落默认居中、
  //   缩放也还原不了（用户实证：基本全部卡片居中、大小乱）。
  //   修复：优先从「有片段」的视频轨取骨架；仍拿不到 clip 时兜底造一个，确保落位一定写进去。
  const segBearing =
    tracks.find(
      (t) => t && t.type === 'video' && Array.isArray(t.segments) && t.segments.length > 0,
    ) || srcTrack
  const baseSeg =
    segBearing.segments && segBearing.segments[0] ? segBearing.segments[0] : {}
  // 兜底：baseSeg 缺 clip 对象时造一个，否则 clipPlacement 的落位永远写不进去（全居中）。
  if (!baseSeg.clip || typeof baseSeg.clip !== 'object') {
    baseSeg.clip = { scale: { x: 1, y: 1 }, transform: { x: 0, y: 0 }, flip: {} }
  }

  // 片段清单：clips 为空 = 老行为（整条成片一段平铺）；非空 = 按卡分段，每段一段素材。
  //   clip = { path, start(秒), duration(秒) }：素材从自己文件头取 duration，摆到 start 处。
  //   时间一律换算成微秒（剪映 timerange 单位）。
  const segmented = Array.isArray(clips) && clips.length > 0
  const list = segmented ? clips : [{ path: videoPath, start: 0, duration: dur / 1_000_000 }]
  const range = (r, s, d) => (r && typeof r === 'object' ? { ...r, start: s, duration: d } : { start: s, duration: d })
  const clipMats = []

  // 视频轨实拍片段：存在时主草稿主轨放这些视频（剪映基准轨，层级最底），卡片透明层一律上移叠加轨。
  // token 已在 generateDraft 里解析成绝对路径；时间单位秒 → 微秒（与 clips 同源换算）。
  const haveVideos = Array.isArray(videos) && videos.length > 0
  let videoSegs = null
  if (haveVideos) {
    videoSegs = videos.map((v) =>
      buildClipSeg({
        startUs: Math.max(0, Math.round((Number(v && v.start) || 0) * 1_000_000)),
        durUs: Math.max(1, Math.round((Number(v && v.duration) || 0) * 1_000_000)),
        srcStartUs: Math.max(0, Math.round((Number(v && v.trimStart) || 0) * 1_000_000)),
        clipPath: String((v && v.path) || videoPath),
        mw: Number(v && v.width) || 0,
        mh: Number(v && v.height) || 0,
        crop: null,
        // K2：加速倍率（缺省 1），草稿里按 seg.speed 还原变速
        speed: Number(v && v.speed) || 1,
      }),
    )
  }

  // 按 lane 分组分轨：VFX STUDIO 里 lane 0 = 最底轨道，lane 越大层级越高。
  // 剪映实测（导出后真机回看）：tracks 数组**越靠后层级越高**（与常规 NLE 一致，
  // 数组末尾在最上层）。因此导出时把「低 lane」放在数组前面、「高 lane」放在数组后面，
  // 和 VFX STUDIO 的「lane 0 在最底」层级关系一致。
  //
  // ★ 主轨道开放（2026-10-16 用户要求）：剪映主轨是**基准轨**，天然压在所有叠加轨之下。
  //   把「最底 lane 的第一条子轨」放到主轨 ⇒ 背景层（grid-bg-1 这类铺满全片的卡）无论
  //   如何都不会被叠加轨的前景卡盖住 —— 层级不再只依赖叠加轨数组的顺序语义，双保险。
  //   最底 lane 内部先按**时长降序**排：背景卡 duration 最大 ⇒ 优先拿到第一条子轨 ⇒ 落主轨；
  //   同一 lane 里与它重叠的其它卡被 first-fit 拆到后面的叠加轨（在它之上）。
  // 同一 lane 内部仍用 first-fit：若该 lane 里时间重叠的卡太多，就在本 lane 内
  // 拆成多条轨道，这些同 lane 子轨整体仍排在所有更低 lane 的轨道之上、更高 lane 之下。
  const byLane = new Map()
  for (const c of list) {
    const lane = Number(c && c.lane) || 0
    if (!byLane.has(lane)) byLane.set(lane, [])
    byLane.get(lane).push(c)
  }

  const laneEntries = Array.from(byLane.entries()).sort((a, b) => a[0] - b[0])
  const laneTracks = []
  /** 最底 lane 的第一条子轨 → 主轨道（剪映基准轨，层级最底，无 flag） */
  let mainSegs = null
  laneEntries.forEach(([, clipsInLane], laneIdx) => {
    // ★ 同一条 lane 内按「起始时间」升序做 first-fit（不再按时长降序）：
    //   相邻不重叠的卡会稳定共用同一条子轨 ⇒ lane 0 上的多张顺序卡整组落到主轨，
    //   修复「主轨道多张卡导出后只剩 1 张、其余被挤到叠加轨」的回归。
    //   旧写法对 lane 0 按时长降序，会把「较晚出现的长卡」先占满主轨子轨，
    //   导致「更早出现的短卡」fit 失败而被新建子轨、落到叠加轨（用户实报：主轨 2 张卡 → 导出仅 1 张）。
    //   背景卡（铺满全片、独占 lane 0）通常起始最早，按起始时间排序同样最先占主轨；
    //   前景卡一般在 lane 1+（由外层 lane 分组保证层级），不受此改动影响。
    //   所有 lane 统一按起始时间排序，使组内 first-fit packing 最稳健（同 lane 重叠才拆子轨）。
    const ordered = [...clipsInLane].sort((x, y) => (Number(x && x.start) || 0) - (Number(y && y.start) || 0))
    const laneEnds = []
    const subLanes = []
    for (const c of ordered) {
      const startUs = Math.max(0, Math.round((Number(c && c.start) || 0) * 1_000_000))
      const durUs = Math.max(1, Math.round((Number(c && c.duration) || 0) * 1_000_000))
      let li = laneEnds.findIndex((end) => startUs >= end)
      if (li < 0) {
        li = laneEnds.length
        laneEnds.push(0)
        subLanes.push([])
      }
      laneEnds[li] = startUs + durUs
      subLanes[li].push({
        startUs,
        durUs,
        path: String((c && c.path) || videoPath),
        // 片段实际像素尺寸（0 = 未给，回落到画布尺寸 = 老行为）
        mw: Number(c && c.width) || 0,
        mh: Number(c && c.height) || 0,
        crop: (c && c.crop) || null,
      })
    }
    for (const lane of subLanes) {
      const segs = lane.map((it) =>
        buildClipSeg({ ...it, clipPath: it.path, srcStartUs: 0 }),
      )
      // ⚠️ 只有「按卡分段 且 无视频轨」才占用主轨：有视频时主轨留给视频，
      //    卡片透明层一律上移到叠加轨（flag=2）；整条模式仍留空主轨让用户自己放素材。
      if (!haveVideos && mainSegs === null && segmented) {
        // 第一条子轨进主轨道：不放 flag ⇒ 剪映基准轨，压在所有叠加轨之下
        mainSegs = segs
        continue
      }
      const t = JSON.parse(JSON.stringify(srcTrack))
      t.type = 'video'
      t.id = newGuid()
      t.flag = 2
      t.segments = segs
      laneTracks.push(t)
    }
  })
  // 主轨内容优先级：有视频轨 ⇒ 视频（基准轨，最底）；否则按卡分段时背景卡进主轨；都没有 ⇒ 空主轨。
  if (videoSegs && videoSegs.length) mainTrack.segments = videoSegs
  else if (mainSegs) mainTrack.segments = mainSegs
  dc.tracks = [mainTrack, ...laneTracks]

  // 素材：视频素材换成成片；被引用的支撑素材保留；内容类素材清空
  const mats = dc.materials && typeof dc.materials === 'object' ? dc.materials : {}
  const KEEP = ['speeds', 'canvases', 'placeholder_infos', 'sound_channel_mappings', 'material_colors', 'vocal_separations']
  const nextMats = {}
  for (const k of Object.keys(mats)) {
    nextMats[k] = Array.isArray(mats[k]) ? [] : mats[k]
  }
  for (const k of KEEP) {
    if (Array.isArray(mats[k])) nextMats[k] = JSON.parse(JSON.stringify(mats[k]))
  }
  const srcVideo = Array.isArray(mats.videos) && mats.videos[0] ? JSON.parse(JSON.stringify(mats.videos[0])) : {}
  nextMats.videos = clipMats.map((m) => ({
    ...srcVideo,
    id: m.id,
    duration: m.duration,
    path: m.path,
    // ⚠️ 必须是片段的**真实像素尺寸**（可能已降采样），不能一律写画布尺寸：
    //    剪映按 material 宽高 + clip.scale 还原显示大小，写错就会显示得过大/过小。
    width: m.w || canvasW,
    height: m.h || canvasH,
    material_name: path.basename(m.path),
    // 每条素材独立缓存标识，避免与模板占位视频 / 彼此撞车
    unique_id: newDraftId(),
    local_material_id: newGuidLower(),
    material_id: '',
  }))
  dc.materials = nextMats
  if (dc.keyframes && typeof dc.keyframes === 'object') {
    for (const k of Object.keys(dc.keyframes)) {
      if (Array.isArray(dc.keyframes[k])) dc.keyframes[k] = []
    }
  }
  return dc
}

/** 把新草稿登记进剪映索引 root_meta_info.json（best-effort，失败不影响草稿本身）。
 *  剪映自己也会扫目录补登记，但主动登记后封面 / 体积 / 时长立即可见，且不依赖剪映是否在运行。 */
function registerDraftEntry(metaRoot, o) {
  try {
    const p = path.join(metaRoot, 'root_meta_info.json')
    if (!fs.existsSync(p)) return false
    const meta = readJson(p)
    if (!meta || !Array.isArray(meta.all_draft_store)) return false
    const fwd = (s) => String(s || '').replace(/\\/g, '/')
    const fold = fwd(o.draftFoldPath)
    const nowUs = Date.now() * 1000
    const entry = {
      cloud_draft_cover: false,
      cloud_draft_sync: false,
      draft_cloud_last_action_download: false,
      draft_cloud_purchase_info: '',
      draft_cloud_template_id: '',
      draft_cloud_tutorial_info: '',
      draft_cloud_videocut_purchase_info: '',
      draft_cover: fwd(o.coverPath),
      draft_fold_path: fold,
      draft_id: o.draftId,
      draft_is_ai_shorts: false,
      draft_is_cloud_temp_draft: false,
      draft_is_infinite_canvas_draft: false,
      draft_is_invisible: false,
      draft_is_pippit_draft: false,
      draft_is_web_article_video: false,
      draft_json_file: `${fold}/draft_content.json`,
      draft_name: o.draftName,
      draft_new_version: '',
      draft_root_path: o.draftRootPath,
      draft_timeline_materials_size: o.materialsSize || 0,
      draft_type: '',
      draft_web_article_video_enter_from: '',
      pippit_avatar_url: '',
      pippit_extra_info: '',
      pippit_id: '',
      pippit_user_name: '',
      streaming_edit_draft_ready: true,
      tm_draft_cloud_completed: '',
      tm_draft_cloud_entry_id: -1,
      tm_draft_cloud_modified: 0,
      tm_draft_parent_entry_id: -1,
      tm_draft_space_id: -1,
      tm_draft_user_id: -1,
      tm_draft_removed: 0,
      tm_duration: o.durationUs || 0,
      tm_draft_create: nowUs,
      tm_draft_modified: nowUs,
    }
    const idx = meta.all_draft_store.findIndex(
      (e) => e && e.draft_fold_path && path.normalize(e.draft_fold_path) === path.normalize(o.draftFoldPath),
    )
    if (idx >= 0) meta.all_draft_store[idx] = { ...meta.all_draft_store[idx], ...entry }
    else meta.all_draft_store.push(entry)
    fs.writeFileSync(p, JSON.stringify(meta))
    return true
  } catch {
    return false
  }
}

ipcMain.handle('jianying:defaultRoot', async () => jianyingDefaultRoot())

/** 检测本机是否安装了剪映（默认索引目录下有无 root_meta_info.json）。
 *  供设置面板在未安装时展示提醒；用户手动选过目录的以目录内有无索引为准由前端另行判断。 */
ipcMain.handle('jianying:detect', async () => {
  const metaRoot = jianyingMetaRoot()
  return { installed: fs.existsSync(path.join(metaRoot, 'root_meta_info.json')), metaRoot }
})

/** 探测本机剪映安装信息（同步版：IPC 与抓取解密共用）。
 *  剪映默认安装在各盘根的 jianying\JianyingPro（官方默认 D 盘，安装时可选）。
 *  版本来源优先级：JianyingProPacket.xml 的 full_appver > 版本子目录名（形如 11.5.0.14471）。
 *  供「生成剪映草稿」选择匹配的加解密组件；未安装时 installed=false。 */
function detectJianyingInstall() {
  const info = { installed: false, installDir: '', version: '', dllPath: '' }
  // 1) 枚举各盘 jianying\JianyingPro
  const letters = 'DEFGHIJKLMNOPQRSTUVWXYZ'.split('')
  let installDir = ''
  for (const L of letters) {
    const p = path.join(`${L}:`, 'jianying', 'JianyingPro')
    try {
      if (fs.statSync(p).isDirectory()) { installDir = p; break }
    } catch { /* 不存在 */ }
  }
  if (!installDir) return info
  info.installed = true
  info.installDir = installDir
  // 2) 版本：先读 Packet xml
  try {
    const xml = fs.readFileSync(path.join(installDir, 'JianyingProPacket.xml'), 'utf8')
    const m = xml.match(/full_appver\s+value="([^"]+)"/) || xml.match(/<appver\s+value="([^"]+)"/)
    if (m) info.version = m[1]
  } catch { /* 忽略 */ }
  // 3) 兜底：版本子目录枚举
  if (!info.version) {
    try {
      const dirs = fs.readdirSync(installDir, { withFileTypes: true })
        .filter((d) => d.isDirectory() && /^\d+\.\d+\.\d+/.test(d.name))
        .map((d) => d.name)
        .sort()
      if (dirs.length) info.version = dirs[dirs.length - 1]
    } catch { /* 忽略 */ }
  }
  // 4) videoeditor.dll：优先版本子目录，其次安装根
  const verDir = info.version ? path.join(installDir, info.version) : installDir
  for (const p of [path.join(verDir, 'videoeditor.dll'), path.join(installDir, 'videoeditor.dll')]) {
    try {
      if (fs.statSync(p).isFile()) { info.dllPath = p; break }
    } catch { /* 不存在 */ }
  }
  return info
}

ipcMain.handle('jianying:installInfo', async () => detectJianyingInstall())

ipcMain.handle('jianying:draftRoot', async (_e, metaRoot) => jianyingDraftRoot(metaRoot))

ipcMain.handle('jianying:selectFolder', async () => {
  const r = dialog.showOpenDialogSync(win ?? undefined, {
    title: '选择剪映草稿目录',
    properties: ['openDirectory'],
  })
  return r && r[0] ? r[0] : ''
})

/** 草稿列表最多展示的条数：按最近修改时间只取最新 N 条，避免列表过长 */
const JY_LIST_LIMIT = 10

/** 列出剪映草稿（供抓取向导展示）。
 *  - ratioKey 传入时只保留该比例的草稿（向导只需抓某个比例的信封）；
 *  - 结果按最近修改时间降序，只返回最新 JY_LIST_LIMIT 条；
 *  - 返回 { drafts, total }：total 为过滤后的总条数（供界面提示「仅显示最新 N 条」）；
 *  - 每条尽量补充剪映版本号（appVersion，密文草稿需 jy-draftc 解密，读不到则为空）。 */
ipcMain.handle('jianying:listDrafts', async (_e, rootPath, ratioKey) => {
  const metaRoot = resolveMetaRoot(rootPath)
  const meta = readMetaStore(metaRoot)
  const out = []
  if (meta && Array.isArray(meta.all_draft_store)) {
    for (const e of meta.all_draft_store) {
      if (e.tm_draft_removed !== 0) continue
      const draftPath = e.draft_fold_path ? path.normalize(e.draft_fold_path) : ''
      const coverPath = e.draft_cover ? path.normalize(e.draft_cover) : ''
      const dims = readImageSize(coverPath) || { width: 0, height: 0 }
      const durationUs = typeof e.tm_duration === 'number' ? e.tm_duration : 0
      out.push({
        name: e.draft_name || '',
        path: draftPath,
        draftPath,
        canvasW: dims.width,
        canvasH: dims.height,
        ratioKey: ratioKeyFromCanvas(dims.width, dims.height),
        hasVideo: durationUs > 0,
        mtime: e.tm_draft_modified || 0,
      })
    }
  } else {
    // 旧版剪映兜底：直接扫描草稿文件夹并读 draft_content.json（明文时才读得出画布）
    const root = rootPath || jianyingDefaultRoot()
    for (const name of safeReaddir(root)) {
      const draftDir = path.join(root, name)
      const dcPath = path.join(draftDir, 'draft_content.json')
      if (!fs.existsSync(dcPath)) continue
      const dc = readJson(dcPath)
      const cfg = dc && dc.canvas_config ? dc.canvas_config : {}
      const w = cfg.width || 0
      const h = cfg.height || 0
      const vids = dc && dc.materials && Array.isArray(dc.materials.videos) ? dc.materials.videos : []
      const st = fs.statSync(draftDir)
      out.push({
        name,
        path: draftDir,
        draftPath: draftDir,
        canvasW: w,
        canvasH: h,
        ratioKey: ratioKeyFromCanvas(w, h),
        hasVideo: vids.length > 0,
        mtime: Math.max(st.mtimeMs || 0, st.ctimeMs || 0),
        appVersion: dc && dc.platform && dc.platform.app_version ? String(dc.platform.app_version) : '',
      })
    }
  }
  // 按比例过滤 → 按最近修改时间降序 → 只保留最新 N 条 → 补充版本号
  const filtered = ratioKey ? out.filter((d) => d.ratioKey === ratioKey) : out
  filtered.sort((a, b) => b.mtime - a.mtime)
  const shown = filtered.slice(0, JY_LIST_LIMIT)
  await enrichJyVersions(shown)
  return { drafts: shown, total: filtered.length }
})

/** 在 root_meta_info.json 里按名字找草稿条目 */
function findMetaEntry(meta, draftName) {
  if (!meta || !Array.isArray(meta.all_draft_store)) return null
  return meta.all_draft_store.find((e) => e.draft_name === draftName && e.tm_draft_removed === 0) || null
}

/** 定位封面图文件 */
function coverPathFromDraft(draftPath, metaEntry) {
  if (metaEntry && metaEntry.draft_cover) {
    const p = path.normalize(metaEntry.draft_cover)
    if (fs.existsSync(p)) return p
  }
  for (const name of ['draft_cover.jpg', 'draft_cover.png', 'draft_cover.jpeg']) {
    const p = path.join(draftPath, name)
    if (fs.existsSync(p)) return p
  }
  return ''
}

ipcMain.handle('jianying:captureEnvelope', async (_e, { rootPath, draftName, draftPath, ratioKey }) => {
  // 未安装剪映时直接给出安装指引（解密依赖其 videoeditor.dll，后面也必然失败）
  if (!detectJianyingInstall().installed) {
    return { ok: false, reason: 'no-install', jyVersion: '', support: JY_DRAFTC_SUPPORT, detail: '' }
  }
  const metaRoot = resolveMetaRoot(rootPath)
  const meta = readMetaStore(metaRoot)
  let src = ''
  let draftRoot = ''

  // 无论是否传了 draftPath，都先按名字查索引条目：
  // 索引里的 tm_duration 是判断「主轨有无占位视频」的唯一可靠来源
  // （新版剪映 draft_content.json 已加密，读不出 materials.videos）。
  // 传 draftPath 时旧代码直接跳过索引查找 → metaEntry 恒为 null → hasVideo 恒为 false，
  // 导致「明明抓的是有视频草稿，信封却显示无视频」。
  const metaEntry = meta ? findMetaEntry(meta, draftName) : null
  // 索引条目必须与目标目录一致才采信（用户手动选过目录时索引可能指向别处）
  const entryMatchesSrc = !!(
    metaEntry &&
    metaEntry.draft_fold_path &&
    ((draftPath && path.normalize(metaEntry.draft_fold_path) === path.normalize(draftPath)) ||
      (!draftPath && rootPath && path.normalize(metaEntry.draft_fold_path) === path.normalize(path.join(rootPath, draftName))))
  )

  if (draftPath) {
    src = path.normalize(draftPath)
  } else if (metaEntry && metaEntry.draft_fold_path) {
    src = path.normalize(metaEntry.draft_fold_path)
  }
  if (!src && rootPath) src = path.join(rootPath, draftName)
  if (!src || !fs.existsSync(path.join(src, 'draft_content.json'))) {
    return { ok: false, reason: 'not-a-draft' }
  }
  if (entryMatchesSrc) {
    draftRoot = metaEntry.draft_root_path ? path.normalize(metaEntry.draft_root_path) : path.dirname(src)
  }

  // 新版剪映加密了 draft_content.json，所以只拷贝整个目录；生成时以解密出的明文模板为基准
  const env = jianyingEnvelopeDir(ratioKey)
  try {
    fs.rmSync(env, { recursive: true, force: true })
  } catch {
    /* 忽略 */
  }
  copyDir(src, env, { excludeMedia: true, skipTransient: true })

  const coverP = coverPathFromDraft(src, metaEntry)
  const dims = readImageSize(coverP) || { width: 0, height: 0 }
  const durationUs = metaEntry && typeof metaEntry.tm_duration === 'number' ? metaEntry.tm_duration : 0
  const hasVideo = durationUs > 0

  // 解密出「明文模板」：之后每次生成新草稿都以它为基准注入成片，保证与当前剪映的草稿结构
  // （new_version，如剪映 11.5 → 187.0.0）完全一致——手搓的旧代最小模板会被新版剪映拒绝打开。
  // 解密失败（剪映版本与内置组件不匹配等）⇒ 整个抓取失败，绝不留下半个不可用的信封。
  const dec = await jyDecryptContentFile(
    path.join(env, 'draft_content.json'),
    path.join(env, 'template_content.json'),
  )
  if (!dec.ok) {
    try { fs.rmSync(env, { recursive: true, force: true }) } catch { /* 忽略 */ }
    return { ok: false, reason: dec.reason, jyVersion: dec.jyVersion || '', support: dec.support || '', detail: dec.detail || '' }
  }

  const manifest = {
    ratioKey,
    canvasW: dims.width,
    canvasH: dims.height,
    hasVideo,
    capturedAt: Date.now(),
    sourceDraftName: draftName || (metaEntry ? metaEntry.draft_name : path.basename(src)),
    /** 索引目录：生成草稿时若找不到 draftRoot 会回退到这里 */
    root: metaRoot,
    /** 实际草稿目录：生成新草稿时优先写回这里 */
    draftRoot,
    /** 信封内含解密出的明文模板（generateDraft 依赖它；缺了即为旧版信封，需重抓） */
    decrypted: true,
    templateNewVersion: dec.newVersion || '',
    jyVersion: dec.jyVersion || '',
  }
  fs.writeFileSync(path.join(env, 'envelope.json'), JSON.stringify(manifest, null, 2))
  return {
    ok: true,
    ratioKey,
    canvasW: dims.width,
    canvasH: dims.height,
    hasVideo,
    newVersion: dec.newVersion || '',
    jyVersion: dec.jyVersion || '',
  }
})

ipcMain.handle('jianying:deleteDraft', async (_e, { rootPath, draftName, draftPath }) => {
  let p = ''
  if (draftPath) {
    p = path.normalize(draftPath)
  } else {
    const metaRoot = resolveMetaRoot(rootPath)
    const meta = readMetaStore(metaRoot)
    const entry = meta ? findMetaEntry(meta, draftName) : null
    if (entry && entry.draft_fold_path) {
      p = path.normalize(entry.draft_fold_path)
    } else {
      const root = rootPath || jianyingDefaultRoot()
      p = path.join(root, draftName)
    }
  }
  if (!p || !fs.existsSync(path.join(p, 'draft_content.json'))) {
    return { ok: false, reason: 'not-a-draft' }
  }
  fs.rmSync(p, { recursive: true, force: true })
  return { ok: true, path: p }
})

ipcMain.handle('jianying:envelopeList', async () => {
  const root = jianyingCacheRoot()
  const out = []
  for (const ratioKey of safeReaddir(root)) {
    const env = path.join(root, ratioKey)
    if (!fs.existsSync(path.join(env, 'envelope.json'))) continue
    const m = readJson(path.join(env, 'envelope.json'))
    if (!m) continue
    out.push({
      ratioKey: m.ratioKey || ratioKey,
      canvasW: m.canvasW || 0,
      canvasH: m.canvasH || 0,
      hasVideo: !!m.hasVideo,
      capturedAt: m.capturedAt || 0,
      sourceDraftName: m.sourceDraftName || '',
      /** 是否含解密出的明文模板（生成依赖它）；旧版信封没有 ⇒ 需重抓 */
      ready: !!m.decrypted && fs.existsSync(path.join(env, 'template_content.json')),
      newVersion: m.templateNewVersion || '',
      jyVersion: m.jyVersion || '',
    })
  }
  return out
})

/** 删除某个比例的本地信封缓存（不影响剪映草稿目录） */
ipcMain.handle('jianying:deleteEnvelope', async (_e, { ratioKey }) => {
  const env = jianyingEnvelopeDir(ratioKey)
  try {
    fs.rmSync(env, { recursive: true, force: true })
    return { ok: true }
  } catch (e) {
    return { ok: false, reason: String((e && e.message) || e) }
  }
})

ipcMain.handle('jianying:generateDraft', async (_e, opts) => {
  const { ratioKey, videoPath, durationSec, fps, width, height, draftName, clips, videos, audioClips,
    // R77：工作台音乐 / 音效轨片段 + 两条轨的总音量（缺省 1 = 不衰减）
    musicClips, musicVolume, sfxVolume } = opts || {}
  const env = jianyingEnvelopeDir(ratioKey)
  const envManifest = readJson(path.join(env, 'envelope.json')) || {}
  const tplPath = path.join(env, 'template_content.json')
  // 没有明文模板 = 没有信封，或是「解密模板」方案上线前抓的旧信封（缺 template_content.json）
  if (!fs.existsSync(tplPath)) {
    return { ok: false, reason: fs.existsSync(path.join(env, 'envelope.json')) ? 'envelope-outdated' : 'no-envelope' }
  }
  const tpl = readJson(tplPath)
  if (!tpl || !Array.isArray(tpl.tracks)) return { ok: false, reason: 'envelope-outdated' }

  // 片段清单提前算：有无整条成片都要先知道 clips 是否可用（跳过整条时靠它兜底）。
  //   过滤掉文件不存在 / 时长非正的项；一条都不剩就退回「整条一段」。
  // ⚠️ lane 必须一并带过去：丢掉它的话 buildDraftFromTemplate 收到的 lane 全是 0，
  //    所有卡被塞进同一条 lane，层级排序彻底失效（背景卡会被前景卡盖住）。
  const clipList = (Array.isArray(clips) ? clips : [])
    .filter((c) => c && c.path && fs.existsSync(String(c.path)) && Number(c.duration) > 0)
    .map((c) => ({
      path: String(c.path),
      start: Number(c.start) || 0,
      duration: Number(c.duration) || 0,
      lane: Number(c && c.lane) || 0,
      kind: String((c && c.kind) || ''),
      // 片段实际像素尺寸（渲染降采样后可能小于画布）：
      // draft 用它写 material 宽高 + clip.scale 放大回满屏。
      // ⚠️ 这几个字段以前在这里被丢过一次（跟 lane 同一个坑），丢了就等于降级成「不降采样」。
      width: Number(c && c.width) || 0,
      height: Number(c && c.height) || 0,
      // 裁剪矩形（源帧坐标系）：有值 ⇒ 走「裁剪 + transform 还原位置」，
      // 丢了就退化成「素材尺寸 = 画布」⇒ 内容被摆在画面正中，位置全错。
      crop:
        c && c.crop && Number(c.crop.width) > 0 && Number(c.crop.height) > 0
          ? {
              x: Number(c.crop.x) || 0,
              y: Number(c.crop.y) || 0,
              width: Number(c.crop.width) || 0,
              height: Number(c.crop.height) || 0,
            }
          : null,
    }))

  // 视频轨片段：token → 本地绝对路径（经 media-registry），过滤缺 token / 路径不存在 / 时长非正。
  //   时间单位在传给 buildDraftFromTemplate 前保持「秒」，由它内部统一换算成微秒。
  const reg = loadMediaRegistry()
  const videoList = (Array.isArray(videos) ? videos : [])
    .map((v) => {
      const tok = v && v.token
      const p = tok ? reg[tok] : null
      if (!p) return null
      return {
        path: String(p).replace(/\\/g, '/'),
        start: Math.max(0, Number(v.start) || 0),
        duration: Math.max(0, Number(v.duration) || 0),
        trimStart: Math.max(0, Number(v.trimStart) || 0),
        width: Number(v.width) || 0,
        height: Number(v.height) || 0,
      }
    })
    .filter((v) => v && fs.existsSync(v.path) && v.duration > 0)

  // 第②层：BASE 态下草稿片段含 pro 卡 ⇒ fail-closed 拒写草稿（不泄漏 pro 内容到剪映）。
  // 片段的 kind 由 renderer 随 clips 传入（与逐卡导出同源），主进程独立复核、不信任 renderer 布尔。
  const clipKinds = (Array.isArray(clips) ? clips : [])
    .map((c) => (c && c.kind) || '')
    .filter(Boolean)
  const { ok: draftProOk } = await exportProOk(clipKinds)
  if (!draftProOk) return { ok: false, reason: 'edition', blocked: true }

  // 「只渲分段、不导整条」（2026-10-16）：整条成片在草稿里根本不被引用，
  //   所以 clips 可用时允许 videoPath 为空；两者都没有才报 no-video。
  const hasFull = !!videoPath && fs.existsSync(String(videoPath))
  if (!hasFull && !clipList.length) return { ok: false, reason: 'no-video' }
  // 封面 / 体积：优先用整条成片，没有就用第一条片段
  const coverSrc = hasFull ? String(videoPath) : clipList[0].path

  // 画布：优先用成片实际分辨率；其次模板自带的画布；最后信封里由封面推断的尺寸
  const tplCanvas = tpl.canvas_config && typeof tpl.canvas_config === 'object' ? tpl.canvas_config : {}
  const canvasW = width || tplCanvas.width || envManifest.canvasW || 1080
  const canvasH = height || tplCanvas.height || envManifest.canvasH || 1920

  // 优先写回抓取时记录的实际草稿目录，其次索引目录，最后默认
  let root = ''
  if (envManifest.draftRoot && fs.existsSync(envManifest.draftRoot)) root = envManifest.draftRoot
  else if (envManifest.root && fs.existsSync(envManifest.root)) root = envManifest.root
  else root = jianyingDraftRoot()
  if (!root || !fs.existsSync(root)) {
    // 区分「根本没装剪映」与「装过但草稿目录被移动」：前者给安装指引，后者给目录指引。
    // 注意只在找不到草稿目录时才判断——剪映装在非默认位置、但信封里记着有效 draftRoot 的用户不受影响。
    if (!detectJianyingInstall().installed) return { ok: false, reason: 'no-install' }
    return { ok: false, reason: 'no-root' }
  }

  // 草稿名：M月d日（与剪映原生草稿命名风格一致）；重名自动加「 (n)」去重
  const baseName = draftName || jyDraftFolderName(new Date())
  let dest = path.join(root, baseName)
  if (fs.existsSync(dest)) {
    let n = 2
    while (n < 100) {
      dest = path.join(root, `${baseName} (${n})`)
      if (!fs.existsSync(dest)) break
      n++
    }
    if (fs.existsSync(dest)) return { ok: false, reason: 'exists' }
  }
  const folderName = path.basename(dest)

  const dur = Math.max(1, Math.round((durationSec || 0) * 1_000_000))
  const nowUs = Date.now() * 1000

  fs.mkdirSync(dest, { recursive: true })

  // 1) 草稿内容：以信封里的「明文模板」（与当前剪映同代结构）为基准注入成片。
  //    绝不整目录拷贝源草稿：旧实现会把 Timelines/、timeline_layout.json、.backup/ 等
  //    剪映自己的状态一起带进来，新版剪映按 activeTimeline 加载到旧时间线，表现为打不开。
  const timelineId = newGuid()
  const dc = buildDraftFromTemplate(tpl, {
    timelineId,
    videoPath: String(hasFull ? videoPath : clipList[0] ? clipList[0].path : videoPath).replace(/\\/g, '/'),
    dur,
    canvasW,
    canvasH,
    fps,
    clips: clipList.length ? clipList : null,
    videos: videoList.length ? videoList : null,
  })
  // ------------------------------------------------------------------
  // 音频轨注入（R77）：三类音频统一走这里，按来源分组、组内 first-fit 分轨。
  //   ① 卡片入场音效：离线渲染好的 WAV 直接写进草稿目录，素材名前缀 MOCUT；
  //   ② 音乐轨 / ③ 音效轨：工作台 overlay.music 的片段，源文件复制进草稿目录，
  //      完整保留 start / offset / duration / speed / volume / fadeIn / fadeOut 语义。
  //   ⚠️ buildDraftFromTemplate 已把模板的内容类素材清空、音频轨全部移除（dc.tracks 只剩视频轨），
  //      所以这里赋值的 dc.materials.audios 就是最终清单，dc.tracks 只需追加音频轨。
  //   ⚠️ 素材 / 段 / 轨结构一律克隆信封模板（与当前剪映同代），只覆盖稳定字段，
  //      避免凭空构造 schema 导致草稿打不开。
  // ------------------------------------------------------------------
  const jyAudios = []
  const jyAudioFades = []
  const jyAudioGroups = []
  const audioMatTpl = tpl.materials && Array.isArray(tpl.materials.audios) && tpl.materials.audios[0]
    ? tpl.materials.audios[0]
    : null
  const audioTrackTpl = (tpl.tracks || []).find((t) => t && t.type === 'audio') || null
  const audioSegTpl = audioTrackTpl && Array.isArray(audioTrackTpl.segments) && audioTrackTpl.segments[0]
    ? audioTrackTpl.segments[0]
    : null
  const jyUs = (sec) => Math.max(0, Math.round((Number(sec) || 0) * 1_000_000))
  const jyRange = (r, s, d) => (r && typeof r === 'object' ? { ...r, start: s, duration: d } : { start: s, duration: d })
  const jySpeed = (v) => {
    const n = Number(v)
    return Number.isFinite(n) && n > 0 ? Math.min(10, Math.max(1, n)) : 1
  }
  const jyGain = (v, d) => {
    const n = Number(v)
    return Number.isFinite(n) ? Math.min(3, Math.max(0, n)) : d
  }

  /** 造一条音频素材 + 一条音频段，返回带时间信息供 first-fit 分轨 */
  function pushJyAudio(o) {
    const matId = newGuid()
    const mat = audioMatTpl
      ? JSON.parse(JSON.stringify(audioMatTpl))
      : { id: matId, type: 'extract_music', name: '', duration: 1, path: '' }
    mat.id = matId
    // ⚠️ type 必须是剪映合法枚举（extract_music/sound/music）——写非法值（如 'audio'）会被
    //    剪映归一化成 'none'：音频照常播放，但时间轴 UI 不渲染素材块（看起来像「没有音效轨」）。
    //    与用户本地导入音频的实测 schema 对齐（type:extract_music + category_name:local）。
    mat.type = 'extract_music'
    mat.name = String(o.name || '音频')
    mat.duration = Math.max(1, o.matDurUs)
    mat.path = String(o.filePath).replace(/\\/g, '/')
    mat.music_id = ''
    mat.resource_id = ''
    mat.category_name = 'local'
    delete mat.music_source
    delete mat.similiar_music_info
    mat.category_id = '0'
    mat.app_id = 1775
    mat.tts_benefit_info = { benefit_type: 'none' }
    // 模板里若带波形缓存，指向的是别的音频，清掉让剪映按新文件重建
    if ('wave_points' in mat) mat.wave_points = []
    jyAudios.push(mat)

    const seg = audioSegTpl
      ? JSON.parse(JSON.stringify(audioSegTpl))
      : { material_id: matId, volume: 1, source: 'segmentsourcenormal' }
    seg.id = newGuid()
    seg.material_id = matId
    seg.source_timerange = jyRange(seg.source_timerange, o.srcStartUs, o.srcDurUs)
    seg.target_timerange = jyRange(seg.target_timerange, o.startUs, o.axisDurUs)
    seg.render_timerange = {}
    // ★ 剪映变速铁律：source_timerange.duration 必须 = target_timerange.duration × speed。
    //   显式写 speed=1 也能避免克隆模板段时把模板自己的 1.25 / 1.35 倍速带过来。
    seg.speed = o.speed
    seg.volume = o.volume
    seg.source = 'segmentsourcenormal'
    const refs = []
    if (o.fadeInUs > 0 || o.fadeOutUs > 0) {
      // 剪映原生淡入淡出：materials.audio_fades + segment.extra_material_refs 双向登记，
      // 单位是微秒、按「输出时间轴」计（与 MP4 的 afade 链同源）。
      const fadeId = newGuid()
      jyAudioFades.push({
        id: fadeId,
        fade_in_duration: o.fadeInUs,
        fade_out_duration: o.fadeOutUs,
        fade_type: 0,
        type: 'audio_fade',
      })
      refs.push(fadeId)
    }
    seg.extra_material_refs = refs
    return { seg, startUs: o.startUs, durUs: o.axisDurUs }
  }

  try {
    // ① 卡片入场音效（WAV 由渲染端离线烘焙，per-call 音量已写进 PCM ⇒ seg.volume 恒 1）
    const entranceItems = []
    const entranceClips = Array.isArray(audioClips) ? audioClips : []
    for (let i = 0; i < entranceClips.length; i++) {
      const ac = entranceClips[i] || {}
      const wavPath = path.join(dest, `MOCUT_sfx_${String(i + 1).padStart(2, '0')}.wav`)
      try {
        fs.writeFileSync(wavPath, ac.data)
      } catch {
        continue
      }
      const durUs = Math.max(1, jyUs(Number(ac.duration) || 1.2))
      entranceItems.push(
        pushJyAudio({
          filePath: wavPath,
          name: `MOCUT音效${i + 1}_${ac.proto || ''}`,
          matDurUs: durUs,
          srcStartUs: 0,
          srcDurUs: durUs,
          startUs: jyUs(ac.time),
          axisDurUs: durUs,
          speed: 1,
          volume: 1,
          fadeInUs: 0,
          fadeOutUs: 0,
        }),
      )
    }
    if (entranceItems.length) jyAudioGroups.push({ label: 'entrance', items: entranceItems })

    // ②③ 工作台音乐轨 / 音效轨：与成片 MP4 的 musicClips 解析口径一致（musicDir + basename）
    const musicTrackVol = jyGain(musicVolume, 1)
    const sfxTrackVol = jyGain(sfxVolume, 1)
    const trackItems = { music: [], sfx: [] }
    const musicList = Array.isArray(musicClips) ? musicClips : []
    for (let i = 0; i < musicList.length; i++) {
      const m = musicList[i] || {}
      if (!m.file) continue
      const src = path.join(musicDir(), path.basename(String(m.file)))
      if (!fs.existsSync(src)) continue
      const startSec = Number(m.start) || 0
      // 老工程若缺 duration：退化为「从落点铺到成片末尾」，绝不静默丢掉用户音频
      const fallbackSec = Math.max(0, Number(durationSec) || 0) - startSec
      const srcSec = Number(m.duration) > 0 ? Number(m.duration) : fallbackSec
      if (!(srcSec > 0)) continue
      const speed = jySpeed(m.speed)
      const srcStartUs = jyUs(m.offset)
      const srcDurUs = Math.max(1, jyUs(srcSec))
      const axisDurUs = Math.max(1, Math.round(srcDurUs / speed))
      const startUs = jyUs(startSec)
      const group = m.track === 'sfx' ? 'sfx' : 'music'
      const outName = `MOCUT_${group}_${String(i + 1).padStart(2, '0')}${path.extname(src) || '.mp3'}`
      const outPath = path.join(dest, outName)
      try {
        fs.copyFileSync(src, outPath)
      } catch {
        continue
      }
      const clipV = jyGain(m.volume, 0.9)
      const trkV = group === 'sfx' ? sfxTrackVol : musicTrackVol
      trackItems[group].push(
        pushJyAudio({
          filePath: outPath,
          name: String(m.name || path.basename(src)),
          // material.duration 至少要覆盖到 source_timerange 末端，否则剪映截不到源区间
          matDurUs: srcStartUs + srcDurUs,
          srcStartUs,
          srcDurUs,
          startUs,
          axisDurUs,
          speed,
          // 与 MP4 混音同口径：最终增益 = 片段音量 × 轨道总音量
          volume: Math.min(3, clipV * trkV),
          fadeInUs: jyUs(m.fadeIn),
          fadeOutUs: jyUs(m.fadeOut),
        }),
      )
    }
    if (trackItems.music.length) jyAudioGroups.push({ label: 'music', items: trackItems.music })
    if (trackItems.sfx.length) jyAudioGroups.push({ label: 'sfx', items: trackItems.sfx })
  } catch {
    /* 音频注入失败不阻断草稿生成 */
  }

  if (jyAudios.length) {
    // 组内按起始时间升序 first-fit：同轨时间重叠的片段拆到新轨，剪映才不会叠在同一条轨上
    const newTracks = []
    for (const g of jyAudioGroups) {
      const ordered = [...g.items].sort((a, b) => a.startUs - b.startUs)
      const laneEnds = []
      const lanes = []
      for (const it of ordered) {
        let li = laneEnds.findIndex((end) => it.startUs >= end)
        if (li < 0) {
          li = laneEnds.length
          laneEnds.push(0)
          lanes.push([])
        }
        laneEnds[li] = it.startUs + it.durUs
        lanes[li].push(it.seg)
      }
      for (const segs of lanes) {
        const atrack = audioTrackTpl
          ? JSON.parse(JSON.stringify(audioTrackTpl))
          : { type: 'audio', is_default_name: true }
        atrack.id = newGuid()
        atrack.type = 'audio'
        atrack.segments = segs
        newTracks.push(atrack)
      }
    }
    // 音频轨与视频轨独立，挂在 tracks 末尾即可（剪映按类型分轨，不参与视频层级堆叠）
    dc.tracks = Array.isArray(dc.tracks) ? [...dc.tracks, ...newTracks] : newTracks
    dc.materials = dc.materials || {}
    dc.materials.audios = jyAudios
    dc.materials.audio_fades = jyAudioFades
  }
  const dcJson = JSON.stringify(dc, null, 2)
  fs.writeFileSync(path.join(dest, 'draft_content.json'), dcJson)

  // 2) 配套文件：信封里除内容/元数据外的剪映配置原样带过来（key_value / attachment / common_attachment 等）
  copyJySupportFiles(env, dest, [
    'draft_content.json',
    'draft_content.json.bak',
    'draft_meta_info.json',
    'envelope.json',
    'template_content.json',
    'draft_cover.jpg',
    'Timelines',
  ])

  // 3) 多时间线结构：新 GUID 的时间线目录 + project.json + timeline_layout.json，三处指针一致
  const tlDir = path.join(dest, 'Timelines', timelineId)
  fs.mkdirSync(tlDir, { recursive: true })
  // 3a) 模板时间线的配套文件（attachment_editing / common_attachment / draft.extra 等）
  const srcTlDir = findTemplateTimelineDir(env)
  if (srcTlDir) {
    copyJySupportFiles(srcTlDir, tlDir, ['draft_content.json', 'draft_content.json.bak', 'draft_cover.jpg'])
  }
  // 3b) 时间线内容与顶层一致（真实草稿两处相同）
  fs.writeFileSync(path.join(tlDir, 'draft_content.json'), dcJson)
  // 3c) project.json：克隆模板的指针结构，只换 id / 主时间线 id / 时间
  const srcProject = readJson(path.join(env, 'Timelines', 'project.json')) || {}
  fs.writeFileSync(
    path.join(dest, 'Timelines', 'project.json'),
    JSON.stringify(
      {
        ...srcProject,
        create_time: nowUs,
        id: newGuid(),
        main_timeline_id: timelineId,
        timelines: [
          { create_time: nowUs, id: timelineId, is_marked_delete: false, name: '时间线01', update_time: nowUs },
        ],
        update_time: nowUs,
      },
      null,
      2,
    ),
  )
  fs.writeFileSync(
    path.join(dest, 'timeline_layout.json'),
    JSON.stringify(
      {
        activeTimeline: timelineId,
        dockItems: [{ dockIndex: 0, ratio: 1, timelineIds: [timelineId], timelineNames: ['时间线01'] }],
        layoutOrientation: 1,
      },
      null,
      2,
    ),
  )

  // 4) 草稿元数据（明文；剪映接受明文 meta）
  const draftId = newGuid()
  fs.writeFileSync(
    path.join(dest, 'draft_meta_info.json'),
    JSON.stringify(
      buildMinimalDraftMeta({
        draftId,
        draftName: folderName,
        draftFoldPath: dest,
        draftRootPath: root,
        durationUs: dur,
      }),
      null,
      2,
    ),
  )

  // 5) 封面：从成片抽首帧；没有整条（只渲分段）时改用第一条片段。剪映列表页靠它显示缩略图
  const coverFile = path.join(dest, 'draft_cover.jpg')
  const coverOk = await extractVideoCover(coverSrc, coverFile)
  if (!coverOk) {
    for (const n of ['draft_cover.jpg', 'draft_cover.png', 'draft_cover.jpeg']) {
      const p = path.join(env, n)
      if (fs.existsSync(p)) {
        fs.copyFileSync(p, coverFile)
        break
      }
    }
  }
  if (fs.existsSync(coverFile)) {
    try { fs.copyFileSync(coverFile, path.join(tlDir, 'draft_cover.jpg')) } catch { /* 忽略 */ }
  }

  // 6) 登记进剪映索引（root_meta_info.json）：不登记剪映也会自己扫出来，但登记后
  //    封面/体积/时长立即可见，且不依赖剪映是否在运行。写失败不影响草稿本身。
  // 体积：整条成片优先；只渲分段时用所有片段之和（只是索引里显示的素材体积）
  let materialsSize = 0
  if (hasFull) {
    try { materialsSize = fs.statSync(videoPath).size } catch { /* 忽略 */ }
  } else {
    for (const c of clipList) {
      try { materialsSize += fs.statSync(c.path).size } catch { /* 忽略 */ }
    }
  }
  registerDraftEntry(envManifest.root || jianyingMetaRoot(), {
    draftId,
    draftName: folderName,
    draftFoldPath: dest,
    draftRootPath: root,
    coverPath: coverFile,
    durationUs: dur,
    materialsSize,
  })

  return { ok: true, draftPath: dest, draftName: folderName }
})

/** 生成剪映接受的 draft_meta_info.json（明文）。
 *  剪映列表页真正读的是索引 root_meta_info.json，这份是草稿目录内的自描述元数据。 */
function buildMinimalDraftMeta({ draftId, draftName, draftFoldPath, draftRootPath, durationUs }) {
  return {
    cloud_package_completed_time: '',
    draft_cloud_capcut_purchase_info: '',
    draft_cloud_last_action_download: false,
    draft_cloud_materials: [],
    draft_cloud_purchase_info: '',
    draft_cloud_template_id: '',
    draft_cloud_tutorial_info: '',
    draft_cloud_videocut_purchase_info: '',
    draft_cover: '',
    draft_deeplink_url: '',
    draft_enterprise_info: { draft_enterprise_extra: '', draft_enterprise_id: '', draft_enterprise_name: '', enterprise_material: [] },
    draft_fold_path: draftFoldPath || '',
    draft_id: draftId || newDraftId(),
    draft_is_ai_packaging_used: false,
    draft_is_ai_shorts: false,
    draft_is_ai_translate: false,
    draft_is_article_video_draft: false,
    draft_is_from_deeplink: 'false',
    draft_is_invisible: false,
    draft_materials: [
      { type: 0, value: [] }, { type: 1, value: [] }, { type: 2, value: [] },
      { type: 3, value: [] }, { type: 6, value: [] }, { type: 7, value: [] }, { type: 8, value: [] },
    ],
    draft_materials_copied_info: [],
    draft_name: draftName || '',
    draft_new_version: '',
    draft_removable_storage_device: '',
    draft_root_path: draftRootPath || '',
    draft_segment_extra_info: [],
    draft_type: '',
    tm_draft_cloud_completed: '',
    tm_draft_cloud_modified: 0,
    tm_draft_removed: 0,
    tm_duration: durationUs || 0,
  }
}

ipcMain.on('edition:changed', () => {
  // 激活/退出后通知所有窗口刷新 edition 状态
  BrowserWindow.getAllWindows().forEach((w) => {
    w.webContents.send('edition:refresh')
  })
})
