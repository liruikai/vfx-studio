/* ------------------------------------------------------------------ *
 * 人像遮罩预计算 · worker 线程（2026-10-28）
 *
 * 为什么独立成 worker：MODNet 推理 + ffmpeg 双管道是 CPU 密集活，
 * 若跑在 Electron 主进程会占满事件循环 → 整个客户端卡死、进度 IPC 发不出去。
 * 这里只做重活，主进程（portrait-mask.cjs）只负责转发进度、保持 UI 响应。
 *
 * 本文件不 require electron（避免 fork/worker 里的 app 实例问题），
 * 模型路径 / ffmpeg 路径 / 视频路径 / 输出路径全部由 workerData 传入。
 * ------------------------------------------------------------------ */
const { parentPort, workerData } = require('worker_threads')
const fs = require('fs')
const { execFile, spawn } = require('child_process')

const { videoPath, outPath, ffmpegPath, modelPath } = workerData

const INFER_SIZE = 512 // MODNet 输入边长（拉伸）
const FRAME_BYTES = INFER_SIZE * INFER_SIZE * 3
const MAX_FPS = 30
const MIN_FPS = 8

function post(type, payload) {
  parentPort.postMessage({ type, ...payload })
}

/** 从 `ffmpeg -i` stderr 解析 时长/宽高/帧率 */
function probeVideo(videoPath, ffmpeg) {
  return new Promise((resolve, reject) => {
    execFile(
      ffmpeg,
      ['-hide_banner', '-i', videoPath],
      { maxBuffer: 8 * 1024 * 1024, timeout: 30000, windowsHide: true },
      (err, _stdout, stderr) => {
        const s = String(stderr || '')
        let duration = 0
        const dm = s.match(/Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)/)
        if (dm) duration = (+dm[1]) * 3600 + (+dm[2]) * 60 + parseFloat(dm[3])
        let width = 0
        let height = 0
        const vm = s.match(/Stream #\d+:\d+.*?Video:.*?(\d{2,5})x(\d{2,5})/)
        if (vm) {
          width = parseInt(vm[1], 10)
          height = parseInt(vm[2], 10)
        }
        let fps = 30
        const fm = s.match(/([\d.]+)\s*fps/)
        if (fm) fps = parseFloat(fm[1])
        if (!Number.isFinite(fps) || fps <= 0) fps = 30
        if (duration <= 0 || width <= 0 || height <= 0) {
          reject(new Error('无法解析源视频（时长/尺寸）'))
          return
        }
        resolve({ duration, width, height, fps: Math.min(MAX_FPS, Math.max(MIN_FPS, fps)) })
      },
    )
  })
}

;(async () => {
  let cancelled = false
  // 主进程发 cancel 消息 → 这里置旗，下一轮循环抛出「已取消」
  parentPort.on('message', (m) => {
    if (m && m.type === 'cancel') cancelled = true
  })

  try {
    const ort = require('onnxruntime-node')
    const t0 = Date.now()
    const meta = await probeVideo(videoPath, ffmpegPath)
    const { duration, width, height, fps } = meta
    const total = Math.max(1, Math.ceil(duration * fps))
    post('progress', { done: 0, total, phase: 'decode' })

    const session = await ort.InferenceSession.create(modelPath, { executionProviders: ['cpu'] })
    const inputName = session.inputNames[0]
    const outputName = session.outputNames[0]

    // 解码：源视频 → 512×512 rgb24 原始帧流（stdout）
    const dec = spawn(
      ffmpegPath,
      [
        '-hide_banner',
        '-i', videoPath,
        '-map', '0:v:0',
        '-an', '-sn',
        '-vf', `fps=${fps},scale=${INFER_SIZE}:${INFER_SIZE}:flags=bilinear`,
        '-f', 'rawvideo',
        '-pix_fmt', 'rgb24',
        '-',
      ],
      { windowsHide: true, stdio: ['ignore', 'pipe', 'ignore'] },
    )
    // 编码：灰度帧流（stdin）→ 全量程 yuv420p h264 mask 视频（缩放回源分辨率）
    const enc = spawn(
      ffmpegPath,
      [
        '-hide_banner',
        '-f', 'rawvideo',
        '-pix_fmt', 'gray',
        '-s', `${INFER_SIZE}x${INFER_SIZE}`,
        '-r', String(fps),
        '-i', '-',
        '-vf', `scale=${width}:${height}:flags=bilinear,format=yuv420p`,
        '-c:v', 'libx264',
        '-preset', 'veryfast',
        '-crf', '16',
        '-color_range', 'pc',
        '-x264-params', 'range=pc',
        '-movflags', '+faststart',
        '-threads', '2',
        '-y', outPath,
      ],
      { windowsHide: true, stdio: ['pipe', 'ignore', 'ignore'] },
    )

    let decErr = null
    let encErr = null
    dec.on('error', (e) => (decErr = e))
    enc.on('error', (e) => (encErr = e))

    // ── 帧读取器：把 stdout 字节流切成定长帧，带暂停背压 ──
    let pendingResolve = null
    const bufList = []
    let buffered = 0
    let decodeEnded = false
    let decodeError = null
    dec.stdout.on('data', (d) => {
      bufList.push(d)
      buffered += d.length
      if (buffered >= FRAME_BYTES * 3) {
        try { dec.stdout.pause() } catch { /* 流可能已关 */ }
      }
      if (pendingResolve) {
        const r = pendingResolve
        pendingResolve = null
        r()
      }
    })
    dec.stdout.on('end', () => (decodeEnded = true))
    dec.stdout.on('error', (e) => (decodeError = e))

    async function readFrame() {
      while (buffered < FRAME_BYTES && !decodeEnded && !decodeError) {
        await new Promise((r) => (pendingResolve = r))
      }
      if (buffered < FRAME_BYTES) return null // 流尽（不足一帧的尾巴丢弃）
      let frame
      if (bufList[0].length >= FRAME_BYTES) {
        frame = bufList[0].subarray(0, FRAME_BYTES)
        bufList[0] = bufList[0].subarray(FRAME_BYTES)
        if (bufList[0].length === 0) bufList.shift()
      } else {
        const merged = Buffer.concat(bufList)
        frame = merged.subarray(0, FRAME_BYTES)
        const rest = merged.subarray(FRAME_BYTES)
        bufList.length = 0
        if (rest.length) bufList.push(rest)
      }
      buffered -= FRAME_BYTES
      if (buffered < FRAME_BYTES * 2) {
        try { dec.stdout.resume() } catch { /* 流可能已关 */ }
      }
      return frame
    }

    const chw = new Float32Array(1 * 3 * INFER_SIZE * INFER_SIZE)
    let done = 0
    try {
      for (;;) {
        if (cancelled) throw new Error('cancelled')
        const frame = await readFrame()
        if (!frame) break
        // RGB [0,255] → CHW Float32 [0,1]（验证过的唯一口径）
        for (let c = 0; c < 3; c++) {
          const base = c * INFER_SIZE * INFER_SIZE
          for (let i = 0; i < INFER_SIZE * INFER_SIZE; i++) {
            chw[base + i] = frame[i * 3 + c] / 255
          }
        }
        const out = await session.run({ [inputName]: new ort.Tensor('float32', chw, [1, 3, INFER_SIZE, INFER_SIZE]) })
        const matte = out[outputName].data
        const gray = Buffer.alloc(INFER_SIZE * INFER_SIZE)
        for (let i = 0; i < gray.length; i++) {
          const v = matte[i]
          gray[i] = v <= 0 ? 0 : v >= 1 ? 255 : (v * 255) | 0
        }
        // stdin 背压：write 返回 false 时等 drain，防止内存无限涨
        if (!enc.stdin.write(gray)) {
          await new Promise((r) => enc.stdin.once('drain', r))
        }
        done++
        if (done % 5 === 0 || done === total) {
          post('progress', { done, total, phase: 'infer' })
          if (done % 20 === 0) await new Promise((r) => setTimeout(r, 0))
        }
        if (cancelled) throw new Error('cancelled')
      }
    } finally {
      try { enc.stdin.end() } catch { /* 已关 */ }
    }
    if (cancelled) throw new Error('cancelled')
    // 等 ffmpeg 编码收尾
    await new Promise((resolve) => {
      const t = setTimeout(() => resolve(), 120000)
      enc.once('close', () => {
        clearTimeout(t)
        resolve()
      })
    })
    if (encErr || decErr) throw new Error('ffmpeg 管道失败：' + String(encErr || decErr))
    if (!fs.existsSync(outPath) || fs.statSync(outPath).size < 1024) {
      throw new Error('mask 视频生成失败（输出为空）')
    }
    post('done', { maskPath: outPath, frames: done, ms: Date.now() - t0 })
  } catch (err) {
    const msg = err && err.message ? err.message : String(err)
    post('error', { message: msg === 'cancelled' ? '已取消' : msg })
  }
})()
