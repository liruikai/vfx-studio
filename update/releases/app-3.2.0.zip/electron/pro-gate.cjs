'use strict'
/**
 * PRO 门控（主进程权威版）—— 第②层防破解的核心。
 *
 * 设计要点：
 *  - renderer 里的 isPro/kindAvailable 只是「界面友好」的展示层判定；真正的安全边界
 *    必须落在被签名清单保护的主进程代码里（改 main.cjs / 本文件即触发第①层 fail-closed）。
 *  - 本模块不依赖 Electron，纯 Node crypto，主进程 require 它、单测也能直接 require。
 *
 * 为何可信：
 *  - 激活码由开发者私钥签发，内含本机机器码；无私钥无法伪造（PRO_PUBLIC_KEY 只用于验签）。
 *  - PRO_KINDS 内嵌在本文件（在 integrity.json 清单内），篡改即第①层不通过。
 *  - 机器码用主进程读到的系统级 ID（与 renderer 桌面端同源），保证开发者签发的码只能在本机验过。
 *
 * 用法：
 *  - 主进程：require 后 setMachineIdProvider(systemMachineId)，导出时 isPro(loadAppState()) 判定。
 *  - 导出卡清单复核：blockedKinds(kinds, pro) 返回 BASE 态下应被剔除的 pro 卡种。
 */
const crypto = require('node:crypto')
const { subtle } = crypto.webcrypto

// 内置公钥（与 src/lib/edition.ts 的 PRO_PUBLIC_KEY 同源；私钥只在开发者机器，绝不进包）
const PRO_PUBLIC_KEY_B64 =
  'MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE1ShQHULsoWvG771ufhVoZkJO4x+XJjIHUjYGEdFd+LAZ2LfMXR3bZxA2UoHIertqLM76e7XDjg624G9xApYagQ=='

// 全部 pro 卡种（与 src/lib/cards.ts 中 edition:'pro' 的卡一一对应）。
// ⚠️ 改 cards.ts 增删 pro 卡必须同步改这里，否则 check_pro_kinds_num.cjs 闸门会红（单一真相源）。
const PRO_KINDS = new Set([
  // 2026-10 创建
  "icon-title-tag-1", // 2026-10-17
  "tag-negate-1", // 2026-10-17
  "micro-jump-info-1", // 2026-10-18
  "grow-bars-panel-1", // 2026-10-18
  "draw-area-line-1", // 2026-10-18
  "sweep-donut-1", // 2026-10-18
  "rank-bar-list-1", // 2026-10-18
  "input-confirm-transition-1", // 2026-10-18
  "tag-link-1", // 2026-10-18
  "bar-compare-1", // 2026-10-18
  "toggle-switch-1", // 2026-10-18
  "slider-tier-1", // 2026-10-18
  "curve-ratio-1", // 2026-10-18
  "text-edit-window-1", // 2026-10-19
  "search-result-list-1", // 2026-10-19
  "screen-template-1", // 2026-10-19
  "block-steps-1", // 2026-10-19
  "text-card-frame-1", // 2026-10-19
  "gauge-data-1", // 2026-10-19
  "gold-big-text-1", // 2026-10-19
  "game-menu-1", // 2026-10-20
  "product-show-1", // 2026-10-20
  "text-slam-1", // 2026-10-21
  "text-slam-tag-1", // 2026-10-21
  "text-group-pop-1", // 2026-10-21
  "text-scramble-2", // 2026-10-21
  "circular-loop-1", // 2026-10-21
  "text-group-slam-1", // 2026-10-21
  "plus-icon-1", // 2026-10-21
  "absorb-hint-1", // 2026-10-22
  "tag-rhythm-1", // 2026-10-22
  "kw-bounce-1", // 2026-10-22
  "stairs-jump-1", // 2026-10-22
  "label-stack-1", // 2026-10-22
  "activate-icon-1", // 2026-10-22
  "motion-lib-1", // 2026-10-23
  "en-bounce-in-1", // 2026-10-23
  "repop-text-1", // 2026-10-23
  "text-slam-tag-2", // 2026-10-23
  "focus-burst-1", // 2026-10-23
  "marquee-rows-1", // 2026-10-23
  "panel-keyword-1", // 2026-10-23
  "keys-breakdown-1", // 2026-10-23
  "pill-text-2", // 2026-10-24
  "text-tag-negate-1", // 2026-10-24
  "text-tag-affirm-1", // 2026-10-24
  "text-plus-icon-1", // 2026-10-24
  "bubble-text-1", // 2026-10-24
  "emoji-motion-1", // 2026-10-24
  "block-icon-text-1", // 2026-10-26
  "num-roll-2", // 2026-10-26
  "text-slam-shake-1", // 2026-10-26
  "arrow-group-r-1", // 2026-10-26
  "tag-group-pop-1", // 2026-10-26
  "script-write-1", // 2026-10-26
  "node-intro-1", // 2026-10-26
  "block-icon-text-2", // 2026-10-26
  "data-progress-1", // 2026-10-26
  "label-stack-2", // 2026-10-26
  "label-stack-3", // 2026-10-26
  "num-roll-3", // 2026-10-27
  "slam-redshift-1", // 2026-10-27
  "stripe-sweep-bg-1", // 2026-10-27
  "equalizer-bg-1", // 2026-10-27
  "split-blocks-bg-1", // 2026-10-27
  "halftone-fade-bg-1", // 2026-10-27
  "contour-waves-bg-1", // 2026-10-27
  "cloud-drift-bg-1", // 2026-10-27
  "bubble-rise-bg-1", // 2026-10-27
  "star-twinkle-bg-1", // 2026-10-27
  "memphis-float-bg-1", // 2026-10-27
  "rainbow-arcs-bg-1", // 2026-10-27
  "barrage-fly-text-1", // 2026-10-27
  "shatter-reassemble-text-1", // 2026-10-27
  "neon-glow-text-1", // 2026-10-27
  "brush-ink-text-1", // 2026-10-27
  "pixel-assemble-text-1", // 2026-10-27
  "flip-board-text-1", // 2026-10-27
  "ripple-mirror-text-1", // 2026-10-27
  "radar-scan-link-1", // 2026-10-27
  "conveyor-stamp-link-1", // 2026-10-27
  "magnet-dock-link-1", // 2026-10-27
  "srt-caption-1", // 2026-10-28
  "rolling-hills-bg-1", // 2026-10-28
  "sun-burst-bg-1", // 2026-10-28
  "town-scape-bg-1", // 2026-10-28
  "doodle-float-bg-1", // 2026-10-28
  "candy-waves-bg-1", // 2026-10-28
  "comment-typing-1", // 2026-10-28
  "mind-nodes-1", // 2026-10-28
  "confetti-rain-1", // 2026-10-28
  "skeleton-load-1", // 2026-10-28
  "dots-reveal-1", // 2026-10-29
  "sticker-float-1", // 2026-10-29
  "timecode-hud-1", // 2026-10-29
  "burst-accent-1", // 2026-10-29
  "pure-bg-1", // 2026-10-29
  "pill-text-3", // 2026-10-29
  "pill-text-4", // 2026-10-29
  "srt-caption-2", // 2026-10-29
  "code-terminal-1", // 2026-10-29
  "phone-app-launch-1", // 2026-10-29
  "quest-roadmap-1", // 2026-10-29
  "stage-clear-1", // 2026-10-29
  "leaderboard-1", // 2026-10-29
  "skill-negate-1", // 2026-10-29
  "skill-tree-1", // 2026-10-29
  "world-progress-1", // 2026-10-29
  "podcast-big-text-1", // 2026-10-29
  "workflow-check-1", // 2026-10-29
  "device-flow-1", // 2026-10-29
  "slot-percent-1", // 2026-10-29
  "checker-wipe-1", // 2026-10-30
  "block-sequence-1", // 2026-10-30
  "num-roll-4", // 2026-10-30
  "num-roll-5", // 2026-10-30
  "cartoon-anim-1", // 2026-10-30
  "points-link-1", // 2026-10-31
  "panel-tag-2", // 2026-10-31
  "three-geo-1", // 2026-10-31
  // 2026-11 创建
  "liquid-search-1", // 2026-11-02
  "chapter-bar-2", // 2026-11-02
  "scribble-underline-1", // 2026-11-02
  "scribble-circle-1", // 2026-11-02
  "scribble-arrow-1", // 2026-11-02
  "white-panel-1", // 2026-11-02
  "grow-box-1", // 2026-11-02
  "fx-flash-1", // 2026-11-02
  "fx-iris-1", // 2026-11-02
  "fx-barn-door-1", // 2026-11-02
  "fx-mask-wipe-1", // 2026-11-02
  "fx-glitch-1", // 2026-11-02
  "fx-black-card-1", // 2026-11-02
  "fx-whip-pan-1", // 2026-11-02
  "fx-block-wipe-1", // 2026-11-02
  "fx-cam-3d-1", // 2026-11-03
  "promo-flash-1", // 2026-11-03
  "media-fan-1", // 2026-11-04
  "media-spotlight-1", // 2026-11-04
  "transition-travel", // 2026-11-05
  "dataviz-landscape-open", // 2026-11-05
  "fx-circle-burst-1", // 2026-11-05
  "single-page-1", // 2026-11-05
  "tech-globe-3d-bg", // 2026-11-05
  "tech-cube-grid-3d-bg", // 2026-11-05
  "food-plate-3d-bg", // 2026-11-05
  "hotel-arch-3d-bg", // 2026-11-05
  "retail-crate-3d-bg", // 2026-11-05
  "retail-tag-orbit-3d-bg", // 2026-11-05
  "edu-book-stack-3d-bg", // 2026-11-05
  "edu-atom-3d-bg", // 2026-11-05
  "mfg-gears-3d-bg", // 2026-11-05
  "mfg-assembly-3d-bg", // 2026-11-05
  "tech-neural-3d-bg", // 2026-11-05
  "tech-ai-chip-3d-bg", // 2026-11-05
  "tech-token-tunnel-3d-bg", // 2026-11-05
  "promo-opener-1", // 2026-11-05
  "impact-hit-counter", // 2026-11-06
  "impact-anime", // 2026-11-06
  "pure-bg-2", // 2026-11-06
  "beat-step-list-theme-cycle", // 2026-11-09
])

// 机器码提供方：主进程注入 systemMachineId（与 renderer 桌面端同源）；测试可注入桩。
let _machineIdProvider = () => 'na'
function setMachineIdProvider(fn) {
  _machineIdProvider = typeof fn === 'function' ? fn : () => 'na'
}

// FNV-1a，输出 8 位 hex（与 edition.ts 的 hashStr 同口径）
function fnv1a(s) {
  let h = 0x811c9dc5
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i)
    h = Math.imul(h, 0x01000193)
  }
  return (h >>> 0).toString(16).padStart(8, '0')
}

// 规范机器码（无连字符）：与 edition.ts machineCodeNorm 桌面端同口径（用系统级 ID）
function machineCodeNorm() {
  const mid = _machineIdProvider()
  const base = mid && mid !== 'na' ? fnv1a('vfx-mc-guid:' + mid) : fnv1a('vfx-mc-guid:na')
  const ext = fnv1a('vfx-mc-salt:' + base)
  return 'VFXMC' + (base + ext).toUpperCase()
}

function b64urlToBytes(b64) {
  const s = String(b64).replace(/-/g, '+').replace(/_/g, '/')
  const pad = s.length % 4 === 0 ? '' : '='.repeat(4 - (s.length % 4))
  return Buffer.from(s + pad, 'base64')
}

/**
 * 验证激活码：ECDSA 验签 + 过期 + 机器码比对。
 * 与 edition.ts verifyActivation、scripts/issue_pro_key.cjs 同口径（均用 WebCrypto，签名是 raw R||S / P1363）。
 *
 * ⚠️ 必须用 WebCrypto subtle.verify（raw），不能用 Node 老 crypto.verify（默认期望 DER 格式）。
 *    issue_pro_key.cjs 用 subtle.sign 签出的是 raw 码；若主进程用 crypto.verify 验，raw 码会验不过，
 *    表现为「专业版每次打开闪回基础版」（renderer 端用 subtle.verify 能验过，所以以前正常）。2026-10-16 确诊。
 * 返回 { ok, expired?, mcMismatch?, clockSkew? }
 *
 * opts.clockSuspect（由主进程的时钟回拨检测给出）：为 true 时，**期限码**一律按已到期处理。
 * 系统时间被往回调是零成本破解（改 Windows 日期即可让 exp 永不到来），必须由这个外部信号兜住；
 * 永久码（exp=0）没有到期概念，不受影响。
 */
async function verifyProCode(raw, opts) {
  try {
    const m = String(raw || '').trim().match(/^VFXPRO-(.+)$/i)
    if (!m) return { ok: false }
    const inner = m[1]
    const dot = inner.indexOf('.')
    if (dot < 0) return { ok: false }
    const payloadB64 = inner.slice(0, dot)
    const sigB64 = inner.slice(dot + 1)
    let payload
    try {
      payload = JSON.parse(b64urlToBytes(payloadB64).toString('utf8'))
    } catch {
      return { ok: false }
    }
    // WebCrypto 验签：签名是 raw R||S（与 subtle.sign / issue_pro_key.cjs 同格式）。
    // ⚠️ subtle.verify 只认 WebCrypto CryptoKey，不能用 crypto.createPublicKey 的 Node KeyObject。
    const pub = await subtle.importKey(
      'spki',
      Buffer.from(PRO_PUBLIC_KEY_B64, 'base64'),
      { name: 'ECDSA', namedCurve: 'P-256' },
      false,
      ['verify'],
    )
    const valid = await subtle.verify(
      { name: 'ECDSA', hash: 'SHA-256' },
      pub,
      b64urlToBytes(sigB64),
      Buffer.from(payloadB64, 'utf8'),
    )
    if (!valid) return { ok: false }
    if (payload.ed !== 'pro') return { ok: false }
    if (payload.exp && Date.now() > payload.exp) return { ok: false, expired: true }
    if (payload.exp && opts && opts.clockSuspect) return { ok: false, clockSkew: true }
    if (payload.mc !== machineCodeNorm()) return { ok: false, mcMismatch: true }
    return { ok: true }
  } catch {
    return { ok: false }
  }
}

/** 从 app-state 对象判断是否为 PRO（激活码以 'VX1.' 前缀存于 vfx-studio:edition） */
async function isPro(state, opts) {
  const raw = (state && state['vfx-studio:edition']) || ''
  const code = raw.startsWith('VX1.') ? raw.slice(4) : raw
  if (!code) return false
  return (await verifyProCode(code, opts)).ok
}

/**
 * 更新资格判定（第②层，主进程权威）：把「能否接收软件更新」与「是否 PRO」分离。
 * 规则（2026-11-02 用户拍板）：仅「永久」与「在期订阅」可更新；
 *   免费基础版（无码）与到期订阅（有码已过期）都冻结在旧版本。
 * 返回：
 *   'active'   —— 有码且在期（exp 为空=永久 或 exp>now），可更新
 *   'expired'  —— 有码但已过期（订阅过、没续费）
 *   'clock'    —— 有期限码，但检测到系统时间被回拨（按到期处理，提示校准时间）
 *   'free'     —— 无码 / 验签失败 / 机器码不符（免费基础版）
 * 本函数不依赖渲染进程，落于签名清单保护内，无法被前端绕过。
 */
async function updateEligible(state, opts) {
  const raw = (state && state['vfx-studio:edition']) || ''
  const code = raw.startsWith('VX1.') ? raw.slice(4) : raw
  if (!code) return 'free'
  const v = await verifyProCode(code, opts)
  if (v.ok) return 'active'
  if (v.expired) return 'expired'
  if (v.clockSkew) return 'clock'
  return 'free'
}

function isProKind(kind) {
  return PRO_KINDS.has(kind)
}

/**
 * 导出卡清单复核：给定本次导出用到的卡种集合与是否 PRO，
 * 返回 BASE 态下应被剔除（不应导出）的 pro 卡种子集。
 * 主进程在导出合成前调用：非空即 fail-closed 拦截（拦/剔除）。
 */
function blockedKinds(kinds, pro) {
  if (pro) return []
  const out = []
  for (const k of kinds || []) if (PRO_KINDS.has(k)) out.push(k)
  return out
}

module.exports = {
  PRO_PUBLIC_KEY_B64,
  PRO_KINDS,
  setMachineIdProvider,
  fnv1a,
  machineCodeNorm,
  b64urlToBytes,
  verifyProCode,
  isPro,
  updateEligible,
  isProKind,
  blockedKinds,
}
