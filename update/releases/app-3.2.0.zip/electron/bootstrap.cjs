'use strict'
/**
 * Electron 入口引导（2026-11-02 防破解加固）
 * ───────────────────────────────────────────────────────────────────────────
 * 真正的主进程逻辑已编译成 V8 字节码 `main.jsc`，源码 `main.cjs` 只作回退：
 *   纯本地 Electron 客户端里「源码可读 = 逻辑可被读懂并打补丁」（改 isPro / 删 exp 判断 /
 *   跳过签名校验），字节码把这条路从「改一行」抬成「盲改二进制」。
 *
 * 回退为什么不是后门：
 *   ① 触发条件只有「字节码与当前 Electron/V8 不兼容」（cachedDataRejected），
 *      也就是升级 Electron 后忘了跑 `npm run build:bytecode` 的场景；
 *   ② main.cjs / main.jsc / 本文件都在 dist/integrity.json 的签名清单内，
 *      改任何一个都会被启动校验拦下并只显示「完整性校验未通过」错误页；
 *   ③ 想靠回退解锁 PRO，必须先把 main.jsc 弄坏 —— 那会让完整性校验失败，直接不加载界面。
 *
 * ⚠️ 升级 Electron 后请重跑：`npm run build:bytecode`（会重写 bytecode-target.json）。
 */
const path = require('path')
const fs = require('fs')

const dir = __dirname
let target = null
try {
  target = JSON.parse(fs.readFileSync(path.join(dir, 'bytecode-target.json'), 'utf8'))
} catch {
  /* 没有版本戳：直接走源码（首次开发 / 未编译过字节码） */
}

function boot() {
  if (target && target.electron === process.versions.electron) {
    try {
      require('bytenode')
      global.__vfxBootMode = 'main.jsc'
      require(path.join(dir, 'main.jsc'))
      return
    } catch (e) {
      global.__vfxBootMode = 'main.cjs(fallback)'
      console.error('[bootstrap] main.jsc 加载失败，回退 main.cjs：', e && e.message)
    }
  } else if (target) {
    global.__vfxBootMode = 'main.cjs(stamp-mismatch)'
    console.error(
      `[bootstrap] 字节码目标 Electron ${target.electron} ≠ 当前 ${process.versions.electron}，回退 main.cjs（请重跑 build:bytecode）`,
    )
  } else {
    global.__vfxBootMode = 'main.cjs(no-stamp)'
  }
  require(path.join(dir, 'main.cjs'))
}

boot()
