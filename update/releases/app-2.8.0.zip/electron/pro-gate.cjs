'use strict'
/**
 * PRO 门控（主进程权威版）—— 第②层防破解的核心。
 *
 * 设计要点：
 *  - renderer 里的 isPro/kindAvailable 只是「界面友好」的展示层判定；真正的安全边界
 *    必须落在被签名清单保护的主进程代码里（改 main.cjs / 本文件即触发第①层 fail-closed）。
 *  - 本模块不依赖 Electron，纯 Node crypto，主进程 require 它、单测也能直接 require。
 *
 * 为何可信：
 *  - 激活码由开发者私钥签发，内含本机机器码；无私钥无法伪造（PRO_PUBLIC_KEY 只用于验签）。
 *  - PRO_KINDS 内嵌在本文件（在 integrity.json 清单内），篡改即第①层不通过。
 *  - 机器码用主进程读到的系统级 ID（与 renderer 桌面端同源），保证开发者签发的码只能在本机验过。
 *
 * 用法：
 *  - 主进程：require 后 setMachineIdProvider(systemMachineId)，导出时 isPro(loadAppState()) 判定。
 *  - 导出卡清单复核：blockedKinds(kinds, pro) 返回 BASE 态下应被剔除的 pro 卡种。
 */
const crypto = require('node:crypto')
const { subtle } = crypto.webcrypto

// 内置公钥（与 src/lib/edition.ts 的 PRO_PUBLIC_KEY 同源；私钥只在开发者机器，绝不进包）
const PRO_PUBLIC_KEY_B64 =
  'MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE1ShQHULsoWvG771ufhVoZkJO4x+XJjIHUjYGEdFd+LAZ2LfMXR3bZxA2UoHIertqLM76e7XDjg624G9xApYagQ=='

// 全部 pro 卡种（与 src/lib/cards.ts 中 edition:'pro' 的卡一一对应）。
// ⚠️ 改 cards.ts 增删 pro 卡必须同步改这里，否则 check_pro_kinds_num.cjs 闸门会红（单一真相源）。
const PRO_KINDS = new Set([
  "absorb-hint-1",
  "axis-timeline-1",
  "bar-compare-1",
  "bar-race-1",
  "big-number-panel-1",
  "block-icon-text-1",
  "block-icon-text-2",
  "node-intro-1",
  "data-progress-1",
  "label-stack-2",
  "label-stack-3",
  "num-roll-2",
  "num-roll-3",
  "slam-redshift-1",
  "text-slam-shake-1",
  "arrow-group-r-1",
  "tag-group-pop-1",
  "script-write-1",
  "block-steps-1",
  "blur-region-1",
  "brand-logo-1",
  "brand-logo-2",
  "capsule-focus-1",
  "capsule-number-panel-1",
  "cartoon-bar-1",
  "circular-loop-1",
  "coord-stretch-1",
  "cover-link-1",
  "curve-ratio-1",
  "data-slant-title-1",
  "data-timeline-1",
  "displaced-text-1",
  "dot-bg-1",
  "draw-area-line-1",
  "en-bounce-in-1",
  "cartoon-anim-1",
  "event-timeline-1",
  "game-menu-1",
  "gauge-data-1",
  "glass-bars-1",
  "gold-big-text-1",
  "grid-bg-1",
  "grid-corner-panel-1",
  "grow-bars-panel-1",
  "icon-list-1",
  "icon-orbit-1",
  "icon-title-tag-1",
  "img-in-1",
  "info-box-group-1",
  "info-bridge-1",
  "info-flood-1",
  "info-panel-1",
  "info-strip-1",
  "input-confirm-transition-1",
  "kw-bar-1",
  "kw-bounce-1",
  "kw-bubble-1",
  "kw-dash-1",
  "kw-flash-1",
  "kw-palette-1",
  "kw-photo-1",
  "kw-plate-1",
  "kw-title-roll-1",
  "light-pillar-1",
  "line-chart-1",
  "logic-map-1",
  "magnifier-1",
  "media-collapse-1",
  "media-column-1",
  "media-diagonal-1",
  "media-head-3-1",
  "media-row-1",
  "media-shadow-1",
  "media-zoom-1",
  "micro-jump-info-1",
  "milestone-1",
  "num-roll-1",
  "orbit-cluster-1",
  "pain-point-1",
  "perf-bars-1",
  "phase-list-1",
  "pie-cone-1",
  "pill-carousel-1",
  "pill-text-1",
  "pill-text-2",
  "pill-text-3",
  "pill-text-4",
  "plus-icon-1",
  "product-show-1",
  "quote-bubble-1",
  "rank-banner-1",
  "rank-bar-list-1",
  "ring-load-1",
  "screen-template-1",
  "search-box-1",
  "search-result-list-1",
  "single-line-panel-1",
  "slider-tier-1",
  "step-flow-1",
  "style-list-1",
  "sweep-donut-1",
  "tag-link-1",
  "tag-negate-1",
  "tag-rhythm-1",
  "text-card-frame-1",
  "text-edit-window-1",
  "text-group-pop-1",
  "text-group-slam-1",
  "text-intro-1",
  "text-mask-1",
  "text-part-title-1",
  "text-prompt-box-1",
  "text-rain-in-1",
  "text-scramble-1",
  "text-scramble-2",
  "text-slam-1",
  "text-slam-tag-1",
  "text-slice-sweep-1",
  "text-split-1",
  "text-tag-negate-1",
  "text-tag-affirm-1",
  "text-plus-icon-1",
  "bubble-text-1",
  "text3d-in-1",
  "title-bounce-1",
  "toggle-switch-1",
  "tri-select-1",
  "vert-quote-bubble-1",
  "vert-title-panel-1",
  "wx-chat-1",
  "wx-chat-2",
  "year-invest-1",
  "stairs-jump-1",
  "label-stack-1",
  "activate-icon-1",
  "motion-lib-1",
  // 2026-10-24 新增（复刻 C:/Users/NINGMEI/20261023_174054.mp4 的 6 个动效）
  "repop-text-1",
  "text-slam-tag-2",
  "focus-burst-1",
  "marquee-rows-1",
  "panel-keyword-1",
  "keys-breakdown-1",
  // 2026-10-24 新增（PRO · 表情进场）—— 表情运动：烟花喷泉
  "emoji-motion-1",
  // 2026-10-28 新增（PRO · 画面布局）—— 背景动效几何批 5 张
  "stripe-sweep-bg-1",
  "contour-waves-bg-1",
  "equalizer-bg-1",
  "split-blocks-bg-1",
  "halftone-fade-bg-1",
  // 2026-10-28 新增（PRO · 画面布局）—— 背景动效卡通批 5 张
  "cloud-drift-bg-1",
  "bubble-rise-bg-1",
  "star-twinkle-bg-1",
  "memphis-float-bg-1",
  "rainbow-arcs-bg-1",
  // 2026-10-29 新增（PRO · 画面布局）—— 背景动效卡通批第 2 组
  "rolling-hills-bg-1",
  "sun-burst-bg-1",
  "pure-bg-1",
  "town-scape-bg-1",
  "doodle-float-bg-1",
  "candy-waves-bg-1",
  // 2026-10-29 新增（PRO · 文字进场）—— 文字进场批次 1 五张
  "pixel-assemble-text-1",
  "barrage-fly-text-1",
  "shatter-reassemble-text-1",
  "neon-glow-text-1",
  "brush-ink-text-1",
  // 2026-10-29 新增（PRO · 文字进场）—— 文字进场批次 2 保留 2 张
  "flip-board-text-1",
  "ripple-mirror-text-1",
  // 2026-10-28 新增（PRO · 信息联动）—— 3 张「多元素因果联动」卡
  "radar-scan-link-1",
  "conveyor-stamp-link-1",
  "magnet-dock-link-1",
  // 2026-10-28 新增（PRO · 常驻层）—— 口播文稿字幕（SRT 驱动）
  "srt-caption-1",
  // 2026-10-29 新增（PRO · 常驻层）—— 口播文稿字幕/2（克隆 + 圆点弹跳/涟漪）
  "srt-caption-2",
  // 2026-10-29 新增（PRO · 信息联动）—— 复刻参考片 20261029_061611.mp4
  "comment-typing-1",
  // 2026-10-29 新增（PRO · 信息联动）
  "mind-nodes-1",
  // 2026-10-29 新增（PRO · 表情进场）
  "confetti-rain-1",
  // 2026-10-29 新增（PRO · 信息联动）
  "skeleton-load-1",
  // 2026-10-29 新增（PRO · 信息联动）
  "dots-reveal-1",
  // 2026-10-29 新增（PRO · 表情进场）
  "sticker-float-1",
  // 2026-10-29 新增（PRO · 常驻层）
  "timecode-hud-1",
  // 2026-10-29 新增（PRO · 表情进场）
  "burst-accent-1",
  // 2026-10-30 新增（PRO · 复刻 20261029_233817.mp4）—— 10 张
  "code-terminal-1",
  "checker-wipe-1",
  "phone-app-launch-1",
  "quest-roadmap-1",
  "stage-clear-1",
  "leaderboard-1",
  "skill-negate-1",
  "skill-tree-1",
  "world-progress-1",
  "podcast-big-text-1",
  "workflow-check-1",
  "device-flow-1",
  "slot-percent-1",
  // 2026-10-30 三批（PRO · 信息联动）—— 方块序列（代码终端右侧面板拆出的独立卡）
  "block-sequence-1",
  // 2026-10-30 四批（PRO · 数据）—— 滚轮数字/4、滚轮数字/5（复刻 20261030_121623.mp4）
  "num-roll-4",
  "num-roll-5",
  "points-link-1",
  "panel-tag-2",
  // 2026-10-31：3D 几何体（Three.js 实时渲染 + 可上传 .glb）—— 升为 PRO
  "three-geo-1",
])

// 机器码提供方：主进程注入 systemMachineId（与 renderer 桌面端同源）；测试可注入桩。
let _machineIdProvider = () => 'na'
function setMachineIdProvider(fn) {
  _machineIdProvider = typeof fn === 'function' ? fn : () => 'na'
}

// FNV-1a，输出 8 位 hex（与 edition.ts 的 hashStr 同口径）
function fnv1a(s) {
  let h = 0x811c9dc5
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i)
    h = Math.imul(h, 0x01000193)
  }
  return (h >>> 0).toString(16).padStart(8, '0')
}

// 规范机器码（无连字符）：与 edition.ts machineCodeNorm 桌面端同口径（用系统级 ID）
function machineCodeNorm() {
  const mid = _machineIdProvider()
  const base = mid && mid !== 'na' ? fnv1a('vfx-mc-guid:' + mid) : fnv1a('vfx-mc-guid:na')
  const ext = fnv1a('vfx-mc-salt:' + base)
  return 'VFXMC' + (base + ext).toUpperCase()
}

function b64urlToBytes(b64) {
  const s = String(b64).replace(/-/g, '+').replace(/_/g, '/')
  const pad = s.length % 4 === 0 ? '' : '='.repeat(4 - (s.length % 4))
  return Buffer.from(s + pad, 'base64')
}

/**
 * 验证激活码：ECDSA 验签 + 过期 + 机器码比对。
 * 与 edition.ts verifyActivation、scripts/issue_pro_key.cjs 同口径（均用 WebCrypto，签名是 raw R||S / P1363）。
 *
 * ⚠️ 必须用 WebCrypto subtle.verify（raw），不能用 Node 老 crypto.verify（默认期望 DER 格式）。
 *    issue_pro_key.cjs 用 subtle.sign 签出的是 raw 码；若主进程用 crypto.verify 验，raw 码会验不过，
 *    表现为「专业版每次打开闪回基础版」（renderer 端用 subtle.verify 能验过，所以以前正常）。2026-10-16 确诊。
 * 返回 { ok, expired?, mcMismatch? }
 */
async function verifyProCode(raw) {
  try {
    const m = String(raw || '').trim().match(/^VFXPRO-(.+)$/i)
    if (!m) return { ok: false }
    const inner = m[1]
    const dot = inner.indexOf('.')
    if (dot < 0) return { ok: false }
    const payloadB64 = inner.slice(0, dot)
    const sigB64 = inner.slice(dot + 1)
    let payload
    try {
      payload = JSON.parse(b64urlToBytes(payloadB64).toString('utf8'))
    } catch {
      return { ok: false }
    }
    // WebCrypto 验签：签名是 raw R||S（与 subtle.sign / issue_pro_key.cjs 同格式）。
    // ⚠️ subtle.verify 只认 WebCrypto CryptoKey，不能用 crypto.createPublicKey 的 Node KeyObject。
    const pub = await subtle.importKey(
      'spki',
      Buffer.from(PRO_PUBLIC_KEY_B64, 'base64'),
      { name: 'ECDSA', namedCurve: 'P-256' },
      false,
      ['verify'],
    )
    const valid = await subtle.verify(
      { name: 'ECDSA', hash: 'SHA-256' },
      pub,
      b64urlToBytes(sigB64),
      Buffer.from(payloadB64, 'utf8'),
    )
    if (!valid) return { ok: false }
    if (payload.ed !== 'pro') return { ok: false }
    if (payload.exp && Date.now() > payload.exp) return { ok: false, expired: true }
    if (payload.mc !== machineCodeNorm()) return { ok: false, mcMismatch: true }
    return { ok: true }
  } catch {
    return { ok: false }
  }
}

/** 从 app-state 对象判断是否为 PRO（激活码以 'VX1.' 前缀存于 vfx-studio:edition） */
async function isPro(state) {
  const raw = (state && state['vfx-studio:edition']) || ''
  const code = raw.startsWith('VX1.') ? raw.slice(4) : raw
  if (!code) return false
  return (await verifyProCode(code)).ok
}

function isProKind(kind) {
  return PRO_KINDS.has(kind)
}

/**
 * 导出卡清单复核：给定本次导出用到的卡种集合与是否 PRO，
 * 返回 BASE 态下应被剔除（不应导出）的 pro 卡种子集。
 * 主进程在导出合成前调用：非空即 fail-closed 拦截（拦/剔除）。
 */
function blockedKinds(kinds, pro) {
  if (pro) return []
  const out = []
  for (const k of kinds || []) if (PRO_KINDS.has(k)) out.push(k)
  return out
}

module.exports = {
  PRO_PUBLIC_KEY_B64,
  PRO_KINDS,
  setMachineIdProvider,
  fnv1a,
  machineCodeNorm,
  b64urlToBytes,
  verifyProCode,
  isPro,
  isProKind,
  blockedKinds,
}
