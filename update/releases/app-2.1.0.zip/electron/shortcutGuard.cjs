/**
 * 客户端「浏览器类快捷键」护栏
 * ───────────────────────────────────────────────────────────────────────────
 * 客户端是 Chromium 内核，出厂带一整套网页快捷键。对 VFX STUDIO 这种
 * 「有未保存工程 + 精密排版 + 自绘无边框 UI」的桌面应用来说，其中一部分
 * 属于误触炸弹：Ctrl+Shift+I 弹出 DevTools、Ctrl+R 直接重载（工程回到初始态）、
 * Alt+← 触发页面后退、Ctrl+W 关窗口……
 *
 * 用法（electron/main.cjs）：
 *   const guard = require('./shortcutGuard.cjs')
 *   guard.installWebShortcutGuard(win.webContents, !isDev)  // dev 模式放行
 *
 * ⚠️ 这是一个**独立文件**，必须在 scripts/sync-portable.cjs 的同步清单里
 *    （否则便携版 / 安装版 require 不到它 ⇒ 客户端直接打不开）。
 *
 * 2026-10-16 建立。分组开关改 true/false 即可整组开合。
 */
'use strict'

/** 分组开关（★ = 用户已确认启用；2026-10-16 用户「按建议全禁」⇒ 九组全开） */
const SHORTCUT_GUARD = {
  /** ★开发者工具：Ctrl/Cmd+Shift+I / J / C、F12、macOS ⌘⌥I / J / C */
  devTools: true,
  /** ★页面重载：Ctrl/Cmd+R、F5、Ctrl/Cmd+Shift+R、Ctrl/Cmd+F5 —— 会丢未保存工程 */
  reload: true,
  /** ★查看源码：Ctrl/Cmd+U */
  viewSource: true,
  /** ★打印：Ctrl/Cmd+P（打印当前 SPA 页面，无意义且卡住界面） */
  print: true,
  /** ★保存网页：Ctrl/Cmd+S（App 有自己的导出/保存，不该被「网页另存」抢） */
  savePage: true,
  /** ★页面缩放：Ctrl/Cmd+= / - / 0（滚轮缩放另见 src/main.tsx 的 BLOCK_CTRL_WHEEL_ZOOM） */
  zoom: true,
  /** ★全屏：F11（自绘标题栏没有配套的全屏退出入口） */
  fullscreen: true,
  /** ★页面前进/后退：Alt+← / Alt+→ —— SPA 里表现是「界面凭空回到上一状态」 */
  historyNav: true,
  /** ★关闭窗口：Ctrl/Cmd+W、Ctrl/Cmd+Shift+W */
  closeWindow: true,
}

/**
 * 判断一次按键是否命中屏蔽表（纯函数，供 build-out/kwcheck 数值闸门校验）。
 *
 * 用 input.code（物理键位）而不是 input.key：key 会随输入法 / 大小写 /
 * 键盘布局变化（俄文布局下 Ctrl+Shift+I 的 key 是 'Ш'），code 恒为 'KeyI'。
 *
 * @param {{type?:string,code?:string,control?:boolean,shift?:boolean,alt?:boolean,meta?:boolean}} input
 * @returns {string|null} 命中的分组名；未命中返回 null
 */
function webShortcutHit(input) {
  if (!input) return null
  if (input.type && input.type !== 'keyDown') return null
  const ctrl = !!input.control
  const shift = !!input.shift
  const alt = !!input.alt
  const meta = !!input.meta
  const mod = ctrl || meta // 主修饰键：Windows/Linux = Ctrl，macOS = Cmd
  const code = input.code || ''
  const G = SHORTCUT_GUARD

  if (G.devTools) {
    // Windows/Linux: Ctrl+Shift+I(J/C)  macOS: ⌘⌥I(J/C)
    if (mod && shift && !alt && (code === 'KeyI' || code === 'KeyJ' || code === 'KeyC')) return 'devTools'
    if (meta && alt && (code === 'KeyI' || code === 'KeyJ' || code === 'KeyC')) return 'devTools'
    if (!mod && !shift && !alt && code === 'F12') return 'devTools'
  }
  if (G.reload && (mod && code === 'KeyR' || code === 'F5')) return 'reload'
  if (G.viewSource && mod && !shift && !alt && code === 'KeyU') return 'viewSource'
  if (G.print && mod && !shift && !alt && code === 'KeyP') return 'print'
  if (G.savePage && mod && !shift && !alt && code === 'KeyS') return 'savePage'
  if (G.zoom && mod && (code === 'Equal' || code === 'Minus' || code === 'Digit0' || code === 'NumpadAdd' || code === 'NumpadSubtract')) {
    return 'zoom'
  }
  if (G.fullscreen && !mod && !shift && !alt && code === 'F11') return 'fullscreen'
  if (G.historyNav && alt && !mod && (code === 'ArrowLeft' || code === 'ArrowRight')) return 'historyNav'
  if (G.closeWindow && mod && code === 'KeyW') return 'closeWindow'
  return null
}

/** 命中且需要「连浏览器默认动作一起吃掉」的（目前全部） */
function shouldBlock(input) {
  return webShortcutHit(input) !== null
}

/**
 * 给某个窗口的 webContents 装上护栏。
 * @param {import('electron').WebContents} wc
 * @param {boolean} enabled false = 完全放行（开发调试用）
 */
function installWebShortcutGuard(wc, enabled = true) {
  if (!wc || !enabled) return
  wc.on('before-input-event', (event, input) => {
    if (shouldBlock(input)) event.preventDefault()
  })
}

module.exports = { SHORTCUT_GUARD, webShortcutHit, shouldBlock, installWebShortcutGuard }
